import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\EUXSK\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(
				"https://login.microsoftonline.com/fcb2b37b-5da0-466b-9b83-0014b67a7c78/oauth2/authorize?client_id=ff05efd4-400b-470c-8630-2e62dd58a057&redirect_uri=https%3A%2F%2Fbayernet.int.bayer.com%2F&response_mode=form_post&response_type=code%20id_token&scope=openid%20profile%20email%20group.read.all&state=OpenIdConnect.AuthenticationProperties%3DBwBcOuPBWqQGi1ldv1owivuTyOMfamqJ_sl9aNyJUZhHSLWkCUFJkP0Apws_mcJox75jQwfR9ICOEOFqHUIiq4UalMOX6JZYtnELaoTEiNLfBw1Mbw2K565Rio06v5bWlnvqLMWrsPwLUnPByR3tc--9KV5bg0YEu6l3M8mTMcDToFRgeC2TOTngKD9zQZ06QRL3_r007PmaPSwOwverROvvWhsGQn_5PJG-_vtbJHyxj-KFGAv3E9KjfoZZHrzAgOcMoqCVc_SdtNhpO9BYLh-fjZiW3ggyqSjITM-IaI-BOaFAqV5jS8CzSfdbHEMG&nonce=637190743286533434.MmYwMmRlZjAtOWYyYS00MmM4LWI2MzctMWMxM2M2ZTkyNzE3NTI0OGQ4YmQtZjJhMC00MjQzLTllM2MtOWQ4NTBiOWMxZTEy&x-client-SKU=ID_NET451&x-client-ver=5.2.2.0&sso_reload=true");

	}

}
