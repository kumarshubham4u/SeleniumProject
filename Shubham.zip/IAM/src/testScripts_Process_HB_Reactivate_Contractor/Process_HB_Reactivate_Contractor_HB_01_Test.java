package testScripts_Process_HB_Reactivate_Contractor;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForReactivateContractor;

public class Process_HB_Reactivate_Contractor_HB_01_Test extends BaseTest {
	
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForReactivateContractor objReactivate = new RequestForReactivateContractor();	
	
	@Test
	public void Process_HB_Reactivate_Contractor() throws InterruptedException, AWTException{
		
		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();
		
		//Clicking on gums Contractor Admin Link
		objHomePage.clickingOnGumsContractorAdmin();
		
		// Clicking on Reactivate CWID for contractor GUMS Non-GHR link
		objReactivate.clickingOnReactivateCwidLink();
		
		//Clicking on Search CWID button
		objReactivate.clickingOnSearchCwid();
		
		//Selecting First row CWID for reactivation
		objReactivate.clickingOnFirstRowCWID();
		
		//Clicking on Ok button
		objReactivate.clickingOnOkButton();
		
		//Clicking on Next button
		objReactivate.clickingNextButton();
		
		//Clicking on Next button without entering mandatory fields
		objReactivate.clickingNextButtonWithoutEnteringFields();
		
		// Sending Keys for external Company Name
		objReactivate.sendingKeysOnExtCompanyName();
		
		// Sending Keys for Sponser CWID lookup
		objReactivate.sendingKeysOnSponsorCWIDLookup();
		
		//Sending Keys for Valid To date
		objReactivate.sendingKeysOnValidToDate();
		
		//Sending Keys for External Email
		objReactivate.sendingKeysOnExtEmail();
		
		//Sending Keys for External Mobile Country Code
		objReactivate.sendingKeysOnExtMobileCountryCode();
		
		//Sending Keys for External Mobile Country Prefix
		objReactivate.sendingKeysOnExtMobilePrefix();
		
		//Sending Keys for External Mobile Country Number
		objReactivate.sendingKeysOnExtMobileNumber();
		
		//Clicking on Next button after entering fields
		objReactivate.clickingNextButtonAfterEnteringFields();
		
		//Fetching generated CWID details and Clicking on Finish button
		objReactivate.clickingFinishButton();
		
		//Checking for the submission State
		objReactivate.submissionState();
		
		//Closing the browser
		objBaseTest.CloseBrowser();
		
	}

}
