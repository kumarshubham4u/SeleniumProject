package testScripts_Process_N_New_2nd_CWID;

import java.awt.AWTException;
import org.testng.Assert;
import org.testng.annotations.Test;
import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForNewSecondaryCWIDBySponsorPage;
import page.RequestForSecondaryCwidPage;

/**
 *  Process_N_New_2nd_CWID_N_03 - Rejecting request without Ad account -  contractor login
 * 
 * @author EPVRY
 *
 */
  

@Test
public class Process_N_New_2nd_CWID_N_03Test extends BaseTest
{
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new  HomePage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();
	RequestForNewSecondaryCWIDBySponsorPage objRequestRequestForNewSecondaryCWIDBySponsorPage = new RequestForNewSecondaryCWIDBySponsorPage();

	
	public void Process_N_New_2nd_CWID_N_03Scenario() throws InterruptedException, AWTException
	{
		String reasonForRequestEntered = "Required for Rejection scenario";
		// Login in with Contractor
		//entering userName from windows popup
		robotClassUserNameForContractor("Contractor");

		//entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Contractor");
		
		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		//Creating Secondary CWID 
		objRequestSecondaryCwidPage.creatingSecondaryCWIDLink(reasonForRequestEntered,"WithOut_ADAccount","DoNotSelectCyberArkRadioButton");
		String succesMessagExpected ="Your request has been submitted successfully.";

		//Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabel(BaseTest.driver).getText().trim();
		//System.out.println("succesMessagActual"+succesMessagActual);
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label.");

		//Closing the session
		BaseTest.driver.close();

		//Login with the Sponsor to approve the request
		browserInitialization();

		//entering userName from windows popup
		robotClassUserNameForContractor("Sponsor");

		//entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Supervisor");

		//Clicking and viewing the request 
		String reasonForRequestViewApproverPage=  objRequestRequestForNewSecondaryCWIDBySponsorPage.viewingSecondaryCWIDRequest("SelectedGeneralAdministrativePurposesRadioButton");
		System.out.println("reasonForRequestViewApproverPage"+reasonForRequestViewApproverPage);
		Assert.assertEquals(reasonForRequestEntered, reasonForRequestViewApproverPage);
		objBaseTest.logResults("Clicking and viewing the request ");

		//Rejecting request without entering comments
		String rejectionPopUpMessageLabelExpected ="Specify a value for all required fields";
		String rejectionPopUpMessageLabelActual = objRequestRequestForNewSecondaryCWIDBySponsorPage.clickingRejectButtonWithOutEnteringComments("WithOut_ADAccount");
		Assert.assertEquals(rejectionPopUpMessageLabelActual, rejectionPopUpMessageLabelExpected);

		//Rejecting  request with entering comments
		objRequestRequestForNewSecondaryCWIDBySponsorPage.clickingRejectButtonWithEnteringComments();

		//Assert to check success message.
		String succesMessagApproverExpected ="Your task has been completed successfully.";
		String succesMessagApproverActual = objRequestRequestForNewSecondaryCWIDBySponsorPage.successMessageForApproverLabel(BaseTest.driver).getText().trim();
		//System.out.println("succesMessagActualApprover"+succesMessagApproverActual);
		Assert.assertEquals(succesMessagApproverActual, succesMessagApproverExpected);
		objBaseTest.logResults("Checking success message label."+ succesMessagApproverActual );

	}

}
