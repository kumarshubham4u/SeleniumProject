package testScripts_Process_N_New_2nd_CWID;

import java.awt.AWTException;

import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.RequestForSecondaryCwidPage;

@Test
public class LoginTest  extends BaseTest 

{
	BaseTest objBaseTest = new BaseTest();
	RequestForSecondaryCwidPage objHomePage = new RequestForSecondaryCwidPage();

	
	public void LoginTest() throws InterruptedException, AWTException
	{
		String reasonForRequestEntered = "Required for Rejection scenario";
		// Login in with Contractor
		//entering userName from windows popup
		robotClassUserNameForContractor("Contractor");

		//entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Contractor");
	}
}
