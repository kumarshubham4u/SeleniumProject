package testScripts_Process_X_Create_Delegation;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForDelegateRights;

public class Process_X_Create_Delegation_X04_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForDelegateRights objDelegate = new RequestForDelegateRights();

	/*
	 * Test case for Creating Delegation Request by Employee(BBSS4) and Approving it
	 * from the delegate Employee(BBSE56). Also to Validate if the request raise by
	 * Contractor(BBSC9) after Delegation is sent to Delegated Employee(BBSE56) for
	 * approval
	 */

	/*
	 * You need to run "Process_Y_Revoke_Delegation_Y_02_Test" script before running
	 * this script to check if the Delegate rights were already present for BBSE56, else script will fail
	 */
	@Test
	public void Process_X_Create_Delegation_X04_Approve() throws InterruptedException, AWTException {

		// Login in with Employee (BBSS4)
		// entering userName from windows popup
		robotClassUserNameForEmployee("Employee");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Delegation / Aufgaben �bertragen Link
		objHomePage.clickingOnDelegationLink();

		// Clicking on Delegate Gums Right to an Employee Link
		objDelegate.clickingOnDelegateGumsRight();

		// Sending Keys for search search CWID lookup
		objDelegate.sendingKeysOnLookupCWID();

		// Clicking on Next button without entering fields
		objDelegate.clickingNextButtonWithoutEnteringFields();

		// Sending Keys on Delegate from date
		objDelegate.sendingKeysOnDelegateFromDate();

		// Sending Keys on Delegate To date
		objDelegate.sendingKeysOnDelegateToDate();

		// Clicking on Finish button
		objDelegate.clickingFinishButton();

		// Checking for the submission State
		objDelegate.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		// Re-launch browser for new session
		objBaseTest.browserInitialization();

		// Login in with Employee (BBSE56)
		// entering userName from windows popup
		robotClassUserNameForEmployee("employeeGSO");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Delegate Employee");
		Reporter.log("Login with Delegate Employee");

		// Clicking on View All Request link
		objDelegate.clickingOnViewAllRequest();

		// Clicking on Create Delegation, Accept Request Link
		objDelegate.clickingOnCreateDelegationLink();

		// Clicking on Accept No radio button
		objDelegate.acceptingRequest();

		// Checking for the submission State
		objDelegate.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		// Re-launch browser for new session
		objBaseTest.browserInitialization();

		// Login in with Contractor(BBSC9)
		// entering userName from windows popup
		robotClassUserNameForContractor("ContractorDelegate");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Contractor to Validate if the raised request is sent to Delegated Employee");
		Reporter.log("Login with Contractor to Validate if the raised request is sent to Delegated Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Raising Secondary CWID Request
		objDelegate.raisingSecondaryCwidRequest();

		// Checking for Request Submit state
		objDelegate.requestState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		// Re-launch browser for new session
		objBaseTest.browserInitialization();

		// Login in with Employee (BBSE56)
		// entering userName from windows popup
		robotClassUserNameForEmployee("employeeGSO");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Delegate Employee to validate if received Request raised by Contractor");
		Reporter.log("Login with Delegate Employee to validate if received Request raised by Contractor");

		// Clicking on View All Request link
		objDelegate.clickingOnViewAllRequest();

		// Clicking on Approve New Secondary CWID Request Link
		objDelegate.clickingOnApproveNewSecCWIDRequestLink();

		// Validating if the Approval request was sent to new Delegate Employee
		objDelegate.validateRequest();

		// Checking for the submission State
		objDelegate.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
