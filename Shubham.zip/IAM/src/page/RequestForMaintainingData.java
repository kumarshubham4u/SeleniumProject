package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForMaintainingData {

	BaseTest objBaseTest = new BaseTest();

	String bayerMail = "test123@bayer.com";
	String company = "Test ext. Company";
	String randomMailID = null;
	String randomPrefix = null;
	String randomMobile = null;
	String randomCompanyName = null;
	String randomCompanyID = null;
	String companyNameCheck = null;
	String phoneCheck = null;
	String emailValidate = null;

	static String mail = "@xyz.com";
	static int n = 6;

	// Creator locators
	private By maintainMyDataLink = By.xpath("//span[(text()='Maintain my data')]");
	private By emailCheck = By.xpath("//input[@id='1036984']");
	private By checkButton = By.xpath("//input[@value='Check']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Submit']");
	private By submitButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Submit']");
	private By dropdown = By.xpath("//span[@id='HorzBarUserDropDown']");
	private By myProfile = By.xpath("//span[(text()='My profile')]");

	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By extCompanyName = By.xpath("//input[@id='1036828']");
	private By extCompanyNameActual = By.xpath("//input[@id='1036658']");
	private By extEmailActual = By.xpath("//input[@id='1036672']");
	private By phoneNumberActual = By.xpath("//input[@id='EXT_MOBILE_FULL_NR']");
	private By extMobileCountryCode = By.xpath("//input[@id='1036851']");
	private By extMobilePrefix = By.xpath("//input[@id='1036852']");
	private By extMobileNumber = By.xpath("//input[@id='1036853']");
	private By phoneNumber = By.xpath("//input[@id='1036854']");
	private By requestMessageLabel = By.xpath(
			"//span[@id='PageMsgsContnr']//td[contains(text(),'Your request has been submitted successfully.')]");

	// Returning WebElement from respective locators

	public WebElement maintainMyDataLink(final WebDriver driver) {
		return driver.findElement(maintainMyDataLink);

	}

	public WebElement emailCheck(final WebDriver driver)

	{
		return driver.findElement(emailCheck);
	}

	public WebElement checkButton(final WebDriver driver)

	{
		return driver.findElement(checkButton);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement submitButton(final WebDriver driver) {
		return driver.findElement(submitButton);

	}

	public WebElement dropdown(final WebDriver driver) {
		return driver.findElement(dropdown);

	}

	public WebElement myProfile(final WebDriver driver) {
		return driver.findElement(myProfile);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement extEmailActual(final WebDriver driver) {
		return driver.findElement(extEmailActual);
	}

	public WebElement extCompanyNameActual(final WebDriver driver) {
		return driver.findElement(extCompanyNameActual);
	}

	public WebElement phoneNumberActual(final WebDriver driver) {
		return driver.findElement(phoneNumberActual);
	}

	public WebElement extCompanyName(final WebDriver driver) {
		return driver.findElement(extCompanyName);
	}

	public WebElement extMobileCountryCode(final WebDriver driver) {
		return driver.findElement(extMobileCountryCode);
	}

	public WebElement extMobilePrefix(final WebDriver driver) {
		return driver.findElement(extMobilePrefix);
	}

	public WebElement extMobileNumber(final WebDriver driver) {
		return driver.findElement(extMobileNumber);
	}

	public WebElement phoneNumber(final WebDriver driver) {
		return driver.findElement(phoneNumber);
	}

	public WebElement requestMessageLabel(final WebDriver driver) {
		return driver.findElement(requestMessageLabel);

	}

	/**
	 * Function to click on maintain My Data Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnMaintainMyDataLink() throws InterruptedException {
		// Clicking on maintain My Data Link
		Thread.sleep(5000);
		// maintainMyDataLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(maintainMyDataLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Maintain My Data Link");
	}

	/**
	 * Function to Check Exceptions
	 * 
	 * @throws InterruptedException
	 */
	public void checkValidation() throws InterruptedException {

		// generating random Prefix,Mobile number and ext. company ID
		randomPrefix = number();
		randomMobile = number();
		randomCompanyID = number();

		// Sending Keys on External Email as Bayer Mail ID
		objBaseTest.fluentWait();
		Thread.sleep(6000);
		emailCheck(BaseTest.driver).clear();
		Thread.sleep(2000);
		emailCheck(BaseTest.driver).sendKeys(bayerMail);
		objBaseTest.logResults("Sending Keys on External Email as Bayer Mail ID to Check for Validation Error");
		Thread.sleep(1000);
		submitButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Submit Button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		String alert1 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending Keys on external Company Name
		extCompanyName(BaseTest.driver).clear();
		Thread.sleep(1000);
		extCompanyName(BaseTest.driver).sendKeys(company + "_" + randomCompanyID);
		objBaseTest.logResults("Sending Keys for external Company Name");
		companyNameCheck = extCompanyName(BaseTest.driver).getAttribute("value");
		Thread.sleep(2000);

		// Sending Keys on Mobile Country Code as invalid
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("8972");
		objBaseTest.logResults("Sending Keys for Mobile Country Code as invalid to check for Validation error");
		submitButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Submit Button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Country code as invalid

		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Country Code\" could not be validated");

		// Sending Keys on Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for mobile country code as valid");

		// Sending Keys on Mobile Prefix as invalid
		Thread.sleep(2000);
		extMobilePrefix(BaseTest.driver).clear();
		Thread.sleep(1000);
		extMobilePrefix(BaseTest.driver).sendKeys("abcd123");
		objBaseTest.logResults("Sending Keys for External Mobile Prefix as invalid to check for Validation error");
		submitButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Submit Button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys(randomPrefix);
		objBaseTest.logResults("Sending Keys for mobile prefix as valid");

		// Sending Keys on Mobile Number as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		Thread.sleep(1000);
		extMobileNumber(BaseTest.driver).sendKeys("wxyz123");
		objBaseTest.logResults("Sending Keys for External Mobile Number as invalid to check for Validation error");
		submitButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Submit Button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid

		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys(randomMobile);
		objBaseTest.logResults("Sending Keys for external mobile number as valid");

	}

	/**
	 * Function to Send Valid Email ID to External Email Field
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysToEmailID() throws InterruptedException {

		// Sending Keys on External Email ID as random Mail ID
		randomMailID = getAlphaNumericString();
		Thread.sleep(2000);

		emailCheck(BaseTest.driver).clear();
		Thread.sleep(1000);
		emailCheck(BaseTest.driver).sendKeys(randomMailID);
		objBaseTest.logResults("Sending Keys on External Email ID as random Mail ID");
		Thread.sleep(1000);
		emailValidate = emailCheck(BaseTest.driver).getAttribute("value");
		phoneCheck = phoneNumber(BaseTest.driver).getAttribute("value");
		Thread.sleep(2000);
		submitButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Submit Button");

	}

	/**
	 * Function to Validate the Changed Data of User
	 * 
	 * @throws InterruptedException
	 */
	public void ValidateUserData() throws InterruptedException {

		// Clicking on Horizontal Drop-down from the Profile
		Thread.sleep(2000);
		dropdown(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Horizontal Drop-down from the Profile ");

		// Clicking on My Profile menu
		Thread.sleep(2000);
		myProfile(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on My Profile menu");
		objBaseTest.explicitWait(extEmailActual);
		Thread.sleep(2000);

		// Validating External Email ID
		String actualEmail = extEmailActual(BaseTest.driver).getAttribute("value");
		Assert.assertEquals(emailValidate, actualEmail);
		objBaseTest.logResults("External Email ID was updated and validated");

		// Validating External Company Name
		Thread.sleep(2000);
		String actualExtCompanyName = extCompanyNameActual(BaseTest.driver).getAttribute("value");
		Assert.assertEquals(companyNameCheck, actualExtCompanyName);
		objBaseTest.logResults("External Company Name was updated and validated");

		// Validating External Mobile Full Number
		Thread.sleep(2000);
		objBaseTest.scrollInView(phoneNumberActual(BaseTest.driver));
		Thread.sleep(1000);
		String actualMobileNumber = phoneNumberActual(BaseTest.driver).getAttribute("value");
		Assert.assertEquals(phoneCheck, actualMobileNumber);
		objBaseTest.logResults("External Mobile Full Number was updated and validated");

	}

	/**
	 * Function to Check for Request message display
	 * 
	 * @throws InterruptedException
	 */

	public void requestState() throws InterruptedException {

		// Assert to check request message.
		objBaseTest.explicitWait(requestMessageLabel);
		String requestMessagExpected = "Your request has been submitted successfully.";
		String requestMessagActual = requestMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(requestMessagActual, requestMessagExpected);
		objBaseTest.logResults("Checking request submission message label. " + requestMessagActual);
		Reporter.log("Checking request submission message label. " + requestMessagActual);

	}

	// function to generate a random string of length n
	static String getAlphaNumericString() {

		// choose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		String Alphabate = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {
			if (i == 0) {
				int index = (int) (Alphabate.length() * Math.random());
				sb.append(Alphabate.charAt(index));
			} else {
				// generate a random number between
				// 0 to AlphaNumericString variable length
				int index = (int) (AlphaNumericString.length() * Math.random());

				// add Character one by one in end of sb
				sb.append(AlphaNumericString.charAt(index));

			}
		}
		sb.append(mail);
		return sb.toString();
	}

	// Function to generate a random Number of length 5

	public static String NUMERIC_STRING = "0123456789";

	public static String number() {
		int count = 5;
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * NUMERIC_STRING.length());
			builder.append(NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

}
