package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForDelegateRights {

	BaseTest objBaseTest = new BaseTest();
	String reasonText = "This a Test to Validate";
	String loginCwid = "BBSS4";
	String delegateCwid = "BBSE56";
	String pastDate = "04/25/2019";
	String futureDate = "04/20/2035";
	String validDate = "04/27/2021";

	// Creator locators

	private By delegateGumsRight = By.xpath("//span[(text()='Delegate GUMS rights to an employee')]");
	private By lookupCWID = By.xpath("//input[@id='1014636']");
	private By nextButton = By.xpath("//input[@value='Next >']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By delegateFromDate = By.xpath("//input[@id='1014627']");
	private By delegateToDate = By.xpath("//input[@id='1014628']");
	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");
	private By requestMessageLabel = By.xpath(
			"//span[@id='PageMsgsContnr']//td[contains(text(),'Your request has been submitted successfully.')]");
	private By viewAllRequest = By.xpath("//div[@id='Dashboard1_widget1_header']//span[text()='View all >']");
	private By createDelegationLink = By.xpath("//a[text()='Create delegation, accept request']");
	private By approveNewSecCWIDRequestLink = By
			.xpath("//a[contains(text(),'Approve request for new secondary CWID')]");

	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By acceptYes = By.xpath("//label[contains(text(),'Yes')]");
	private By acceptNo = By.xpath("//label[contains(text(),'No')]");
	private By backButton = By.xpath("//input[@value='< Back']");

	private By requestSecondaryCWIDLink = By.xpath(
			"//span[contains(@title,'request a CWID for testing ')]//span[contains(text(),'Request Secondary CWID')]");
	private By reasonForRequest = By.id("1001452");
	private By requestForSecondaryCWIDButton = By.id("btnTrans1013993");
	private By validateReason = By.xpath("//td[@class='propml-wrapper-ctrl']//textarea[@id='1001460']");
	private By approveRequestButton = By
			.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Approve request')]");

	// Returning WebElement from respective locators

	public WebElement delegateGumsRight(final WebDriver driver) {
		return driver.findElement(delegateGumsRight);

	}

	public WebElement lookupCWID(final WebDriver driver) {
		return driver.findElement(lookupCWID);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement delegateFromDate(final WebDriver driver) {
		return driver.findElement(delegateFromDate);
	}

	public WebElement delegateToDate(final WebDriver driver) {
		return driver.findElement(delegateToDate);
	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	public WebElement requestMessageLabel(final WebDriver driver) {
		return driver.findElement(requestMessageLabel);

	}

	public WebElement viewAllRequest(final WebDriver driver)

	{
		return driver.findElement(viewAllRequest);
	}

	public WebElement createDelegationLink(final WebDriver driver)

	{
		return driver.findElement(createDelegationLink);
	}

	public WebElement approveNewSecCWIDRequestLink(final WebDriver driver)

	{
		return driver.findElement(approveNewSecCWIDRequestLink);
	}

	public WebElement acceptYes(final WebDriver driver)

	{
		return driver.findElement(acceptYes);
	}

	public WebElement acceptNo(final WebDriver driver)

	{
		return driver.findElement(acceptNo);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement requestSecondaryCWIDLink(final WebDriver driver) {
		return driver.findElement(requestSecondaryCWIDLink);
	}

	public WebElement reasonForRequest(final WebDriver driver) {
		return driver.findElement(reasonForRequest);
	}

	public WebElement requestForSecondaryCWIDButton(final WebDriver driver) {
		return driver.findElement(requestForSecondaryCWIDButton);
	}

	public WebElement validateReason(final WebDriver driver) {
		return driver.findElement(validateReason);
	}

	public WebElement approveRequestButton(final WebDriver driver) {
		return driver.findElement(approveRequestButton);
	}

	/**
	 * Function to click on delegate Gums Right
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDelegateGumsRight() throws InterruptedException {
		// Clicking on Delegate Gums Right to an Employee Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// delegateGumsRight(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(delegateGumsRight(BaseTest.driver));
		objBaseTest.logResults("Clicking on Delegate Gums Right to an Employee Link");

	}

	/**
	 * Function clicking on Next button without entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButtonWithoutEnteringFields() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

	}

	/**
	 * Function for clicking on Finish button
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingFinishButton() throws InterruptedException {
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(2000);
		// Clicking on Finish button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");

	}

	/**
	 * Function to click on View all Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnViewAllRequest() throws InterruptedException {
		Thread.sleep(16000);
		viewAllRequest(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on View all Button");

	}

	/**
	 * Function to click on Accept Yes radio button
	 * 
	 * @throws InterruptedException
	 */
	public void acceptingRequest() throws InterruptedException {
		// Clicking on Accept Yes radio button
		Thread.sleep(10000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		acceptYes(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on  Accept Yes radio button");
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");

		// Clicking on Finish button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(3000);
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish button");

	}

	/**
	 * Function to click on Accept No radio button
	 * 
	 * @throws InterruptedException
	 */
	public void decliningRequest() throws InterruptedException {
		// Clicking on Accept No radio button

		Thread.sleep(10000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		acceptNo(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on  Accept No radio button");
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");

		// Clicking on Next button after verifying the Final form
		objBaseTest.explicitWait(backButton);
		Thread.sleep(3000);
		nextButton(BaseTest.driver).click();

		// Clicking on Finish button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(3000);
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish button");

	}

	/**
	 * Function to click on Create Delegation, Accept Request Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnCreateDelegationLink() throws InterruptedException {
		// Clicking on Create Delegation, Accept Request Link
		objBaseTest.explicitWait(createDelegationLink);
		Thread.sleep(2000);
		createDelegationLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Create Delegation, Accept Request Link");

	}

	/**
	 * Function to click on approve New Secondary CWID Request Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnApproveNewSecCWIDRequestLink() throws InterruptedException {
		// Clicking on approve New Secondary CWID Request Link
		objBaseTest.explicitWait(approveNewSecCWIDRequestLink);
		Thread.sleep(2000);
		approveNewSecCWIDRequestLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Approve New Secondary CWID Request Link");

	}

	/**
	 * Function to send keys on search CWID lookup
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnLookupCWID() throws InterruptedException {
		// Sending Keys for search search CWID lookup as Logged in Employee to
		// check for Validation error
		objBaseTest.explicitWait(lookupCWID);
		Thread.sleep(2000);
		lookupCWID(BaseTest.driver).sendKeys(loginCwid + Keys.TAB);
		objBaseTest.logResults("Sending Keys to search CWID as Logged in Employee to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert1 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending Keys for search search CWID lookup as another Employee
		Thread.sleep(3000);
		lookupCWID(BaseTest.driver).sendKeys(delegateCwid + Keys.TAB);
		objBaseTest.logResults("Sending Keys to search CWID as another Employee");
	}

	/**
	 * Function to send keys on Delegate from date
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnDelegateFromDate() throws InterruptedException {
		// Sending Keys on Delegate from date
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Delegate from date" as past date
		objBaseTest.scrollInView(delegateFromDate(BaseTest.driver));
		delegateFromDate(BaseTest.driver).sendKeys(pastDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Delegate from\" date as past date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert2 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

		// Sending keys on "Delegate from date" as todays date
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		delegateFromDate(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Delegate from\" date as todays date");

	}

	/**
	 * Function to send keys on Delegate to date
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnDelegateToDate() throws InterruptedException {
		// Sending Keys on Delegate from date
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Delegate to date" as past date
		delegateToDate(BaseTest.driver).sendKeys(pastDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Delegate To\" date as past date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert3 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert3);

		// Sending keys on "Delegate to date" as more than 365 days
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		delegateToDate(BaseTest.driver).sendKeys(futureDate + Keys.ENTER);
		objBaseTest
				.logResults("Sending keys on \"Delegate To\" date as more than 365 days to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		objBaseTest.explicitWait(popUpMessageOkButton);
		Thread.sleep(2000);
		String alert4 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert4);

		// Sending keys on "Delegate to date" as less than 365 days
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		delegateToDate(BaseTest.driver).clear();
		delegateToDate(BaseTest.driver).sendKeys(validDate + Keys.ENTER);
		objBaseTest.logResults(
				"Sending keys on \"Delegate To\" date within 365 days, ( Valid Till Date: " + validDate + " )");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
	}

	/**
	 * Function to raise secondary cwid request
	 * 
	 * @throws InterruptedException
	 */
	public void raisingSecondaryCwidRequest() throws InterruptedException {

		// Clicking on request Secondary CWID Link
		Thread.sleep(6000);
		objBaseTest.clickUsingJavascript(requestSecondaryCWIDLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on request Secondary CWID Link");

		// Sending Keys to Reason for Request

		Thread.sleep(10000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		Thread.sleep(4000);
		reasonForRequest(BaseTest.driver).sendKeys(reasonText);
		objBaseTest.logResults("Sending Keys to Reason for Request");

		// Clicking on Request Secondary CWID button
		requestForSecondaryCWIDButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on request Secondary CWID button");
		Thread.sleep(13000);

	}

	public void validateRequest() throws InterruptedException {

		Thread.sleep(10000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		Thread.sleep(3000);
		String validApproveText = validateReason(BaseTest.driver).getText().trim();
		Assert.assertEquals(validApproveText, reasonText);
		objBaseTest.logResults("Validated that The approval request was sent to new delegate Employee");
		Thread.sleep(2000);
		approveRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on approval button");

	}

	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(3000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

	/**
	 * Function to Check for Request message display
	 * 
	 * @throws InterruptedException
	 */

	public void requestState() throws InterruptedException {

		// Assert to check request message.
		Thread.sleep(5000);
		String requestMessagExpected = "Your request has been submitted successfully.";
		String requestMessagActual = requestMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(requestMessagActual, requestMessagExpected);
		objBaseTest.logResults("Checking request submission message label. " + requestMessagActual);
		Reporter.log("Checking request submission message label. " + requestMessagActual);

	}

}
