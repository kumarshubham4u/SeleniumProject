package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForADAccountCwidPage 
{
	BaseTest objBaseTest = new BaseTest();
	// locators
	private By searchBtnForCWID = By.id("1023662_addbtn");
	private By displayNameTextBox = By.id("gs_1000914_selection-grid-grid_c-40");
	private By selectFirstRowForADRequestCwid = By.xpath("//*[@id='1000914_selection-grid-grid']//tr[2]//td[5]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	private By removeCwidIcon = By.xpath("//*[@id='PanelSection1003864']//a[contains(@class,'remove')]");
	private By nextButton = By.id("btnTrans17704525");
	private By cWIDWithoutADAccount = By.xpath("//*[@id='1023664_ContainerTable']//td//span");
	private By finishButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'Finish')]");
	private By successMessageLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");



	// Returning WebElement from respective locators

	public WebElement searchBtnForCWID(final WebDriver driver)
	{
		return driver.findElement(searchBtnForCWID);
	}
	public WebElement displayNameTextBox(final WebDriver driver)
	{
		return driver.findElement(displayNameTextBox);
	}
	public WebElement selectFirstRowFromTable(final WebDriver driver)
	{
		return driver.findElement(selectFirstRowForADRequestCwid);
	}
	public WebElement okBtnForSelectingCwid(final WebDriver driver)
	{
		return driver.findElement(okBtnForSelectingCwid);
	}
	public WebElement removeCwidIcon(final WebDriver driver)
	{
		return driver.findElement(removeCwidIcon);
	}
	public WebElement nextButton(final WebDriver driver)
	{
		return driver.findElement(nextButton);
	}
	public WebElement cWIDWithoutADAccount(final WebDriver driver)
	{
		return driver.findElement(cWIDWithoutADAccount);
	}
	public WebElement finishButton(final WebDriver driver)
	{
		return driver.findElement(finishButton);
	}
	public WebElement successMessageLabel(final WebDriver driver)
	{
		return driver.findElement(successMessageLabel);
	}
	

	/**
	 *  Function to select CWID from search icon
	 * @param typeOFCWIDToSearch
	 * @throws InterruptedException
	 */
	public void selectingCWIDFromSearchIcon(String typeOFCWIDToSearch) throws InterruptedException
	{
		//Clicking on Search Icon
		objBaseTest.fluentWait();Thread.sleep(10000);
		objBaseTest.scrollInView(searchBtnForCWID(BaseTest.driver));
		searchBtnForCWID(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Search Icon");

		//Entering in Display name Textbox as 'G' for selecting as Secondary CWID
		objBaseTest.fluentWait();Thread.sleep(17000);
		objBaseTest.scrollInView(displayNameTextBox(BaseTest.driver));
		displayNameTextBox(BaseTest.driver).sendKeys(typeOFCWIDToSearch);
		objBaseTest.logResults("Entering in Display name Textbox for selecting as Secondary CWID:-"+typeOFCWIDToSearch);

		//Clicking on enter button using selenium
		objBaseTest.fluentWait();Thread.sleep(2000);
		displayNameTextBox(BaseTest.driver).sendKeys(Keys.ENTER);

		//Selecting first CWID from list 
		objBaseTest.fluentWait();Thread.sleep(12000);
		String requestingCWID = selectFirstRowFromTable(BaseTest.driver).getText();
		System.out.println("requestingCWID"+requestingCWID);
		objBaseTest.logResults("Selecting CWID for AD account as :- "+ requestingCWID);
		selectFirstRowFromTable(BaseTest.driver).click();

		//Clicking on Ok Button 
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(okBtnForSelectingCwid(BaseTest.driver));
		okBtnForSelectingCwid(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Ok Button ");


	}


	/**
	 * Function to remove CWID from textbox
	 * @throws InterruptedException
	 */
	public void removeCwidFromTextBox() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(removeCwidIcon(BaseTest.driver));
		removeCwidIcon(BaseTest.driver).click();
		objBaseTest.logResults("Removing selected Cwid from CWID without AD Account textbox");
	}

	
	/**
	 * Function to click on next button
	 * @throws InterruptedException
	 */
	public void clickingOnNextButton() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(3000);
		objBaseTest.scrollInView(nextButton(BaseTest.driver));
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
	}


	/**
	 * Function to click on Finish button
	 * @throws InterruptedException
	 */
	public void clickingOnFinishButton() throws InterruptedException
	{
		/*
		 * //Getting the CWID without AD Account label value
		 * objBaseTest.fluentWait();Thread.sleep(9000);
		 * objBaseTest.scrollInView(cWIDWithoutADAccount(BaseTest.driver)); String
		 * requestingCWIDADAccount =cWIDWithoutADAccount(BaseTest.driver).getText();
		 * System.out.println("requestingCWIDADAccount"+requestingCWIDADAccount);
		 * objBaseTest.logResults("CWID Account is created for this CWID:-"+
		 * requestingCWIDADAccount);
		 */
		
		//Clicking on finish button
		objBaseTest.fluentWait();Thread.sleep(17000);
		objBaseTest.scrollInView(finishButton(BaseTest.driver));
		objBaseTest.clickUsingJavascript(finishButton(BaseTest.driver));
		//finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish button");
		Thread.sleep(19000);
		objBaseTest.fluentWait();
		
	}

}
