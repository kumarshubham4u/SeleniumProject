package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForRevokeDelegate {

	BaseTest objBaseTest = new BaseTest();

	// Creator locators
	private By revokeGumsRight = By.xpath("//span[(text()='Remove delegation of GUMS rights')]");
	private By nextButton = By.xpath("//input[@value='Next >']");
	private By firstRowDelegate = By.xpath("//table[@id='idContainerRemoved_grid']//td[2]//a");
	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement revokeGumsRight(final WebDriver driver) {
		return driver.findElement(revokeGumsRight);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement firstRowDelegate(final WebDriver driver) {
		return driver.findElement(firstRowDelegate);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}
	
	/**
	 * Function to click on Remove delegation of GUMS rights link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnRevokeGumsRight() throws InterruptedException {
		// Clicking on Remove delegation of GUMS rights link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// revokeGumsRight(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(revokeGumsRight(BaseTest.driver));
		objBaseTest.logResults("Clicking on Remove delegation of GUMS rights link");
	}

	/**
	 * Function to Revoke Rights of Delegate
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void revokingDelegate() throws InterruptedException {

		Thread.sleep(13000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		// Selecting delegate and CLicking on Next button
		String delegate = firstRowDelegate(BaseTest.driver).getText();
		objBaseTest.logResults("Delegate selected to Revoke Rights : " + delegate);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Next button selecting the Delegate");

		// Clicking on Finish button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(2000);
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");
		

	}
	
	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(3000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
