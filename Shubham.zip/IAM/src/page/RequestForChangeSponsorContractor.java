package page;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForChangeSponsorContractor {
	BaseTest objBaseTest = new BaseTest();
	String selectedContractor = null;
	String sponsorCwid = "BBSE1 Zuproweit, Steffi";

	// locators
	private By changeSponsorContractorLink = By.xpath(
			"//span[contains(@title,'change your sponsorship')]//span[contains(text(),'Change Sponsor for Contractor')]");
	private By searchBtnForSponsorCWID = By.id("1034106_btn");
	private By firstRowContractorCwid = By.xpath("//table[@id='roContainerContractor_grid']//tr[2]//td[3]");
	private By firstRowSponsorCwid = By.xpath("//table[@id='1001434_selection-grid-grid']//tr[2]//td[2]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	private By nextButton = By.xpath("//input[@value='Next >']");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By finishButton = By.xpath("//input[@value='Finish']");
	private By searchingCwid = By.xpath("(//table[@class='ui-search-table'])[1]//tr[1]//td[2]//input");
	private By contractorSelectedChkBox = By.xpath("(//table[@id='roContainerContractor_grid']//input)[1]");
	private By tasksApproveRequestLinkapprover = By.xpath(
			"//*[@id='Dashboard1_widget1_content']//tr[1]//td[1]//span[contains(text(),'Change sponsor of contractor')]");
	private By yesRadioButton = By.xpath("//label[contains(text(),'Yes')]");
	private By noRadioButton = By.xpath("//label[contains(text(),'No')]");
	private By commentTextBox = By.id("1014965");

	// Returning WebElement from respective locators

	public WebElement changeSponsorContractorLink(final WebDriver driver) {
		return driver.findElement(changeSponsorContractorLink);
	}

	public WebElement searchBtnForSponsorCWID(final WebDriver driver) {
		return driver.findElement(searchBtnForSponsorCWID);
	}

	public WebElement firstRowContractorCwid(final WebDriver driver) {
		return driver.findElement(firstRowContractorCwid);
	}

	public WebElement firstRowSponsorCwid(final WebDriver driver) {
		return driver.findElement(firstRowSponsorCwid);
	}

	public WebElement okBtnForSelectingCwid(final WebDriver driver) {
		return driver.findElement(okBtnForSelectingCwid);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);
	}

	public WebElement searchingCwid(final WebDriver driver) {
		return driver.findElement(searchingCwid);
	}

	public WebElement contractorSelectedChkBox(final WebDriver driver) {
		return driver.findElement(contractorSelectedChkBox);
	}

	public WebElement tasksApproveRequestLinkapprover(final WebDriver driver) {
		return driver.findElement(tasksApproveRequestLinkapprover);
	}

	public WebElement yesRadioButton(final WebDriver driver) {
		return driver.findElement(yesRadioButton);
	}

	public WebElement noRadioButton(final WebDriver driver) {
		return driver.findElement(noRadioButton);
	}

	public WebElement commentTextBox(final WebDriver driver) {
		return driver.findElement(commentTextBox);
	}

	/****
	 * Function to change Sponsor for contractor
	 * 
	 * @throws InterruptedException
	 */

	public void changeSponsorForContractor() throws InterruptedException {

		// Clicking on change sponsor for password link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLink = BaseTest.driver.findElements(changeSponsorContractorLink);
		chckLink.get(0).click();
		objBaseTest.logResults("Clicking on change sponsor for cotractor link");
		objBaseTest.fluentWait();
		Thread.sleep(3000);

		// Selecting the CWID
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		contractorSelectedChkBox(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		objBaseTest.logResults("Selecting the Contractor");
		selectedContractor = firstRowContractorCwid(BaseTest.driver).getText();
		objBaseTest.logResults("Requesting change for the cwid-:" + selectedContractor);

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Selecting Sponsor
		searchBtnForSponsorCWID(BaseTest.driver).click();
		Thread.sleep(2000);
		searchingCwid(BaseTest.driver).sendKeys(sponsorCwid);
		searchingCwid(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Entered the user Sponsor (CWID) in the search option" + sponsorCwid);
		objBaseTest.fluentWait();
		Thread.sleep(10000);
		firstRowSponsorCwid(BaseTest.driver).click();
		okBtnForSelectingCwid(BaseTest.driver).click();

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Clicking on Finish password process button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish process button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);

	}

	/***
	 * Function to view request for change contractor sponsor
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void viewingRequestForChangeSponsorContractor() throws InterruptedException {
		// clicking on task approval link
		Thread.sleep(17000);
		objBaseTest.fluentWait();
		tasksApproveRequestLinkapprover(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

	}

	/***
	 * Function for approving request
	 * 
	 * @throws InterruptedException
	 */
	public void ApproveRequest() throws InterruptedException {
		yesRadioButton(BaseTest.driver).click();

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Clicking on Finish password process button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish process button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
	}

	/***
	 * Clicking on Reject Button without entering comments
	 *
	 * @return
	 * @throws InterruptedException
	 */

	public void rejectingRequest() throws InterruptedException {
		String rejectionComments = "Required more information";
		noRadioButton(BaseTest.driver).click();

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Entering Comments FOr Rejecting
		commentTextBox(BaseTest.driver).sendKeys(rejectionComments);
		objBaseTest.logResults("Entering Comments FOr Rejecting thee request");
		Thread.sleep(15000);
		objBaseTest.fluentWait();

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Clicking on Finish password process button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish process button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
	}
}
