package page;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForPassswordResetPage {
	BaseTest objBaseTest = new BaseTest();
	String CWIDSelectedForPassswordReset = null;
	String currentPassword = null;
	// locators
	private By resetPasswordLink = By
			.xpath("//span[contains(@title,'reset the password')]//span[contains(text(),'Reset Password')]");
	private By accountRequestTab = By.id("ui-id-3");
	private By searchBtnForCWID = By.id("1024387_btn");
	private By firstRowCwid = By.xpath("//table[@id='1000922_selection-grid-grid']//tr[2]//td[3]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	private By checkBoxForSendingMail = By.id("1030043");
	private By nextButton = By.xpath("//input[@value='Next >']");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By generatedPasswordButton = By.xpath("//input[contains(@value,'Reset Password')]");
	private By newPassword = By.id("1024431");
	private By finishButton = By.xpath("//input[@value='Finish']");
	private By searchingCwid = By.xpath("(//table[@class='ui-search-table'])[2]//tr[1]//td[2]//input");

	// Returning WebElement from respective locators

	public WebElement resetPasswordLink(final WebDriver driver) {
		return driver.findElement(resetPasswordLink);
	}


	public WebElement accountRequestTab(final WebDriver driver) {
		return driver.findElement(accountRequestTab);
	}

	public WebElement searchBtnForCWID(final WebDriver driver) {
		return driver.findElement(searchBtnForCWID);
	}

	public WebElement firstRowCwid(final WebDriver driver) {
		return driver.findElement(firstRowCwid);
	}

	public WebElement okBtnForSelectingCwid(final WebDriver driver) {
		return driver.findElement(okBtnForSelectingCwid);
	}

	public WebElement checkBoxForSendingMail(final WebDriver driver) {
		return driver.findElement(checkBoxForSendingMail);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement generatedPasswordButton(final WebDriver driver) {
		return driver.findElement(generatedPasswordButton);
	}

	public WebElement newPassword(final WebDriver driver) {
		return driver.findElement(newPassword);
	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);
	}

	public WebElement searchingCwid(final WebDriver driver) {
		return driver.findElement(searchingCwid);
	}

	/****
	 * Function to run Reset Password Password
	 * 
	 * @throws InterruptedException
	 */

	public void runningResetPasswordProcess(String emailRequired, String tabOfServiceLink) throws InterruptedException {

		if (tabOfServiceLink.equalsIgnoreCase("secondTab")) {

			// Changing the tab inside service Link
			objBaseTest.fluentWait();
			Thread.sleep(4000);
			accountRequestTab(BaseTest.driver).click();
			objBaseTest.logResults("Account Request Tab Opened");
		}
		// Clicking on reset password link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLink = BaseTest.driver.findElements(resetPasswordLink);
		chckLink.get(0).click();
		objBaseTest.logResults("Clicking on reset password link");
		objBaseTest.fluentWait();
		Thread.sleep(3000);

		// clicking on search button for searching the cwid
		searchBtnForCWID(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		objBaseTest.logResults("clicking on search button for searching the cwid");

		// Method for password reset via admin for your choice of cwid
		if (tabOfServiceLink.equalsIgnoreCase("firstTab")) {
			searchingCWIDProcessAfterIdentification();
		}

		// Storing the value of the CWID for which password has been reset
		objBaseTest.clickUsingJavascript(firstRowCwid(BaseTest.driver));
		CWIDSelectedForPassswordReset = firstRowCwid(BaseTest.driver).getText();
		objBaseTest.logResults("Requesting for password reset for the cwid-:" + CWIDSelectedForPassswordReset);
		okBtnForSelectingCwid(BaseTest.driver).click();

		if (emailRequired.equalsIgnoreCase("with_Email")) {
			// Clicking on Checkbox for sending mail
			objBaseTest.fluentWait();
			Thread.sleep(1000);
			objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
			checkBoxForSendingMail(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on Checkbox for sending  mail");
		}

		// Clicking on next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

		// Clicking on generated password button
		Thread.sleep(1000);
		generatedPasswordButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on generated password button");
		Thread.sleep(4000);
		objBaseTest.fluentWait();

		if (emailRequired.equalsIgnoreCase("without_Email")) {
			// Storing the new value of password
			currentPassword = newPassword(BaseTest.driver).getAttribute("value").trim();
			objBaseTest.logResults(
					"New generated password for the cwid" + CWIDSelectedForPassswordReset + "is -:" + currentPassword);
		}

		// Clicking on Finish password process button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Finish password process button");
		objBaseTest.fluentWait();
		Thread.sleep(10000);
	}

	/****
	 * Function for Entering the user input (CWID) in the search option
	 * 
	 * @throws InterruptedException
	 */
	public void searchingCWIDProcessAfterIdentification() throws InterruptedException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the value of cwid for which you want to reset the password");
		String input = scanner.nextLine();
		objBaseTest.fluentWait();
		Thread.sleep(25000);

		searchingCwid(BaseTest.driver).sendKeys(input);
		searchingCwid(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Entered the user input (CWID) in the search option");
		objBaseTest.fluentWait();
		Thread.sleep(10000);
	}

}
