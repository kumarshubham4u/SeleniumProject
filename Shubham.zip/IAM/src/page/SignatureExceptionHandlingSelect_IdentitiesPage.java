package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import commonFunctions.BaseTest;

public class SignatureExceptionHandlingSelect_IdentitiesPage 
{

	BaseTest objBaseTest = new BaseTest();
	//Locators
	private By searchBtnForCWID = By.id("1024591_addbtn");
	private By selectFirstRowFromTable = By.xpath("//*[@id='1000931_selection-grid-grid']//tr[2]//td[4]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	private By dropDownReason = By.id("1024592");
	private By additionalReasonTxtbox = By.id("1024593");
	private By nextButton = By.id("btnTrans17845249");
	private By emptyValuePopUpMessageLabel = By.id("ui-id-1");
	private By additionalReasonView = By.id("1024597");
	private By finishButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'Finish')]");
	private By successMessageLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
	private By emptyValuePopUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	

	// Returning WebElement from respective locators
	public WebElement searchBtnForCWID(final WebDriver driver)
	{
		return driver.findElement(searchBtnForCWID);
	}
	public WebElement selectFirstRowFromTable(final WebDriver driver)
	{
		return driver.findElement(selectFirstRowFromTable);
	}
	public WebElement okBtnForSelectingCwid(final WebDriver driver)
	{
		return driver.findElement(okBtnForSelectingCwid);
	}
	public WebElement dropDownReason(final WebDriver driver)
	{
		return driver.findElement(dropDownReason);
	}
	public WebElement AdditionalReasonTxtbox(final WebDriver driver)
	{
		return driver.findElement(additionalReasonTxtbox);
	}
	public WebElement nextButton(final WebDriver driver)
	{
		return driver.findElement(nextButton);
	}
	public WebElement emptyValuePopUpMessageLabel(final WebDriver driver)
	{
		return driver.findElement(emptyValuePopUpMessageLabel);
	}
	public WebElement additionalReasonView(final WebDriver driver)
	{
		return driver.findElement(additionalReasonView);
	}
	
	public WebElement finishButton(final WebDriver driver)
	{
		return driver.findElement(finishButton);
	}
	public WebElement successMessageLabel(final WebDriver driver)
	{
		return driver.findElement(successMessageLabel);
	}
	public WebElement emptyValuePopUpMessageOkButton(final WebDriver driver)
	{
		return driver.findElement(emptyValuePopUpMessageOkButton);
	}


	/**
	 * Function to select CWID from search icon
	 * @return
	 * @throws InterruptedException
	 */
	public String selectingCWIDFromSearchIcon() throws InterruptedException
	{
		//Clicking on Search Icon
		objBaseTest.fluentWait();Thread.sleep(8000);
		objBaseTest.scrollInView(searchBtnForCWID(BaseTest.driver));
		searchBtnForCWID(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Search Icon");

		//Selecting first CWID from list 
		objBaseTest.fluentWait();Thread.sleep(10000);
		String requestingCWID = selectFirstRowFromTable(BaseTest.driver).getText();
		System.out.println("requestingCWID"+requestingCWID);
		objBaseTest.logResults("Selecting CWID for Signature Exception Handling as :- "+ requestingCWID);
		selectFirstRowFromTable(BaseTest.driver).click();

		//Clicking on Ok Button 
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(okBtnForSelectingCwid(BaseTest.driver));
		okBtnForSelectingCwid(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Ok Button ");
		
		return requestingCWID;
	}

	/**
	 * Function to select dropdown from Reason field
	 * @param enterReason
	 * @throws InterruptedException
	 */
	public void selectingReasonDropdown(String enterReason) throws InterruptedException
	{
		String dropDownValue="Additional reasons";
		objBaseTest.fluentWait();Thread.sleep(3000);
		objBaseTest.scrollInView(dropDownReason(BaseTest.driver));

		Select reasonDropdown = new Select(dropDownReason(BaseTest.driver));  
		reasonDropdown.selectByVisibleText(dropDownValue); 
		objBaseTest.logResults("selecting dropdown from Reason field :-" +dropDownValue);

		//When dropdown value is Additional reasons than only Addition Reason Field gets enabled
		if(dropDownValue.equalsIgnoreCase("Additional reasons"))
		{
			objBaseTest.fluentWait();Thread.sleep(3000);
			objBaseTest.scrollInView(AdditionalReasonTxtbox(BaseTest.driver));
			AdditionalReasonTxtbox(BaseTest.driver).sendKeys(enterReason);
			objBaseTest.logResults("Entering Additional reason field");
		}
	}


	/**
	 * Function to click on next button
	 * @throws InterruptedException
	 */
	public void clickNextButton() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(3000);
		objBaseTest.scrollInView(nextButton(BaseTest.driver));
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");
	}


	/**
	 * Function clicking on Next button without entering fields
	 * @return
	 * @throws InterruptedException
	 */
	public String clickingNextButtonWithoutEnteringFields() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(nextButton(BaseTest.driver));
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when not filling mandatory fields
		objBaseTest.fluentWait();Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = emptyValuePopUpMessageLabel(BaseTest.driver).getText().trim();
		emptyValuePopUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on next button without entering mandatory fields");
		return emptyValuePopUpMessageLabelActual;
	}
	
	
	/**
	 * Function to click on finish button 
	 * @throws InterruptedException
	 */
	public void clickingFinishButton() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(12000);
		objBaseTest.scrollInView(additionalReasonView(BaseTest.driver));
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");
		Thread.sleep(19000);
		objBaseTest.fluentWait();
	}
}
