package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForInitiateContractorOnboard {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;
	// Creator locators
	private By initiateOnboardLink = By.xpath("//span[(text()='Initiate Onboard contractor GUMS Non�GHR')]");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value=' Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value=' < Back ']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By firstName = By.xpath("//input[@id='1016769']");
	private By lastName = By.xpath("//input[@id='1016770']");
	private By extCompanyName = By.xpath("//input[@id='1016762']");
	private By sponsorCWID = By.xpath("//input[@id='1018199']");
	private By validToDate = By.xpath("//input[@id='1016775']");
	private By extEmail = By.xpath("//input[@id='1025158']");
	private By extMobileCountryCode = By.xpath("//input[@id='EXT_MOBILE_COUNTRY']");
	private By extMobilePrefix = By.xpath("//input[@id='EXT_MOBILE_PREFIX']");
	private By extMobileNumber = By.xpath("//input[@id='EXT_CELLPHONE']");
	private By cwidGenerated = By
			.xpath("//td[@class='CtrlAndImgBtn_CtrlCell'] //div[@class='selectize-control TBSL multi'] //span");

	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");

	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement initiateOnboardLink(final WebDriver driver) {
		return driver.findElement(initiateOnboardLink);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement firstName(final WebDriver driver) {
		return driver.findElement(firstName);
	}

	public WebElement lastName(final WebDriver driver) {
		return driver.findElement(lastName);
	}

	public WebElement extCompanyName(final WebDriver driver) {
		return driver.findElement(extCompanyName);
	}

	public WebElement sponsorCWID(final WebDriver driver) {
		return driver.findElement(sponsorCWID);
	}

	public WebElement validToDate(final WebDriver driver) {
		return driver.findElement(validToDate);
	}

	public WebElement extEmail(final WebDriver driver) {
		return driver.findElement(extEmail);
	}

	public WebElement extMobileCountryCode(final WebDriver driver) {
		return driver.findElement(extMobileCountryCode);
	}

	public WebElement extMobilePrefix(final WebDriver driver) {
		return driver.findElement(extMobilePrefix);
	}

	public WebElement extMobileNumber(final WebDriver driver) {
		return driver.findElement(extMobileNumber);
	}

	public WebElement cwidGenerated(final WebDriver driver) {
		return driver.findElement(cwidGenerated);
	}

	
	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on Initiate Onboard contractor GUMS Non�GHR
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnInitiateOnboardLink() throws InterruptedException {
		// Clicking on Initiate On-board contractor GUMS Non�GHR
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// initiateOnboardLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(initiateOnboardLink(BaseTest.driver));
		objBaseTest.logResults("Initiate Onboard contractor GUMS Non GHR");
	}

	/**
	 * Function clicking on Next button without entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButtonWithoutEnteringFields() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(7000);
		objBaseTest.scrollInView(nextButton(BaseTest.driver));
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

	}

	/**
	 * Function clicking on Next button after entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButtonAfterEnteringFields() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after entering fields");
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		objBaseTest.logResults("Accepting the pop up of duplicate Name for generating CWID");

		// Clicking on Next button after verifying the Final form
		objBaseTest.explicitWait(backButton);
		Thread.sleep(4000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after verifying the Final form");

	}

	/**
	 * Function Getting the generated CWID and clicking on Finish button without
	 * entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingFinishButton() throws InterruptedException {
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(6000);
		// Getting Generated CWID
		String[] cwid = cwidGenerated(BaseTest.driver).getText().split(" ");
		objBaseTest.logResults("Generated CWID : " + cwid[0]);
		// Clicking on Finish button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");

	}

	/**
	 * Function to send keys on first Name
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnFirstName() throws InterruptedException {
		// Sending Keys on first Name
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		firstName(BaseTest.driver).sendKeys("TestFirst");
		objBaseTest.logResults("Sending Keys for first Name");
	}

	/**
	 * Function to send keys on last Name
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnLastName() throws InterruptedException {
		// Sending Keys on last Name
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(firstName(BaseTest.driver));
		lastName(BaseTest.driver).sendKeys("TestLast");
		objBaseTest.logResults("Sending Keys for last Name");
	}

	/**
	 * Function to send keys on external Company Name
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtCompanyName() throws InterruptedException {
		// Sending Keys on external Company Name
		Thread.sleep(1000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(lastName(BaseTest.driver));
		extCompanyName(BaseTest.driver).sendKeys("Test ext. company");
		objBaseTest.logResults("Sending Keys for external Company Name");
	}

	/**
	 * Function to send keys on search Sponser CWID lookup
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnSponsorCWIDLookup() throws InterruptedException {
		// Sending Keys for search Sponser CWID
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		sponsorCWID(BaseTest.driver).sendKeys("BBSS1" + Keys.TAB);
		objBaseTest.logResults("Sending Keys for search Sponser CWID");
	}

	/**
	 * Function to send keys on Valid To Date
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnValidToDate() throws InterruptedException {
		// Sending Keys on validToDate
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Valid To Date" as more than 365 to check Expection
		validToDate(BaseTest.driver).sendKeys("04/25/2026" + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" date as more than 365 to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert1 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending keys on "Valid To Date" as Past Date
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		validToDate(BaseTest.driver).sendKeys("04/25/2010" + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" as Past Date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert2 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

		// Sending keys on "Valid To Date" as a date within 365 days
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		validToDate(BaseTest.driver).sendKeys("04/14/2021" + Keys.ENTER); // Valid for Test script running till 14th
																			// April 2021
		objBaseTest.logResults("Sending keys on \"Valid To\" as date within 365 days (Valid Till 04/14/2021)");

	}

	/**
	 * Function to send keys on External Email field
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtEmail() throws InterruptedException {
		// Sending Keys on external email as a Bayer email id
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(extEmail(BaseTest.driver));
		extEmail(BaseTest.driver).sendKeys("testing@bayer.com");
		objBaseTest.logResults("Sending Keys for external email as a Bayer email id to check for Validation error");
		Thread.sleep(1000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		objBaseTest.logResults("Accepting the pop up of duplicate Name for generating CWID");

		// Getting the text of Warning popup modal window when filling the External
		// Email as internal bayer mail id

		objBaseTest.explicitWait(popUpMessageLabel);
		Thread.sleep(2000);
		String extEmailValidation = popUpMessageLabel(BaseTest.driver).getText();
		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + extEmailValidation);

		// Sending Keys on external email as a external mail id
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(extEmail(BaseTest.driver));
		extEmail(BaseTest.driver).clear();
		extEmail(BaseTest.driver).sendKeys("testing@capgemini.com");
		objBaseTest.logResults("Sending Keys for external email as an external mail id");

	}

	/**
	 * Function to send keys on External Mobile Country Code
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobileCountryCode() throws InterruptedException {
		// Sending Keys on external Mobile Country Code as invalid
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).sendKeys("8972");
		objBaseTest
				.logResults("Sending Keys for External Mobile Country Code as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Country code as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Country Code\" could not be validated");

		// Sending Keys on external Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for external mobile country code as valid");

	}

	/**
	 * Function to send keys on External Mobile Prefix
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobilePrefix() throws InterruptedException {
		// Sending Keys on external Mobile Prefix as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).sendKeys("abcd123");
		objBaseTest.logResults("Sending Keys for External Mobile Prefix as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Number\" could not be validated");

		// Sending Keys on external Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("9876");
		objBaseTest.logResults("Sending Keys for external mobile prefix as valid");

	}

	/**
	 * Function to send keys on External Mobile Number
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobileNumber() throws InterruptedException {
		// Sending Keys on external Mobile Number as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).sendKeys("wxyz123");
		objBaseTest.logResults("Sending Keys for External Mobile Number as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Number\" could not be validated");

		// Sending Keys on external Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("765890");
		objBaseTest.logResults("Sending Keys for external mobile number as valid");
	}

	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(3000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
