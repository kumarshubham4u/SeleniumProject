package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import commonFunctions.BaseTest;

public class RequestForNewAccountLDAPBySponsorPage {
	BaseTest objBaseTest = new BaseTest();
	String password="PASSWORD";

	// locators
	private By tasksApproveRequestLinkapprover = By.xpath(
			"//*[@id='Dashboard1_widget1_content']//tr[1]//td[1]//span[contains(text(),'Approve request for new Account')]");
	private By tasksApproveRequestLinkrequestor = By.xpath(
			"//*[@id='Dashboard1_widget1_content']//tr[1]//td[1]//span[contains(text(),'Set initial password')]");
	private By approveRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1)')]");
	private By declineRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'2) Decline')]");
	private By successMessageForApproverLabel = By
			.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
	private By reasonForRejectionComments = By.id("1002934");
	private By sendCommentsToRequestButton = By
			.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Send comments to requestor')]");
	private By rejectionPopUpMessageLabel = By.id("ui-id-1");
	private By rejectionPopUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By setPasswordFrame = By.id("passwordIFrame");
	private By savePasswordBtn = By.id("btnSave");
	private By passwordTextBox = By.id("passwordField");
	private By confirmPasswordTextBox = By.id("confirmPasswordField");
	private By continueButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Continue')]");
	

	// Returning WebElement from respective locators
	public WebElement tasksApproveRequestLinkapprover(final WebDriver driver) {
		return driver.findElement(tasksApproveRequestLinkapprover);
	}

	public WebElement tasksApproveRequestLinkrequestor(final WebDriver driver) {
		return driver.findElement(tasksApproveRequestLinkrequestor);
	}

	public WebElement approveRequestButton(final WebDriver driver) {
		return driver.findElement(approveRequestButton);
	}

	public WebElement declineRequestButton(final WebDriver driver) {
		return driver.findElement(declineRequestButton);
	}

	public WebElement successMessageForApproverLabel(final WebDriver driver) {
		return driver.findElement(successMessageForApproverLabel);
	}

	public WebElement reasonForRejectionComments(final WebDriver driver) {
		return driver.findElement(reasonForRejectionComments);
	}

	public WebElement sendCommentsToRequestButton(final WebDriver driver) {
		return driver.findElement(sendCommentsToRequestButton);
	}

	public WebElement rejectionPopUpMessageLabel(final WebDriver driver) {
		return driver.findElement(rejectionPopUpMessageLabel);
	}

	public WebElement rejectionPopUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(rejectionPopUpMessageOkButton);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement setPasswordFrame(final WebDriver driver) {
		return driver.findElement(setPasswordFrame);
	}
	
	public WebElement passwordTextBox(final WebDriver driver) {
		return driver.findElement(passwordTextBox);
	}
	
	public WebElement confirmPasswordTextBox(final WebDriver driver) {
		return driver.findElement(confirmPasswordTextBox);
	}
	
	public WebElement savePasswordBtn(final WebDriver driver) {
		return driver.findElement(savePasswordBtn);
	}
	
	public WebElement continueButton(final WebDriver driver) {
		return driver.findElement(continueButton);
	}
	
	
	
	/***
	 * Function to view new account request
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void viewingNewAccountRequest(String designation) throws InterruptedException {
		// clicking on task approval link
		Thread.sleep(17000);
		objBaseTest.fluentWait();
		if (designation.equalsIgnoreCase("Approver")) {
			tasksApproveRequestLinkapprover(BaseTest.driver).click();
			objBaseTest.fluentWait();
			Thread.sleep(15000);
			objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		}
		tasksApproveRequestLinkrequestor(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));

	}

	/***
	 * Clicking on Approver Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingApproverButton() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(10000);
		objBaseTest.scrollInView(approveRequestButton(BaseTest.driver));
		approveRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on approve request button.");
		Thread.sleep(18000);
		objBaseTest.fluentWait();
	}

	/***
	 * Clicking on Reject Button without entering comments
	 *
	 * @return
	 * @throws InterruptedException
	 */

	public String clickingRejectButtonWithOutEnteringComments() throws InterruptedException {

		objBaseTest.fluentWait();
		Thread.sleep(10000);
		objBaseTest.scrollInView(declineRequestButton(BaseTest.driver));
		declineRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on decline request button.");

		Thread.sleep(6000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(reasonForRejectionComments(BaseTest.driver));
		sendCommentsToRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on send Comments To Request Button without entering any comments");
		Thread.sleep(1000);

		// Getting the text of Warning popup modal window
		String rejectionPopUpMessageLabelActual = rejectionPopUpMessageLabel(BaseTest.driver).getText().trim();
		rejectionPopUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on rejection PopUp Message Ok Button");

		return rejectionPopUpMessageLabelActual;

	}

	/****
	 * Clicking on send Comments To Request Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingRejectButtonWithEnteringComments() throws InterruptedException {
		String rejectionComments = "Required more information";
		reasonForRejectionComments(BaseTest.driver).sendKeys(rejectionComments);
		objBaseTest.logResults("Entering Reason For Rejection Comments field as " + rejectionComments);

		sendCommentsToRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on send Comments To Request Button");
		Thread.sleep(15000);
		objBaseTest.fluentWait();

	}

	/***
	 * Function to scroll
	 * 
	 * @throws InterruptedException
	 */
	public void scrollToBottom() throws InterruptedException {
		
	}

	public void setPasswordForLDAPAccount () throws InterruptedException{
		BaseTest.driver.switchTo().frame(setPasswordFrame(BaseTest.driver));
		Thread.sleep(6000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(savePasswordBtn(BaseTest.driver));
		passwordTextBox(BaseTest.driver).sendKeys(password);
		confirmPasswordTextBox(BaseTest.driver).sendKeys(password);
		Thread.sleep(1000);
		savePasswordBtn(BaseTest.driver).click();
		BaseTest.driver.switchTo().defaultContent();
		Thread.sleep(1000);
		continueButton(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(15000);
	}
	
	
}
