package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForOffboardPartner {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;
	// Creator locators
	private By offboardPartnerID = By.xpath("//a[contains(text(),'Offboard Partner-ID')]");
	private By acceptYes = By.xpath("//label[contains(text(),'Yes')]");
	private By acceptNo = By.xpath("//label[contains(text(),'No')]");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By nextButton = By.xpath("//input[@value=' Next >']");
	private By comments = By.xpath("//textarea[@id='1023005']");
	private By viewAllRequest = By.xpath("//div[@id='Dashboard1_widget1_header']//span[text()='View all >']");
	private By finishbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value=' Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement offboardPartnerID(final WebDriver driver) {
		return driver.findElement(offboardPartnerID);

	}

	public WebElement acceptYes(final WebDriver driver)

	{
		return driver.findElement(acceptYes);
	}

	public WebElement acceptNo(final WebDriver driver)

	{
		return driver.findElement(acceptNo);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement comments(final WebDriver driver) {
		return driver.findElement(comments);

	}

	public WebElement viewAllRequest(final WebDriver driver)

	{
		return driver.findElement(viewAllRequest);
	}

	public WebElement finishbutton(final WebDriver driver) {
		return driver.findElement(finishbutton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on View all Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnViewAllRequest() throws InterruptedException {
		Thread.sleep(16000);
		viewAllRequest(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on View all Button");

	}

	/**
	 * Function to Click on Off-board Partner ID Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnOffboardPartnerID() throws InterruptedException {
		// Clicking on Off-board Partner ID Link

		objBaseTest.explicitWait(offboardPartnerID);
		Thread.sleep(2000);
		objBaseTest.clickUsingJavascript(offboardPartnerID(BaseTest.driver));
		objBaseTest.logResults("Clicking on Off-board Partner ID Link");

	}

	/**
	 * Function to Extend Valid To date
	 * 
	 * @throws InterruptedException
	 */
	public void extendValidToDate() throws InterruptedException {
		// Clicking on Accept Yes radio button
		Thread.sleep(13000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		acceptYes(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Yes radio button To Extend Valid To Date");
		// Sending Keys on Comment box
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		comments(BaseTest.driver).clear();
		Thread.sleep(1000);
		comments(BaseTest.driver).sendKeys("This is a test to extend Valid To date");
		objBaseTest.logResults("Sending Keys on Comments box");
		Thread.sleep(2000);
		// Clicking on Next button
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");

	}

	/**
	 * Function to Not Extend Valid To date
	 * 
	 * @throws InterruptedException
	 */
	public void notExtendValidToDate() throws InterruptedException {
		// Clicking on Accept No radio button

		Thread.sleep(13000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		acceptNo(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on No radio button To Not Extend Valid To Date");

		// Sending Keys on Comment box
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		comments(BaseTest.driver).clear();
		Thread.sleep(1000);
		comments(BaseTest.driver).sendKeys("This is a test to not extend Valid To date");
		objBaseTest.logResults("Sending Keys on Comments box");
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
	}

	/**
	 * Function to Click on Finish button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishbutton() throws InterruptedException {
		// Clicking on finish button
		objBaseTest.explicitWait(finishbutton);
		Thread.sleep(2000);
		// finishbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on finish button");
		Thread.sleep(10000);
	}

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
