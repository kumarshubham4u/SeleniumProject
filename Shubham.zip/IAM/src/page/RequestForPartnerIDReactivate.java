package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForPartnerIDReactivate {

	BaseTest objBaseTest = new BaseTest();

	String sponser = "BBSS1";
	String pastDate = "04/04/2019";
	String futureDate = "04/04/2050";
	

	// Creator locators
	private By reactivatePartnerIDLink = By.xpath("//span[(text()='Reactivate Partner ID')]");
	private By externalCollaboration = By.xpath("//label[contains(text(),'External Collaboration (incl. GridCard)')]");
	private By sharepointOnline = By.xpath("//label[contains(text(),'Sharepoint Online')]");
	private By email = By.xpath("//input[@id='1029541']");

	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='< Back']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By sponsorCWID = By.xpath("//input[@id='1034057_textbox-selectized']");
	private By searchPIDbutton = By.xpath("//img[@id='1034056_btn']");
	private By firstRowPID = By.xpath("//table[@id='1001255_selection-grid-grid']//tbody/tr[2]/td[2]");
	private By okButton = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='OK']");
	
	private By validFromDate = By.xpath("//input[@id='1029542']");
	private By validToDate = By.xpath("//input[@id='1029543']");
	private By calenderNext = By.xpath("//span[(text()='Next')]");
	private By validDate = By.xpath("//a[(text()='11')]");
	private By processIdSpan = By.xpath("//span[(text()='SID.PIR2.V01')]");

	private By extMobileCountryCode = By.xpath("//input[@id='MOBILE_COUNTRY']");
	private By extMobilePrefix = By.xpath("//input[@id='MOBILE_PREFIX']");
	private By extMobileNumber = By.xpath("//input[@id='CELLPHONE']");
	private By pidGenerated = By
			.xpath("//td[@class='CtrlAndImgBtn_CtrlCell'] //div[@class='selectize-control TBSL multi'] //span");

	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");

	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement reactivatePartnerIDLink(final WebDriver driver) {
		return driver.findElement(reactivatePartnerIDLink);

	}

	public WebElement externalCollaboration(final WebDriver driver)

	{
		return driver.findElement(externalCollaboration);
	}

	public WebElement sharepointOnline(final WebDriver driver)

	{
		return driver.findElement(sharepointOnline);
	}

	public WebElement email(final WebDriver driver)

	{
		return driver.findElement(email);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement sponsorCWID(final WebDriver driver) {
		return driver.findElement(sponsorCWID);
	}

	public WebElement searchPIDbutton(final WebDriver driver) {
		return driver.findElement(searchPIDbutton);
	}

	public WebElement firstRowPID(final WebDriver driver) {
		return driver.findElement(firstRowPID);
	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);
	}
	
	public WebElement validFromDate(final WebDriver driver) {
		return driver.findElement(validFromDate);
	}

	public WebElement validToDate(final WebDriver driver) {
		return driver.findElement(validToDate);
	}

	public WebElement calenderNext(final WebDriver driver) {
		return driver.findElement(calenderNext);
	}

	public WebElement validDate(final WebDriver driver) {
		return driver.findElement(validDate);
	}

	public WebElement processIdSpan(final WebDriver driver) {
		return driver.findElement(processIdSpan);
	}

	public WebElement extMobileCountryCode(final WebDriver driver) {
		return driver.findElement(extMobileCountryCode);
	}

	public WebElement extMobilePrefix(final WebDriver driver) {
		return driver.findElement(extMobilePrefix);
	}

	public WebElement extMobileNumber(final WebDriver driver) {
		return driver.findElement(extMobileNumber);
	}

	public WebElement pidGenerated(final WebDriver driver) {
		return driver.findElement(pidGenerated);
	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on Reactivate Partner ID Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnReactivatePartnerIDLink() throws InterruptedException {
		// Clicking on Reactivate Partner ID Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// reactivatePartnerIDLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(reactivatePartnerIDLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Reactivate Partner ID Link");
	}

	/**
	 * Function to click on Next button without entering mandatory fields
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnNextButton() throws InterruptedException {
		// Clicking on Next button without entering Mandatory Fields
		objBaseTest.explicitWait(sponsorCWID);
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);
	}

	/**
	 * Function for Sending Keys for search Sponser CWID
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnSponsorCWID() throws InterruptedException {

		// Sending Keys for search Sponsor CWID
		Thread.sleep(2000);
		sponsorCWID(BaseTest.driver).sendKeys(sponser);
		Thread.sleep(4000);
		sponsorCWID(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Sending Keys for search Sponser CWID");
	}

	/**
	 * Function to Select Partner ID
	 * 
	 * @throws InterruptedException
	 */
	public void selectPartnerID() throws InterruptedException {
		// Clicking on Search Partner ID button
		Thread.sleep(2000);
		searchPIDbutton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Search Partner ID button");
		Thread.sleep(5000);

		// Selecting First Row PID
		objBaseTest.clickUsingJavascript(firstRowPID(BaseTest.driver));
		String[] SelectedPID = firstRowPID(BaseTest.driver).getText().split(" ");
		objBaseTest.logResults("Selecting Partner ID : " + SelectedPID[0]);

		// Clicking on OK button
		Thread.sleep(1000);
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on OK button");

		// Clicking on Next button
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

	}

	/**
	 * Function to Check Exceptions
	 * 
	 * @throws InterruptedException
	 */
	public void checkValidation() throws InterruptedException {

		// Sending Keys on Mobile Country Code as invalid
		
		Thread.sleep(15000);
		objBaseTest.scrollInView(processIdSpan(BaseTest.driver));
		extMobileCountryCode(BaseTest.driver).clear();
		Thread.sleep(2000);
		extMobileCountryCode(BaseTest.driver).sendKeys("8972");
		objBaseTest.logResults("Sending Keys for Mobile Country Code as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Country code as invalid

		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Country Code\" could not be validated");

		// Sending Keys on Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for mobile country code as valid");

		// Sending Keys on Mobile Prefix as invalid
		Thread.sleep(2000);
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("abcd123");
		objBaseTest.logResults("Sending Keys for External Mobile Prefix as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("9876");
		objBaseTest.logResults("Sending Keys for mobile prefix as valid");

		// Sending Keys on Mobile Number as invalid

		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("wxyz123");
		objBaseTest.logResults("Sending Keys for External Mobile Number as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid

		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("765890");
		objBaseTest.logResults("Sending Keys for external mobile number as valid");

		// Sending Keys on validToDate
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Valid To Date" as more than 365 to check Expection
		validToDate(BaseTest.driver).clear();
		Thread.sleep(1000);
		validToDate(BaseTest.driver).sendKeys(futureDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" date as more than 365 to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		objBaseTest.explicitWait(popUpMessageOkButton);
		String alert1 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending keys on "Valid To Date" as Past Date
		objBaseTest.scrollInView(validToDate(BaseTest.driver));
		validToDate(BaseTest.driver).clear();
		validToDate(BaseTest.driver).sendKeys(pastDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" as Past Date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		objBaseTest.explicitWait(popUpMessageOkButton);
		String alert2 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

	}

	/**
	 * Function to Reactivate Partner ID
	 * 
	 * @throws InterruptedException
	 */
	public void reactivatePartnerID() throws InterruptedException {
		
		objBaseTest.scrollInView(validToDate(BaseTest.driver));
		Thread.sleep(2000);
		validToDate(BaseTest.driver).clear();
		validFromDate(BaseTest.driver).click();
		Thread.sleep(2000);
		validToDate(BaseTest.driver).click();

		// Selecting a valid date within 3 months
		for (int i = 0; i < 3; i++) {
			calenderNext(BaseTest.driver).click();
			Thread.sleep(1000);
		}
		validDate(BaseTest.driver).click();
		objBaseTest.logResults("Selecting a Valid Date within 3 months");
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after entering fields");
		
		//Clicking on Finish button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(2000);
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button after verifying the Final Form");

	}


	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(3000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
