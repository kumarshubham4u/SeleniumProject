package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForRestoreArchievedCwid {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;

	// Creator locators
	private By restoreArchiveCwidLink = By.xpath("//span[(text()='Restore Archived CWID')]");
	private By searchButton = By.xpath("//img[@id='1022196_btn']");
	private By firstRowSelect = By.xpath("//table[@id='1000863_selection-grid-grid']//tr[2]//td[2]");
	private By okButton = By.xpath("//button[text()='OK']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='< Back']");
	private By finishbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	
	
	// Returning WebElement from respective locators

	public WebElement restoreArchiveCwidLink(final WebDriver driver) {
		return driver.findElement(restoreArchiveCwidLink);

	}

	public WebElement searchButton(final WebDriver driver) {
		return driver.findElement(searchButton);

	}



	public WebElement firstRowSelect(final WebDriver driver) {
		return driver.findElement(firstRowSelect);

	}

	
	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}


	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishbutton(final WebDriver driver) {
		return driver.findElement(finishbutton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}




	/**
	 * Function for Clicking on Restore Archived Cwid Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnRestoreArchieveCwidLink() throws InterruptedException {
		// Clicking on Change Employee CWID to Contractor-CWID Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// restoreArchiveCwidLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(restoreArchiveCwidLink(BaseTest.driver));
		objBaseTest.logResults(" Clicking on Restore Archived Cwid Link");
	}

	/**
	 * Function to click on search Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchButton() throws InterruptedException {
		// Clicking on search Button
		objBaseTest.explicitWait(searchButton);
		Thread.sleep(2000);
		// searchButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on search Button to select Employee");
	}

	/**
	 * Function to Select first row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowSelect() throws InterruptedException {
		
		// Clicking on first row CWID
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// firstRowSelect(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowSelect(BaseTest.driver));
		selectedCWID = firstRowSelect(BaseTest.driver).getText();
		objBaseTest.logResults("Requested Archived cwid :  " + selectedCWID);
		// Clicking on Ok button
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
		Thread.sleep(3000);
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next button");

	}

	/**
	 * Function to Click on Finish button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishbutton() throws InterruptedException {
		// Clicking on finish button
		Thread.sleep(10000);
		// finishbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on finish button");
	}

	/**
	 * Function to Select Future Sponsor
	 * 
	 * @throws InterruptedException
	 */
	public void restoringArchivedCwid() throws InterruptedException {

		objBaseTest.explicitWait(backButton);
		Thread.sleep(2000);
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next button after validating the final Form");
	}



	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
