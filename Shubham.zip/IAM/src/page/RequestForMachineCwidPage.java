package page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;
/**
 * @author ELGNF
 *
 */
public class RequestForMachineCwidPage {
	BaseTest objBaseTest = new BaseTest();

	// locators
	private By requestMachineCWIDLink = By.xpath(
			"//span[contains(text(),'Request  Machine CWID')]");
	private By reasonForRequest = By.id("1001454");
	private By checboxAD_Account = By.id("1023700");
	private By requestForMachineCWIDButton = By.id("btnTrans1001187");
	private By successMessageLabel = By.xpath(
			"//span[@id='PageMsgsContnr']//td[contains(text(),'Your request has been submitted successfully.')]");
	
	// Returning WebElement from respective locators 

	public WebElement requestMachineCWIDLink(final WebDriver driver) {
		return driver.findElement(requestMachineCWIDLink);
	}

	public WebElement reasonForRequest(final WebDriver driver) {
		return driver.findElement(reasonForRequest);
	}

	public WebElement checboxAD_Account(final WebDriver driver) {
		return driver.findElement(checboxAD_Account);
	}

	public WebElement requestForMachineCWIDButton(final WebDriver driver) {
		return driver.findElement(requestForMachineCWIDButton);
	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);
	}

	
	
	/**
	 * Function to create Machine CWID
	 * 
	 * @param reasonForRequestEntered
	 * @param ADAccount
	 * @throws InterruptedException
	 */
	
	public void creatingMachineCWIDLink(String reasonForRequestEntered, String ADAccount)
			throws InterruptedException {

		//Clicking on Request Machine CWID Link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLink = BaseTest.driver.findElements(requestMachineCWIDLink);
		chckLink.get(0).click();
		objBaseTest.logResults("Clicking on Request Machine CWID Link");

		
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		objBaseTest.scrollInView(reasonForRequest(BaseTest.driver));
		
		//Entering reason For Request field
		objBaseTest.enterDataUsingJavascript(reasonForRequest(BaseTest.driver), reasonForRequestEntered);
		objBaseTest.logResults("Entering reason For Request field");

		// Uncheck the checkbox i.e without AD account
		if (ADAccount.equalsIgnoreCase("WithOut_ADAccount")) {
			Thread.sleep(1000);
			checboxAD_Account(BaseTest.driver).click();
		}

	
		objBaseTest.fluentWait();
		Thread.sleep(1000);
		
		//Clicking on Request for Machine CWID button
		requestForMachineCWIDButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request for Machine CWID button");
		objBaseTest.fluentWait();
		Thread.sleep(15000);

	}
	

}
