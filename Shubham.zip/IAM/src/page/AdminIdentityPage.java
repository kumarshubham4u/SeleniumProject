package page;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class AdminIdentityPage 
{
	BaseTest objBaseTest = new BaseTest();

	private By seacrhForTxtbox = By.id("tbSearchFor");
	private By selectingFirstRecordFromTable = By.xpath("//*[@id='applistajax-grid-table']//tr[2]//td[3]//a");
	private By bulletinSignedCheckBox = By.id("1023465");
	private By acceptanceDate = By.id("1024599");
	private By securityBulletinSignedBy = By.id("//*[@id='PanelSection1002609']//*[contains(@id,'_ContainerTable')]//tr[1]//span");
	private By additionalReason = By.id("1025169");




	// Returning WebElement from respective locators
	public WebElement searchForTxtbox(final WebDriver driver)
	{
		return driver.findElement(seacrhForTxtbox);
	}
	public WebElement selectingFirstRecordFromTable(final WebDriver driver)
	{
		return driver.findElement(selectingFirstRecordFromTable);
	}
	public WebElement bulletinSignedCheckBox(final WebDriver driver)
	{
		return driver.findElement(bulletinSignedCheckBox);
	}
	public WebElement acceptanceDate(final WebDriver driver)
	{
		return driver.findElement(acceptanceDate);
	}
	public WebElement securityBulletinSignedBy(final WebDriver driver)
	{
		return driver.findElement(securityBulletinSignedBy);
	}
	public WebElement additionalReason(final WebDriver driver)
	{
		return driver.findElement(additionalReason);
	}
	

	//Function to search textbox
	public void searchFieldFromTextBox(String searchText) throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(7000);
		objBaseTest.scrollInView(searchForTxtbox(BaseTest.driver));
		searchForTxtbox(BaseTest.driver).sendKeys(searchText);
		objBaseTest.logResults("Entering text and clicking on Search field:-"+searchText);

		//Clicking Enter from selenium code
		Thread.sleep(2000);
		searchForTxtbox(BaseTest.driver).sendKeys(Keys.ENTER);
	}

	//Function to select first record from table
	public void selectFirstRecordFromTable() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(6000);
		objBaseTest.scrollInView(selectingFirstRecordFromTable(BaseTest.driver));
		objBaseTest.clickUsingJavascript(selectingFirstRecordFromTable(BaseTest.driver));
		//selectingFirstRecordFromTable(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on First record");
	}

	//Function to Check bulletin is signed 
	public String checkingBulletingSignedCheckbox() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(6000);
		objBaseTest.scrollInView(bulletinSignedCheckBox(BaseTest.driver));

		//Checking Bulletin Signed checkbox is checked or not
		String bulletinCheckBoxValue =bulletinSignedCheckBox(BaseTest.driver).getAttribute("checked");

		return bulletinCheckBoxValue;
	}


	//Function to Check Security Bulletin Signed By text
	public String securityBulletinSignedBy() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(6000);
		//objBaseTest.scrollInView(securityBulletinSignedBy(BaseTest.driver));

		List<WebElement> chckLink= BaseTest.driver.findElements(securityBulletinSignedBy);
		System.out.println(chckLink.size());
		for(WebElement w:chckLink)
		{
			System.out.println("Text-"+w.getText());
		}

		String securityBulletinSignedByValue =securityBulletinSignedBy(BaseTest.driver).getText();
		System.out.println("security"+securityBulletinSignedByValue);
		return securityBulletinSignedByValue;
	}

	//Function to acceptanceDate
	public String acceptanceDate() throws InterruptedException
	{
		objBaseTest.fluentWait();Thread.sleep(6000);
		objBaseTest.scrollInView(acceptanceDate(BaseTest.driver));



		String acceptanceDateValue =acceptanceDate(BaseTest.driver).getAttribute("value");
		System.out.println("acceptanceDateValue"+acceptanceDateValue);
		
		return acceptanceDateValue;
	}

}
