package page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage
{
 
private By loginLink = By.xpath("//a[contains(@href,'/login')]");
private By userName = By.name("userName");
private By passWord = By.name("password");
private By loginButton = By.xpath("//button[contains(text(),'Log In')]");
 
public WebElement loginLink(final WebDriver driver)
{
	return driver.findElement(loginLink);
}

public WebElement userName(final WebDriver driver)
 {
	return driver.findElement(userName);
 }
 
 public WebElement passWord(final WebDriver driver)
 {
	 return driver.findElement(passWord);
 }
 
 public WebElement loginButton(final WebDriver driver)
 {
	 return driver.findElement(loginButton);
 }




}
