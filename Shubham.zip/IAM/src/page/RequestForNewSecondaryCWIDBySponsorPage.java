package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import commonFunctions.BaseTest;

public class RequestForNewSecondaryCWIDBySponsorPage 
{
	BaseTest objBaseTest = new BaseTest();

	//Sponsor locators
	private By tasksApproveRequestLink = By.xpath("//*[@id='Dashboard1_widget1_content']//tr[1]//td[1]//span[contains(text(),'Approve request for new secondary CWID by s')]");
	private By reasonForRequestApprover = By.id("1001460");
	private By request_New_ADAccount = By.id("1035393");
	private By approveRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Approve request')]");//btnTrans28862827 //btnTrans28863559
	private By declineRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'2) Decline request')]");//btnTrans28862831
	private By successMessageForApproverLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
	private By reasonForRejectionComments = By.id("1002928");
	private By sendCommentsToRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Send comments to requestor')]");
	private By rejectionPopUpMessageLabel = By.id("ui-id-1");
	private By rejectionPopUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By radioButton_secondary_CWID_General_Administrative_Purposes = By.id("1035473_0");
	private By radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk = By.id("1035473_1");


	// Returning WebElement from respective locators
	public WebElement tasksApproveRequestLink(final WebDriver driver)
	{
		return driver.findElement(tasksApproveRequestLink);
	}
	public WebElement approveRequestButton(final WebDriver driver)
	{
		return driver.findElement(approveRequestButton);
	}
	public WebElement declineRequestButton(final WebDriver driver)
	{
		return driver.findElement(declineRequestButton);
	}
	public WebElement reasonForRequestApprover(final WebDriver driver)
	{
		return driver.findElement(reasonForRequestApprover);
	}

	public WebElement request_New_ADAccount(final WebDriver driver)
	{
		return driver.findElement(request_New_ADAccount);
	}

	public WebElement successMessageForApproverLabel(final WebDriver driver)
	{
		return driver.findElement(successMessageForApproverLabel);
	}
	public WebElement reasonForRejectionComments(final WebDriver driver)
	{
		return driver.findElement(reasonForRejectionComments);
	}
	public WebElement sendCommentsToRequestButton(final WebDriver driver)
	{
		return driver.findElement(sendCommentsToRequestButton);
	}
	public WebElement rejectionPopUpMessageLabel(final WebDriver driver)
	{
		return driver.findElement(rejectionPopUpMessageLabel);
	}
	public WebElement rejectionPopUpMessageOkButton(final WebDriver driver)
	{
		return driver.findElement(rejectionPopUpMessageOkButton);
	}
	public WebElement radioButton_secondary_CWID_General_Administrative_Purposes(final WebDriver driver)
	{
		return driver.findElement(radioButton_secondary_CWID_General_Administrative_Purposes);
	}
	public WebElement radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(final WebDriver driver)
	{
		return driver.findElement(radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk);
	}


	/**
	 * Function for Clicking and viewing the request
	 * @param radioPuposeOfUsage
	 * @return
	 * @throws InterruptedException
	 */
	public String viewingSecondaryCWIDRequest(String radioPuposeOfUsage) throws InterruptedException
	{
		//Clicking on Task Approver Link
		Thread.sleep(17000);
		objBaseTest.fluentWait();
		tasksApproveRequestLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Tasks Approve Request Link");

		//Checking the CyberArk radio button should be selected or General Administrative Purposes RadioButton

		if(radioPuposeOfUsage.equalsIgnoreCase("SelectedCyberArkRadioButton"))
		{
			Thread.sleep(3000);
			objBaseTest.scrollInView(radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(BaseTest.driver));
			String radioButtonCyberArk = radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(BaseTest.driver).getAttribute("checked").trim();
			Assert.assertEquals(radioButtonCyberArk,"true");
			objBaseTest.logResults("Checking CyberArk RadioButton is selected");
		}
		else if(radioPuposeOfUsage.equalsIgnoreCase("SelectedGeneralAdministrativePurposesRadioButton"))
		{
			Thread.sleep(3000);
			objBaseTest.scrollInView(radioButton_secondary_CWID_General_Administrative_Purposes(BaseTest.driver));
			String radioButtonGeneralAdmin = radioButton_secondary_CWID_General_Administrative_Purposes(BaseTest.driver).getAttribute("checked").trim();
			Assert.assertEquals(radioButtonGeneralAdmin,"true");
			objBaseTest.logResults("Checking General Administrative Purposes RadioButton is selected");

		}
		//Checking the values entered
		objBaseTest.scrollInView(reasonForRequestApprover(BaseTest.driver));
		String reasonApprover = reasonForRequestApprover(BaseTest.driver).getText().trim();
		return reasonApprover;
	}


	/**
	 *   Clicking on Approver Button
	 * @param ADAccount
	 * @throws InterruptedException
	 */
	public void clickingApproverButton(String ADAccount) throws InterruptedException
	{
		objBaseTest.fluentWait();
		//Checking checkbox AD account is not selected need to add condition
		if(ADAccount.equalsIgnoreCase("WithOut_ADAccount"))
		{
			Thread.sleep(1000);
			String adaccountCheckBox_Value=request_New_ADAccount(BaseTest.driver).getAttribute("disabled");
			if(adaccountCheckBox_Value.equalsIgnoreCase("true"))
			{
				Assert.assertTrue(true);
				objBaseTest.logResults("Checking WithOut AD Account");
			}
		}


		//Clicking on approve request button.
		objBaseTest.scrollInView(approveRequestButton(BaseTest.driver));
		approveRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on approve request button.");
		Thread.sleep(18000);
		objBaseTest.fluentWait();
	}


	/**
	 * Function for Clicking on Reject Button without entering comments
	 * @param ADAccount
	 * @return
	 * @throws InterruptedException
	 */
	public String clickingRejectButtonWithOutEnteringComments(String ADAccount) throws InterruptedException
	{
		//Checking checkbox AD account is not selected 
		if(ADAccount.equalsIgnoreCase("WithOut_ADAccount"))
		{
			Thread.sleep(1000);
			String adaccountCheckBox_Value=request_New_ADAccount(BaseTest.driver).getAttribute("disabled");
			if(adaccountCheckBox_Value.equalsIgnoreCase("true"))
			{
				Assert.assertTrue(true);
				objBaseTest.logResults("Checking checkbox AD account is not selected ");
			}
		}


		objBaseTest.fluentWait();
		objBaseTest.scrollInView(declineRequestButton(BaseTest.driver));
		declineRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Decline request button.");

		Thread.sleep(9000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(reasonForRejectionComments(BaseTest.driver));
		sendCommentsToRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on send Comments To Request Button without entering any comments");
		Thread.sleep(1000);

		// Getting the text of Warning popup modal window
		String rejectionPopUpMessageLabelActual = rejectionPopUpMessageLabel(BaseTest.driver).getText().trim();
		rejectionPopUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on rejection PopUp Message Ok Button");

		return rejectionPopUpMessageLabelActual;


	}


	/**
	 * Function for Clicking on Reject Button wit entering comments
	 * @throws InterruptedException
	 */
	public void clickingRejectButtonWithEnteringComments() throws InterruptedException
	{

		String rejectionComments= "Required more information";
		reasonForRejectionComments(BaseTest.driver).sendKeys(rejectionComments);
		objBaseTest.logResults("Entering Reason For Rejection Comments field as "+ rejectionComments);

		sendCommentsToRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on send Comments To Request Button");
		Thread.sleep(15000);
		objBaseTest.fluentWait();


	}

}
