/**
 * 
 */
package page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

/**
 * @author ELGNF
 *
 */
public class RequestForDeactivateSecondaryCwidPage {
	BaseTest objBaseTest = new BaseTest();
	public String secondaryCWIDSelected = null;
	public String statusOfCWID = null;
	// locators
	private By deactSecondaryCWIDLinkSelf = By.xpath(
			"//span[contains(@title,'Use this self-service to deactivate a secondary CWID.')]//span[contains(text(),'Deactivate Secondary CWID')]");
	private By searchBtnForSecCWID = By.id("1001363_btn");
	private By firstRowSecondaryCwid = By.xpath("//table[@id='selection-grid-grid']//tr[2]/td[2]");
	private By okBtnForSelectingSecondaryCwid = By.xpath("//button[contains(text(),'OK')]");
	private By reasonForDeactivateSecCWID = By.id("1001463");
	private By continueBtnForDeactivateCWID = By.xpath("//*[contains(@value,'Continue')]");
	private By userDropdown = By.xpath("//*[@title='Tools']");
	private By myProfile = By.xpath("//span[contains(text(),'My profile')]");
	private By secondaryCWIDTable = By.id("cbcContainerSecondary_grid");
	private By statusofSecCWID = By.xpath("(//table[@id='cbcContainerSecondary_grid']//td[4])");

	// Returning WebElement from respective locators

	public WebElement deactSecondaryCWIDLinkSelf(final WebDriver driver) {
		return driver.findElement(deactSecondaryCWIDLinkSelf);
	}

	public WebElement searchBtnForSecCWID(final WebDriver driver) {
		return driver.findElement(searchBtnForSecCWID);
	}

	public WebElement firstRowSecondaryCwid(final WebDriver driver) {
		return driver.findElement(firstRowSecondaryCwid);
	}

	public WebElement okBtnForSelectingSecondaryCwid(final WebDriver driver) {
		return driver.findElement(okBtnForSelectingSecondaryCwid);
	}

	public WebElement reasonForDeactivateSecCWID(final WebDriver driver) {
		return driver.findElement(reasonForDeactivateSecCWID);
	}

	public WebElement continueBtnForDeactivateCWID(final WebDriver driver) {
		return driver.findElement(continueBtnForDeactivateCWID);
	}

	public WebElement userDropdown(final WebDriver driver) {
		return driver.findElement(userDropdown);
	}

	public WebElement myProfile(final WebDriver driver) {
		return driver.findElement(myProfile);
	}

	public WebElement secondaryCWIDTable(final WebDriver driver) {
		return driver.findElement(secondaryCWIDTable);
	}

	public WebElement statusofSecCWID(final WebDriver driver) {
		return driver.findElement(statusofSecCWID);
	}

	/***
	 * Function to Deactivate Secondary cwid
	 * 
	 * @throws InterruptedException
	 */
	public void deactivateSecondaryCWIDLinkSelfService() throws InterruptedException {


		// Clicking on Deactivate Secondary CWID Link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLink = BaseTest.driver.findElements(deactSecondaryCWIDLinkSelf);
		System.out.println(chckLink.size());
		chckLink.get(0).click();
		objBaseTest.logResults("Clicking on Deactivate Secondary CWID Link");
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		objBaseTest.scrollInView(searchBtnForSecCWID(BaseTest.driver));
		searchBtnForSecCWID(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(3000);

		//Storing the value of the CWID to be deactivated
		objBaseTest.clickUsingJavascript(firstRowSecondaryCwid(BaseTest.driver));
		secondaryCWIDSelected = firstRowSecondaryCwid(BaseTest.driver).getText();
		objBaseTest.logResults("Requested for deactivating the cwid-:"+ secondaryCWIDSelected);
		
		okBtnForSelectingSecondaryCwid(BaseTest.driver).click();
		objBaseTest.enterDataUsingJavascript(reasonForDeactivateSecCWID(BaseTest.driver), "Test Deactivate");
		continueBtnForDeactivateCWID(BaseTest.driver).click();
		Thread.sleep(17000);
		objBaseTest.fluentWait();
	}

	/***
	 * Function to verify that CWID is deactivated
	 * 
	 * @throws InterruptedException
	 */
	public void verifyDeactivatedSecondaryCWID() throws InterruptedException {
		Thread.sleep(17000);
		objBaseTest.fluentWait();
		userDropdown(BaseTest.driver).click();
		myProfile(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		// To Locate table
		objBaseTest.scrollInView(secondaryCWIDTable(BaseTest.driver));
		WebElement mytable = secondaryCWIDTable(BaseTest.driver);
		// To locate rows of table.
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		// To calculate no of rows In table.
		int rows_count = rows_table.size();
		// Loop will execute for all the rows of the table
		for (int row = 0; row < rows_count; row++) {
			// To locate columns(cells) of that specific row.
			List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
			// To calculate no of columns(cells) In that specific row.
			int columns_count = Columns_row.size();
			// Loop will execute till the last cell of that specific row.
			for (int column = 0; column < columns_count; column++) {
				// To retrieve text from the cells.
				String celltext = Columns_row.get(column).getText();

				// checking the status of the cwid
				if (celltext.equalsIgnoreCase(secondaryCWIDSelected)) {

					statusOfCWID = BaseTest.driver
							.findElement(By
									.xpath("(//table[@id='cbcContainerSecondary_grid']//tr[" + (row + 1) + "]//td[4])"))
							.getText().trim();

				}

			}
		}
	}
}
