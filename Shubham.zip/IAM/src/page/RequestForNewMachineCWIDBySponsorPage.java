package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import commonFunctions.BaseTest;

public class RequestForNewMachineCWIDBySponsorPage 
{
	BaseTest objBaseTest = new BaseTest();
	
		//locators
		private By tasksApproveRequestLink = By.xpath("//*[@id='Dashboard1_widget1_content']//tr[1]//td[1]//span[contains(text(),'Approve request for new Machine CWID')]");
		private By reasonForRequestApprover = By.id("1001468");
		private By request_New_ADAccount = By.id("1023701");
		private By approveRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Approve request')]");//btnTrans28862827 //btnTrans28863559
		private By declineRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'2) Decline request')]");//btnTrans28862831
		private By successMessageForApproverLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
		private By reasonForRejectionComments = By.id("1002929");
		private By sendCommentsToRequestButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'1) Send comments to requester')]");
		private By rejectionPopUpMessageLabel = By.id("ui-id-1");
		private By rejectionPopUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
		
		// Returning WebElement from respective locators 
		public WebElement tasksApproveRequestLink(final WebDriver driver)
		{
			return driver.findElement(tasksApproveRequestLink);
		}
		public WebElement approveRequestButton(final WebDriver driver)
		{
			return driver.findElement(approveRequestButton);
		}
		public WebElement declineRequestButton(final WebDriver driver)
		{
			return driver.findElement(declineRequestButton);
		}
		public WebElement reasonForRequestApprover(final WebDriver driver)
		{
			return driver.findElement(reasonForRequestApprover);
		}

		public WebElement request_New_ADAccount(final WebDriver driver)
		{
			return driver.findElement(request_New_ADAccount);
		}

		public WebElement successMessageForApproverLabel(final WebDriver driver)
		{
			return driver.findElement(successMessageForApproverLabel);
		}
		public WebElement reasonForRejectionComments(final WebDriver driver)
		{
			return driver.findElement(reasonForRejectionComments);
		}
		public WebElement sendCommentsToRequestButton(final WebDriver driver)
		{
			return driver.findElement(sendCommentsToRequestButton);
		}
		public WebElement rejectionPopUpMessageLabel(final WebDriver driver)
		{
			return driver.findElement(rejectionPopUpMessageLabel);
		}
		public WebElement rejectionPopUpMessageOkButton(final WebDriver driver)
		{
			return driver.findElement(rejectionPopUpMessageOkButton);
		}
		
		/***
		 * Function to view machine cwid request
		 * @return
		 * @throws InterruptedException
		 */
		public String viewingMachineCWIDRequest() throws InterruptedException
		{
			//clicking on task approval link
			Thread.sleep(17000);
			objBaseTest.fluentWait();
			tasksApproveRequestLink(BaseTest.driver).click();

			//Checking the values entered
			objBaseTest.scrollInView(reasonForRequestApprover(BaseTest.driver));
			String reasonApprover = reasonForRequestApprover(BaseTest.driver).getText().trim();
			return reasonApprover;
		}

	/***
	 * Clicking on Approver Button
	 * @param ADAccount
	 * @throws InterruptedException
	 */
		public void clickingApproverButton(String ADAccount) throws InterruptedException
		{
			objBaseTest.fluentWait();
			
			//Checking checkbox AD account is not selected need to add condition
			if(ADAccount.equalsIgnoreCase("WithOut_ADAccount"))
			{
				Thread.sleep(1000);
				System.out.println("WithOut_ADAccount checkbox");
				String adaccountCheckBox_Value=request_New_ADAccount(BaseTest.driver).getAttribute("disabled");
				System.out.println("adaccountCheckBox_Value"+adaccountCheckBox_Value);
				if(adaccountCheckBox_Value.equalsIgnoreCase("true"))
				{
					System.out.println("WithOut_ADAccount checkbox assert");
					Assert.assertTrue(true);
				}
			}

			objBaseTest.scrollInView(approveRequestButton(BaseTest.driver));
			approveRequestButton(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on approve request button.");
			Thread.sleep(18000);
			objBaseTest.fluentWait();
		}

		/***
		 * Clicking on Reject Button without entering comments
		 * @param ADAccount
		 * @return
		 * @throws InterruptedException
		 */
		
		public String clickingRejectButtonWithOutEnteringComments(String ADAccount) throws InterruptedException
		{
			//Checking checkbox AD account is not selected 
			if(ADAccount.equalsIgnoreCase("WithOut_ADAccount"))
			{
				Thread.sleep(1000);
				System.out.println("WithOut_ADAccount checkbox");
				String adaccountCheckBox_Value=request_New_ADAccount(BaseTest.driver).getAttribute("disabled");
				System.out.println("adaccountCheckBox_Value"+adaccountCheckBox_Value);
				if(adaccountCheckBox_Value.equalsIgnoreCase("true"))
				{
					objBaseTest.logResults("WithOut_ADAccount checkbox assert");
					Assert.assertTrue(true);
				}
			}

			
			objBaseTest.fluentWait();
			objBaseTest.scrollInView(declineRequestButton(BaseTest.driver));
			declineRequestButton(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on decline request button.");

			Thread.sleep(6000);
			objBaseTest.fluentWait();
			objBaseTest.scrollInView(reasonForRejectionComments(BaseTest.driver));
			sendCommentsToRequestButton(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on send Comments To Request Button without entering any comments");
			Thread.sleep(1000);

			// Getting the text of Warning popup modal window
			String rejectionPopUpMessageLabelActual = rejectionPopUpMessageLabel(BaseTest.driver).getText().trim();
			rejectionPopUpMessageOkButton(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on rejection PopUp Message Ok Button");

			return rejectionPopUpMessageLabelActual;


		}

		/****
		 * Clicking on send Comments To Request Button
		 * @throws InterruptedException
		 */
		public void clickingRejectButtonWithEnteringComments() throws InterruptedException
		{
			String rejectionComments= "Required more information";
			reasonForRejectionComments(BaseTest.driver).sendKeys(rejectionComments);
			objBaseTest.logResults("Entering Reason For Rejection Comments field as "+ rejectionComments);

			sendCommentsToRequestButton(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on send Comments To Request Button");
			Thread.sleep(15000);
			objBaseTest.fluentWait(); 
	 
	

			
			

		}

}
