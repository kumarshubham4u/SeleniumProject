package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForPartnerID {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;
	String bayerMail = "test123@bayer.com";
	String first = "TestFirst";
	String last = "TestLast";
	String company = "Test ext. Company";
	String sponser = "BBSS1";
	String pastDate = "04/04/2019";
	String futureDate = "04/04/2050";
	String randomMailID = null;
	static String mail = "@xyz.com";
	static int n = 6;

	// Creator locators
	private By createPartnerIDLink = By.xpath("//span[(text()='Create Partner ID')]");
	private By externalCollaboration = By.xpath("//label[contains(text(),'External Collaboration (incl. GridCard)')]");
	private By sharepointOnline = By.xpath("//label[contains(text(),'Sharepoint Online')]");
	private By emailCheck = By.xpath("//input[@id='1029440']");
	private By checkButton = By.xpath("//input[@value='Check']");

	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='< Back']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By firstName = By.xpath("//input[@id='1029441']");
	private By lastName = By.xpath("//input[@id='1029442']");
	private By extCompanyName = By.xpath("//input[@id='1029437']");
	private By sponsorCWID = By.xpath("//input[@id='1029445_textbox-selectized']");
	private By validToDate = By.xpath("//input[@id='1029444']");

	private By extMobileCountryCode = By.xpath("//input[@id='MOBILE_COUNTRY']");
	private By extMobilePrefix = By.xpath("//input[@id='MOBILE_PREFIX']");
	private By extMobileNumber = By.xpath("//input[@id='CELLPHONE']");
	private By pidGenerated = By
			.xpath("//td[@class='CtrlAndImgBtn_CtrlCell'] //div[@class='selectize-control TBSL multi'] //span");

	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");

	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement createPartnerIDLink(final WebDriver driver) {
		return driver.findElement(createPartnerIDLink);

	}

	public WebElement externalCollaboration(final WebDriver driver)

	{
		return driver.findElement(externalCollaboration);
	}

	public WebElement sharepointOnline(final WebDriver driver)

	{
		return driver.findElement(sharepointOnline);
	}

	public WebElement emailCheck(final WebDriver driver)

	{
		return driver.findElement(emailCheck);
	}

	public WebElement checkButton(final WebDriver driver)

	{
		return driver.findElement(checkButton);
	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement firstName(final WebDriver driver) {
		return driver.findElement(firstName);
	}

	public WebElement lastName(final WebDriver driver) {
		return driver.findElement(lastName);
	}

	public WebElement extCompanyName(final WebDriver driver) {
		return driver.findElement(extCompanyName);
	}

	public WebElement sponsorCWID(final WebDriver driver) {
		return driver.findElement(sponsorCWID);
	}

	public WebElement validToDate(final WebDriver driver) {
		return driver.findElement(validToDate);
	}

	public WebElement extMobileCountryCode(final WebDriver driver) {
		return driver.findElement(extMobileCountryCode);
	}

	public WebElement extMobilePrefix(final WebDriver driver) {
		return driver.findElement(extMobilePrefix);
	}

	public WebElement extMobileNumber(final WebDriver driver) {
		return driver.findElement(extMobileNumber);
	}

	public WebElement pidGenerated(final WebDriver driver) {
		return driver.findElement(pidGenerated);
	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on create Partner ID Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnCreatePartnerIDLink() throws InterruptedException {
		// Clicking on create Partner ID Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// createPartnerIDLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(createPartnerIDLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Create Partner ID Link");
	}

	/**
	 * Function to click on External Collaboration Radio button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnExternalCollaboration() throws InterruptedException {
		// Clicking on External Collaboration Radio button
		objBaseTest.explicitWait(externalCollaboration);
		Thread.sleep(2000);
		externalCollaboration(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on External Collaboration Radio button");
	}

	/**
	 * Function to click on Sharepoint Online Radio button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSharepointOnline() throws InterruptedException {
		// Clicking on Sharepoint Online Radio button
		objBaseTest.explicitWait(sharepointOnline);
		Thread.sleep(2000);
		sharepointOnline(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Sharepoint Online Radio button");
	}

	/**
	 * Function for Sending Keys on Email Check as Bayer Mail ID
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnEmailCheck() throws InterruptedException {
		// Sending Keys on Email Check as Bayer Mail ID
		Thread.sleep(2000);
		objBaseTest.scrollInView(sharepointOnline(BaseTest.driver));
		emailCheck(BaseTest.driver).sendKeys(bayerMail);
		objBaseTest.logResults("Sending Keys on Email Check as Bayer Mail ID to Check for Validation Error");
		Thread.sleep(1000);
		checkButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Check Button");
	}

	/**
	 * Function for Sending Keys for search Sponser CWID
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnSponsorCWID() throws InterruptedException {
		// Sending Keys for search Sponser CWID
		Thread.sleep(2000);
		objBaseTest.scrollInView(sponsorCWID(BaseTest.driver));
		sponsorCWID(BaseTest.driver).sendKeys(sponser);
		Thread.sleep(4000);
		sponsorCWID(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Sending Keys for search Sponser CWID");
	}

	/**
	 * Function to Check Exceptions
	 * 
	 * @throws InterruptedException
	 */
	public void checkValidation() throws InterruptedException {

		// Clicking on Next button without entering Mandatory Fields
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

		// Sending Keys on first Name
		Thread.sleep(3000);
		firstName(BaseTest.driver).sendKeys(first);
		objBaseTest.logResults("Sending Keys for first Name");

		// Sending Keys on last Name
		Thread.sleep(1000);
		lastName(BaseTest.driver).sendKeys(last);
		objBaseTest.logResults("Sending Keys for last Name");

		// Sending Keys on external Company Name
		Thread.sleep(1000);
		objBaseTest.scrollInView(sponsorCWID(BaseTest.driver));
		extCompanyName(BaseTest.driver).sendKeys(company);
		objBaseTest.logResults("Sending Keys for external Company Name");

		// Sending Keys on Mobile Country Code as invalid
		Thread.sleep(3000);
		extMobileCountryCode(BaseTest.driver).sendKeys("8972");
		objBaseTest.logResults("Sending Keys for Mobile Country Code as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Country code as invalid

		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Country Code\" could not be validated");

		// Sending Keys on Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for mobile country code as valid");

		// Sending Keys on Mobile Prefix as invalid
		Thread.sleep(2000);
		extMobilePrefix(BaseTest.driver).sendKeys("abcd123");
		objBaseTest.logResults("Sending Keys for External Mobile Prefix as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("9876");
		objBaseTest.logResults("Sending Keys for mobile prefix as valid");

		// Sending Keys on Mobile Number as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).sendKeys("wxyz123");
		objBaseTest.logResults("Sending Keys for External Mobile Number as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid

		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"Mobile Number\" could not be validated");

		// Sending Keys on Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("765890");
		objBaseTest.logResults("Sending Keys for external mobile number as valid");

		// Sending Keys on validToDate
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Valid To Date" as more than 365 to check Expection
		validToDate(BaseTest.driver).clear();
		Thread.sleep(1000);
		validToDate(BaseTest.driver).sendKeys(futureDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" date as more than 365 to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		objBaseTest.explicitWait(popUpMessageOkButton);
		String alert1 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending keys on "Valid To Date" as Past Date
		objBaseTest.scrollInView(validToDate(BaseTest.driver));
		validToDate(BaseTest.driver).clear();
		validToDate(BaseTest.driver).sendKeys(pastDate + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" as Past Date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		objBaseTest.explicitWait(popUpMessageOkButton);
		String alert2 = popUpMessageLabel(BaseTest.driver).getText();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

	}

	/**
	 * Function to Create Partner ID
	 * 
	 * @throws InterruptedException
	 */
	public void createPartnerID() throws InterruptedException {

		// Sending Keys on Email Check as random Mail ID
		randomMailID = getAlphaNumericString();
		Thread.sleep(2000);
		objBaseTest.scrollInView(sharepointOnline(BaseTest.driver));
		emailCheck(BaseTest.driver).clear();
		Thread.sleep(1000);
		emailCheck(BaseTest.driver).sendKeys(randomMailID);
		objBaseTest.logResults("Sending Keys on Email Check as random Mail ID");
		Thread.sleep(1000);
		checkButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Check Button");

		// Sending Keys on first Name
		Thread.sleep(3000);
		if (firstName(BaseTest.driver).isEnabled()) {
			firstName(BaseTest.driver).sendKeys(first);
			objBaseTest.logResults("Sending Keys for first Name");
		} else {
			objBaseTest.logResults("Entered Mail ID pre-exists");
			Assert.assertTrue(false);

		}
		// Sending Keys on last Name
		Thread.sleep(1000);
		lastName(BaseTest.driver).sendKeys(last);
		objBaseTest.logResults("Sending Keys for last Name");

		// Sending Keys on external Company Name
		Thread.sleep(1000);
		objBaseTest.scrollInView(sponsorCWID(BaseTest.driver));
		extCompanyName(BaseTest.driver).sendKeys(company);
		objBaseTest.logResults("Sending Keys for external Company Name");

		// Sending Keys on Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for mobile country code as valid");

		// Sending Keys on Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("9876");
		objBaseTest.logResults("Sending Keys for mobile prefix as valid");

		// Sending Keys on Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("765890");
		objBaseTest.logResults("Sending Keys for external mobile number as valid");

		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after entering fields");

		// Clicking on Next button after verifying the Final form
		objBaseTest.explicitWait(backButton);
		Thread.sleep(4000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after verifying the Final form");
	}

	/**
	 * Function Getting the generated CWID and clicking on Finish button without
	 * entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingFinishButton() throws InterruptedException {
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(6000);
		// Getting Generated CWID
		String[] pid = pidGenerated(BaseTest.driver).getText().split(" ");
		objBaseTest.logResults("Generated Partner ID : " + pid[0]);
		// Clicking on Finish button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");

	}

	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(3000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

	// function to generate a random string of length n
	static String getAlphaNumericString() {

		// choose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		String Alphabate = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {
			if (i == 0) {
				int index = (int) (Alphabate.length() * Math.random());
				sb.append(Alphabate.charAt(index));
			} else {
				// generate a random number between
				// 0 to AlphaNumericString variable length
				int index = (int) (AlphaNumericString.length() * Math.random());

				// add Character one by one in end of sb
				sb.append(AlphaNumericString.charAt(index));

			}
		}
		sb.append(mail);
		return sb.toString();
	}

}
