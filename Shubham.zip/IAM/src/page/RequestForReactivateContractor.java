package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForReactivateContractor {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;
	// Creator locators
	private By reactivateCwidLink = By.xpath("//span[(text()='Reactivate CWID for contractor GUMS Non-GHR')]");
	private By searchCwid = By.xpath("//img[@id='1017641_btn']");
	private By firstRowCWID = By.xpath("//table[@id='1000714_selection-grid-grid']//tbody/tr[2]/td[2]");
	private By okButton = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='OK']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value=' Next >']");
	private By personalData = By.xpath("//span[(text()='Personnel data')]");
	
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By extCompanyName = By.xpath("//input[@id='1016951']");
	private By sponsorCWID = By.xpath("//input[@id='1016949']");
	private By validToDate = By.xpath("//input[@id='1016947']");
	private By extEmail = By.xpath("//input[@id='1025162']");
	private By extMobileCountryCode = By.xpath("//input[@id='EXT_MOBILE_COUNTRY']");
	private By extMobilePrefix = By.xpath("//input[@id='EXT_MOBILE_PREFIX']");
	private By extMobileNumber = By.xpath("//input[@id='EXT_CELLPHONE']");
	private By cwidReactivated = By
			.xpath("//td[@class='CtrlAndImgBtn_CtrlCell'] //div[@class='selectize-control TBSL multi'] //span");

	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value=' Finish']");

	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement reactivateCwidLink(final WebDriver driver) {
		return driver.findElement(reactivateCwidLink);

	}

	public WebElement searchCwid(final WebDriver driver) {
		return driver.findElement(searchCwid);

	}

	public WebElement firstRowCWID(final WebDriver driver) {
		return driver.findElement(firstRowCWID);

	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}
	
	public WebElement personalData(final WebDriver driver) {
		return driver.findElement(personalData);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement extCompanyName(final WebDriver driver) {
		return driver.findElement(extCompanyName);
	}

	public WebElement sponsorCWID(final WebDriver driver) {
		return driver.findElement(sponsorCWID);
	}

	public WebElement validToDate(final WebDriver driver) {
		return driver.findElement(validToDate);
	}

	public WebElement extEmail(final WebDriver driver) {
		return driver.findElement(extEmail);
	}

	public WebElement extMobileCountryCode(final WebDriver driver) {
		return driver.findElement(extMobileCountryCode);
	}

	public WebElement extMobilePrefix(final WebDriver driver) {
		return driver.findElement(extMobilePrefix);
	}

	public WebElement extMobileNumber(final WebDriver driver) {
		return driver.findElement(extMobileNumber);
	}

	public WebElement cwidReactivated(final WebDriver driver) {
		return driver.findElement(cwidReactivated);
	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on Reactivate CWID for contractor GUMS Non-GHR Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnReactivateCwidLink() throws InterruptedException {
		// Clicking on Reactivate CWID for contractor GUMS Non-GHR link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// reactivateCwidLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(reactivateCwidLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Reactivate CWID for contractor GUMS Non-GHR link");
	}

	/**
	 * Function to click on Search CWID button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchCwid() throws InterruptedException {
		// Clicking on Search CWID button
		Thread.sleep(8000);
		objBaseTest.fluentWait();
		// searchCwid(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchCwid(BaseTest.driver));
		objBaseTest.logResults("Clicking on Search CWID button");
	}

	/**
	 * Function to Select first row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowCWID() throws InterruptedException {
		// Clicking on Search GSO CWID
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		// GSOCwidPerson(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowCWID(BaseTest.driver));
		selectedCWID = firstRowCWID(BaseTest.driver).getText();
		objBaseTest.logResults("Requested reactivation for the cwid : " + selectedCWID);
	}

	/**
	 * Function to click on Ok button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnOkButton() throws InterruptedException {
		// Clicking on Ok button
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
	}

	/**
	 * Function clicking on Next button
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButton() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		objBaseTest.scrollInView(nextButton(BaseTest.driver));
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

	}

	/**
	 * Function clicking on Next button without entering mandatory fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButtonWithoutEnteringFields() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(21000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

	}

	/**
	 * Function clicking on Next button after entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingNextButtonAfterEnteringFields() throws InterruptedException {
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after entering fields");

	}

	/**
	 * Function Getting the reactivated CWID and clicking on Finish button without
	 * entering fields
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public void clickingFinishButton() throws InterruptedException {
		objBaseTest.explicitWait(cwidReactivated);
		Thread.sleep(3000);
		// Getting Generated CWID
		String cwid = cwidReactivated(BaseTest.driver).getText();
		objBaseTest.logResults("Reactivated CWID details : " + cwid);
		// Clicking on Finish button
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");

	}

	/**
	 * Function to send keys on external Company Name
	 * 
	 * @throws InterruptedException
	 */

	public void sendingKeysOnExtCompanyName() throws InterruptedException { //
		// Sending Keys on external Company Name Thread.sleep(1000);

		objBaseTest.fluentWait();
		extCompanyName(BaseTest.driver).clear();
		objBaseTest.scrollInView(extCompanyName(BaseTest.driver));
		extCompanyName(BaseTest.driver).sendKeys("TEST Ext. Company");
		objBaseTest.logResults("Sending Keys for external Company Name");
	}

	/**
	 * Function to send keys on search Sponser CWID lookup
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnSponsorCWIDLookup() throws InterruptedException {
		// Sending Keys for search Sponser CWID
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		sponsorCWID(BaseTest.driver).sendKeys("BBSS1" + Keys.TAB);
		objBaseTest.logResults("Sending Keys for search Sponser CWID");
	}

	/**
	 * Function to send keys on Valid To Date
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnValidToDate() throws InterruptedException {
		// Sending Keys on validToDate
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Valid To Date" as more than 365 to check Expection
		validToDate(BaseTest.driver).sendKeys("04/25/2026" + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" date as more than 365 to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert1 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending keys on "Valid To Date" as Past Date
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		validToDate(BaseTest.driver).sendKeys("04/25/2010" + Keys.ENTER);
		objBaseTest.logResults("Sending keys on \"Valid To\" as Past Date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert2 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

		// Sending keys on "Valid To Date" as a date within 365 days
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		validToDate(BaseTest.driver).sendKeys("04/14/2021" + Keys.ENTER); // Valid for Test script running till 14th
																			// April 2021
		objBaseTest.logResults("Sending keys on \"Valid To\" as date within 365 days (Valid Till 04/14/2021)");

	}

	/**
	 * Function to send keys on External Email field
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtEmail() throws InterruptedException {
		// Sending Keys on external email as a Bayer email id
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(extEmail(BaseTest.driver));
		extEmail(BaseTest.driver).clear();
		extEmail(BaseTest.driver).sendKeys("testing@bayer.com");
		objBaseTest.logResults("Sending Keys for external email as a Bayer email id to check for Validation error");
		Thread.sleep(1000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Email as internal bayer mail id
		objBaseTest.explicitWait(popUpMessageLabel);
		Thread.sleep(2000);
		String extEmailValidation = popUpMessageLabel(BaseTest.driver).getText();
		Thread.sleep(2000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + extEmailValidation);

		// Sending Keys on external email as a external mail id
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(extEmail(BaseTest.driver));
		extEmail(BaseTest.driver).clear();
		extEmail(BaseTest.driver).sendKeys("testing@capgemini.com");
		objBaseTest.logResults("Sending Keys for external email as an external mail id");

	}

	/**
	 * Function to send keys on External Mobile Country Code
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobileCountryCode() throws InterruptedException {
		// Sending Keys on external Mobile Country Code as invalid
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("8972");
		objBaseTest
				.logResults("Sending Keys for External Mobile Country Code as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Country code as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Country Code\" could not be validated");

		// Sending Keys on external Mobile Country Code as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileCountryCode(BaseTest.driver).clear();
		extMobileCountryCode(BaseTest.driver).sendKeys("49");
		objBaseTest.logResults("Sending Keys for external mobile country code as valid");

	}

	/**
	 * Function to send keys on External Mobile Prefix
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobilePrefix() throws InterruptedException {
		// Sending Keys on external Mobile Prefix as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("abcd123");
		objBaseTest.logResults("Sending Keys for External Mobile Prefix as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Number\" could not be validated");

		// Sending Keys on external Mobile Country Prefix as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobilePrefix(BaseTest.driver).clear();
		extMobilePrefix(BaseTest.driver).sendKeys("9876");
		objBaseTest.logResults("Sending Keys for external mobile prefix as valid");

	}

	/**
	 * Function to send keys on External Mobile Number
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExtMobileNumber() throws InterruptedException {
		// Sending Keys on external Mobile Number as invalid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("wxyz123");
		objBaseTest.logResults("Sending Keys for External Mobile Number as invalid to check for Validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button");

		// Getting the text of Warning popup modal window when filling the External
		// Mobile Prefix as invalid
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : \"External Mobile Number\" could not be validated");

		// Sending Keys on external Mobile Country Number as Valid
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		extMobileNumber(BaseTest.driver).clear();
		extMobileNumber(BaseTest.driver).sendKeys("765890");
		objBaseTest.logResults("Sending Keys for external mobile number as valid");
	}

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
