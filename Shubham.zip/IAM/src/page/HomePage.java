package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import commonFunctions.BaseTest;

public class HomePage {
	BaseTest objBaseTest = new BaseTest();
	
	// Creator locators
	private By servicesLink = By.xpath("//*[@id='mega-1']//*[contains(text(),'Services')]");
	private By reactivateCWID = By.xpath("//span[(text()='Reactivate CWID')]");
	private By accountRequest_Zulassungsantrage = By.id("ui-id-3");
	private By cwidAdminsLink = By.id("ui-id-4");
	private By delegationLink = By.xpath("//*[contains(text(),'Delegation / Aufgaben �bertragen')]");
	private By partnerIdLink = By.xpath("//*[contains(text(),'Partner-ID Request / Partner-ID Antr�ge')]");
	
	private By gumsContractorAdmin = By.id("ui-id-4");
	private By requestUnix_ID = By.xpath(
			"//div[contains(@id,'ServicesMenu_widget0_content_tabs_')]//span[contains(text(),'Request Unix-ID')]");
	private By requestADAccount = By.xpath(
			"//div[contains(@id,'ServicesMenu_widget0_content_tabs_')]//span[contains(text(),'Request AD Account')]");
	private By signatureExceptionHanlingLink = By.xpath(
			"//div[contains(@id,'ServicesMenu_widget0_content_tabs_')]//span[contains(text(),'Signature Exception Handling')]");
	private By setUpLink = By.xpath("//*[@id='mega-1']//*[contains(text(),'Setup')]");
	private By identityLink = By.xpath("//a[contains(@href,'view=1000598')][text()='Identity']");
	private By loginUserName = By.id("TopBarUserInfo");
	

	// Returning WebElement from respective locators
	public WebElement servicesLink(final WebDriver driver) {
		return driver.findElement(servicesLink);
	}

	public WebElement reactivateCWID(final WebDriver driver) {
		return driver.findElement(reactivateCWID);

	}

	public WebElement accountRequest_Zulassungsantrage(final WebDriver driver) {
		return driver.findElement(accountRequest_Zulassungsantrage);
	}
	
	public WebElement cwidAdminsLink(final WebDriver driver) {
		return driver.findElement(cwidAdminsLink);
	}
	
	public WebElement delegationLink(final WebDriver driver) {
		return driver.findElement(delegationLink);
	}
	
	public WebElement partnerIdLink(final WebDriver driver) {
		return driver.findElement(partnerIdLink);
	}
	
	public WebElement gumsContractorAdmin(final WebDriver driver) {
		return driver.findElement(gumsContractorAdmin);
	}
	
	public WebElement requestUnix_IDLink(final WebDriver driver) {
		return driver.findElement(requestUnix_ID);
	}

	public WebElement requestADAccount(final WebDriver driver) {
		return driver.findElement(requestADAccount);
	}

	public WebElement signatureExceptionHanlingLink(final WebDriver driver) {
		return driver.findElement(signatureExceptionHanlingLink);
	}

	public WebElement setUpLink(final WebDriver driver) {
		return driver.findElement(setUpLink);
	}

	public WebElement identityLink(final WebDriver driver) {
		return driver.findElement(identityLink);
	}

	public WebElement loginUserName(final WebDriver driver) {
		return driver.findElement(loginUserName);
	}

	/**
	 * Function to click on Service Link
	 * 
	 * @throws InterruptedException
	 */
	
	public void clickingOnServiceLink() throws InterruptedException {
		// Clicking on service Link
		objBaseTest.explicitWait(servicesLink);
		// servicesLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(servicesLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Services Link");
	}

	/**
	 * Function to click on Reactivate CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnReactivateCWID() throws InterruptedException {
		// Clicking on Reactivate CWID Link
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// reactivateCWID(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(reactivateCWID(BaseTest.driver));
		objBaseTest.logResults("Clicking on Reactivate CWID");
	}

	/**
	 * Function to click on Account Request Zulassungsantrage
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnAccountRequest_ZulassungsantrageLink() throws InterruptedException {
		// Clicking on Account Request Zulassungsantrage Link
		objBaseTest.fluentWait();
		Thread.sleep(5000);
		accountRequest_Zulassungsantrage(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Account Request / Zulassungsantrage Link");
	}
	
	
	/**
	 * Function to click on CWID Admins Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnCwidAdminsLink() throws InterruptedException {
		// Clicking on cwid Admins Link
		objBaseTest.fluentWait();
		Thread.sleep(5000);
		cwidAdminsLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Cwid Admins Link");
	}
	
	/**
	 * Function to click on Account Request Zulassungsantrage
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDelegationLink() throws InterruptedException {
		// Clicking on Delegation Link
		objBaseTest.fluentWait();
		Thread.sleep(5000);
		delegationLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Delegation / Aufgaben ubertragen Link");
	}
	
	/**
	 * Function to click on Partner-ID Request / Partner-ID Antr�ge Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnPartnerIdLink() throws InterruptedException {
		// Clicking on Partner-ID Request / Partner-ID Antr�ge Link
		objBaseTest.fluentWait();
		Thread.sleep(5000);
		partnerIdLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Partner-ID Request / Partner-ID Antrage Link");
	}
	
	
	/**
	 * Function to click on gums Contractor Admin
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnGumsContractorAdmin() throws InterruptedException {
		// Clicking on gums Contractor Admin Link
		objBaseTest.fluentWait();
		Thread.sleep(5000);
		gumsContractorAdmin(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on gums Contractor Admin Link");
	}
	
	/**
	 * Function to click on Request Unix-ID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnRequestUnixIDLink() throws InterruptedException {
		// Clicking on Request Unix-ID Link
		objBaseTest.fluentWait();
		Thread.sleep(12000);
		// requestUnix_IDLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(requestUnix_IDLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Request Unix-ID Link");
	}

	/**
	 * Function to click on Request Ad Account
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnRequestAdAccount() throws InterruptedException {
		// Clicking on Request Ad Account
		objBaseTest.fluentWait();
		Thread.sleep(14000);
		requestADAccount(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request Ad Account Link");

	}

	/**
	 * Function to click on Signature Exception Handling Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSignatureExceptionHandlingLink() throws InterruptedException {
		// Clicking on Signature Exception Hanling Link
		objBaseTest.fluentWait();
		Thread.sleep(14000);
		signatureExceptionHanlingLink(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Signature Exception Handling Link");
	}

	/**
	 * Function to click on Set Up Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSetUpLink() throws InterruptedException {
		// Clicking on service Link
		objBaseTest.explicitWait(setUpLink);
		objBaseTest.clickUsingJavascript(setUpLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Set Up Link");
	}

	/**
	 * Function to click on identity Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnidentityLink() throws InterruptedException {
		// Clicking on identity Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		objBaseTest.scrollInView(identityLink(BaseTest.driver));
		objBaseTest.clickUsingJavascript(identityLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on identity Link");
	}

}
