package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForChangeEmpCwidToContractorCwid {

	BaseTest objBaseTest = new BaseTest();

	public String[] selectedCWID = null;
	String empCwidInitial = "DWHE";
	String company = "Test ext. Company";
	String givenPurposeOfUsage = "12";
	String pastDate = "04/04/2019";
	String futureDate = "04/04/2050";
	String futureSponsorCWID = "BBSS1 ";
	String correctDate = "12/11/2020";

	// Creator locators
	private By changeEmpCwidLink = By.xpath("//span[(text()='Change Employee CWID to Contractor-CWID')]");
	private By searchButton = By.xpath("//img[@id='1026911_btn']");
	private By displayName = By.xpath("//input[@id='gs_1001146_selection-grid-grid_c-40']");
	private By firstRowSelect = By.xpath("//table[@id='1001146_selection-grid-grid']//tr[2]//td[3]");
	private By extCompanyName = By.xpath("//input[@id='1026930']");
	private By validFromDate = By.xpath("//input[@id='1026935']");
	private By validToDate = By.xpath("//input[@id='1026936']");
	private By calenderNext = By.xpath("//span[(text()='Next')]");
	private By validDate = By.xpath("//a[(text()='11')]");
	private By okButton = By.xpath("//button[text()='OK']");
	private By newSponsor = By.xpath("//input[@id='1026934_textbox-selectized']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By createUIDbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Create Unix ID']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='< Back']");
	private By finishbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");
	private By identityLink = By.xpath("//*[@id=\"mega-1\"]/li[3]/div/ul/div/li[4]/ul/li[13]/a");
	private By searchFor = By.xpath("//input[@id='tbSearchFor']");
	private By searchedEmployee = By.xpath("//td[@class='gridcell-ellipsisclip']/a");
	private By validatedExtCompany = By.xpath("//input[@id='1005443']");
	private By purposeOfUsage = By.xpath("//select[@id='1005693']");
	private By dateValidated = By.xpath("//input[@id='1005399']");
	private By okChecked = By.xpath("//input[@value='OK']");
	

	// Returning WebElement from respective locators

	public WebElement changeEmpCwidLink(final WebDriver driver) {
		return driver.findElement(changeEmpCwidLink);

	}

	public WebElement searchButton(final WebDriver driver) {
		return driver.findElement(searchButton);

	}

	public WebElement displayName(final WebDriver driver) {
		return driver.findElement(displayName);

	}

	public WebElement firstRowSelect(final WebDriver driver) {
		return driver.findElement(firstRowSelect);

	}

	public WebElement extCompanyName(final WebDriver driver) {
		return driver.findElement(extCompanyName);

	}

	public WebElement validFromDate(final WebDriver driver) {
		return driver.findElement(validFromDate);
	}

	public WebElement validToDate(final WebDriver driver) {
		return driver.findElement(validToDate);
	}

	public WebElement calenderNext(final WebDriver driver) {
		return driver.findElement(calenderNext);
	}

	public WebElement validDate(final WebDriver driver) {
		return driver.findElement(validDate);
	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}

	public WebElement newSponsor(final WebDriver driver) {
		return driver.findElement(newSponsor);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement createUIDbutton(final WebDriver driver) {
		return driver.findElement(createUIDbutton);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishbutton(final WebDriver driver) {
		return driver.findElement(finishbutton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	public WebElement identityLink(final WebDriver driver) {
		return driver.findElement(identityLink);

	}

	public WebElement searchFor(final WebDriver driver) {
		return driver.findElement(searchFor);

	}

	public WebElement searchedEmployee(final WebDriver driver) {
		return driver.findElement(searchedEmployee);

	}

	public WebElement validatedExtCompany(final WebDriver driver) {
		return driver.findElement(validatedExtCompany);

	}

	public WebElement purposeOfUsage(final WebDriver driver) {
		return driver.findElement(purposeOfUsage);

	}

	public WebElement dateValidated(final WebDriver driver) {
		return driver.findElement(dateValidated);

	}
	
	public WebElement validatedEmployeeInfo(final WebDriver driver) {
		return driver.findElement(okChecked);

	}

	/**
	 * Function to click on Clicking on Change Employee CWID to Contractor-CWID Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnChangeEmpCwidLink() throws InterruptedException {
		// Clicking on Change Employee CWID to Contractor-CWID Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// changeEmpCwidLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(changeEmpCwidLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Change Employee CWID to Contractor-CWID Link");
	}

	/**
	 * Function to click on search Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchButton() throws InterruptedException {
		// Clicking on search Button
		objBaseTest.explicitWait(searchButton);
		Thread.sleep(2000);
		// searchButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on search Button to select Employee");
	}

	/**
	 * Function to Select first row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowSelect() throws InterruptedException {
		// Clicking on first row CWID
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// firstRowSelect(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowSelect(BaseTest.driver));
		selectedCWID = firstRowSelect(BaseTest.driver).getText().split(" ");
		objBaseTest.logResults("Requested Immediate Offboard for Employee cwid :  " + selectedCWID[0]);
		// Clicking on Ok button
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
		Thread.sleep(3000);
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next button");

	}

	/**
	 * Function to Click on Finish button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishbutton() throws InterruptedException {
		// Clicking on finish button
		objBaseTest.explicitWait(finishbutton);
		Thread.sleep(2000);
		// finishbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on finish button");
	}

	/**
	 * Function to Select Future Sponsor
	 * 
	 * @throws InterruptedException
	 */
	public void selectingFutureSponsor() throws InterruptedException {

		// Selecting Future Sponsor
		Thread.sleep(18000);
		objBaseTest.scrollInView(newSponsor(BaseTest.driver));
		Thread.sleep(2000);
		newSponsor(BaseTest.driver).sendKeys(Keys.BACK_SPACE);
		Thread.sleep(2000);
		newSponsor(BaseTest.driver).sendKeys(futureSponsorCWID);
		Thread.sleep(4000);
		newSponsor(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Selecting Future Sponsor as " + futureSponsorCWID);
	}

	/**
	 * Function to Check Exceptions
	 * 
	 * @throws InterruptedException
	 */
	public void checkValidation() throws InterruptedException {

		// Clicking on Next button without entering Mandatory Fields

		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

		// Sending Keys on validToDate
		Thread.sleep(2000);
		objBaseTest.fluentWait();

		// Sending keys on "Valid To Date" as Past Date
		Thread.sleep(1000);
		objBaseTest.fluentWait();
		validToDate(BaseTest.driver).sendKeys(pastDate + Keys.ENTER);
		Thread.sleep(2000);
		objBaseTest.logResults("Sending keys on \"Valid To\" as Past Date to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert1 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		objBaseTest.logResults("Validation Error thrown : " + alert1);

		// Sending keys on "Valid To Date" as more than 365 to check Expection
		Thread.sleep(2000);
		validToDate(BaseTest.driver).sendKeys(futureDate + Keys.ENTER);
		Thread.sleep(2000);
		objBaseTest.logResults("Sending keys on \"Valid To\" date as more than 365 to check for validation error");
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next button");
		Thread.sleep(2000);
		String alert2 = (BaseTest.driver).switchTo().alert().getText();
		Thread.sleep(1000);
		(BaseTest.driver).switchTo().alert().accept();
		objBaseTest.logResults("Validation Error thrown : " + alert2);

	}

	/**
	 * Function to Select correct Valid To Date
	 * 
	 * @throws InterruptedException
	 */
	public void selectingCorrectValidToDate() throws InterruptedException {

		Thread.sleep(2000);
		validToDate(BaseTest.driver).click();
		Thread.sleep(1000);
		// Selecting a valid date within 6 months
		for (int i = 0; i < 6; i++) {
			calenderNext(BaseTest.driver).click();
			Thread.sleep(1000);
		}
		validDate(BaseTest.driver).click();
		objBaseTest.logResults("Selecting a Valid To Date within 6 months");
		Thread.sleep(2000);
		correctDate = validToDate(BaseTest.driver).getAttribute("value");
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button after entering fields");

	}

	/**
	 * Function to Validate the Employee Data Change
	 * 
	 * @throws InterruptedException
	 */
	public void validateEmployeeDataChange() throws InterruptedException {

		Thread.sleep(6000);
		identityLink(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Identity Link");

		// Sending Keys in "Search For" to find the Employee identity
		objBaseTest.explicitWait(searchFor);
		Thread.sleep(3000);
		searchFor(BaseTest.driver).sendKeys( selectedCWID[0] + Keys.ENTER);
		// objBaseTest.logResults("Searching for CWID " + selectedCWID[0] +" employee
		// data");

		// Clicking on Searched Employee
		objBaseTest.explicitWait(searchedEmployee);
		Thread.sleep(2000);
		searchedEmployee(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Searched Employee to get data");

		// Validate External Company Name
		Thread.sleep(6000);
		objBaseTest.scrollInView(validatedExtCompany(BaseTest.driver));
		Thread.sleep(1000);
		String actualCompany = validatedExtCompany(BaseTest.driver).getAttribute("value");
		Assert.assertEquals(company, actualCompany);
		objBaseTest.logResults("External Company Name is updated and validated");

		// Validate Purpose of Usage
		objBaseTest.scrollInView(purposeOfUsage(BaseTest.driver));
		Thread.sleep(3000);
		Select select = new Select(purposeOfUsage(BaseTest.driver));
		WebElement option = select.getFirstSelectedOption();
		String actualPurposeOfUsage = option.getText();
		Assert.assertEquals(givenPurposeOfUsage, actualPurposeOfUsage);
		objBaseTest.logResults("Purpose of Usage is validated as :" + givenPurposeOfUsage);

		// Validate Valid To Date
		objBaseTest.scrollInView(dateValidated(BaseTest.driver));
		Thread.sleep(1000);
		String actualValidToDate = dateValidated(BaseTest.driver).getAttribute("value");
		Assert.assertEquals(correctDate, actualValidToDate);
		objBaseTest.logResults("Valid To Date is updated and validated");
		
		
		Thread.sleep(2000);
		validatedEmployeeInfo(BaseTest.driver).click();
		objBaseTest.logResults("Data of Employee was Validated");
		objBaseTest.explicitWait(searchedEmployee);
		Thread.sleep(2000);
		objBaseTest.CloseBrowser();
		
	}

	/**
	 * Function to send keys on display name
	 * 
	 * @throws InterruptedException
	 * 
	 */
	public void sendingKeysOnDisplayName() throws InterruptedException {
		// Sending Keys on display name
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		displayName(BaseTest.driver).sendKeys(empCwidInitial + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on display name as : " + empCwidInitial);
	}

	/**
	 * Function for Sending Keys in external Company Name
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnExternalCompany() throws InterruptedException {
		// Sending Keys on external Company Name
		Thread.sleep(1000);
		extCompanyName(BaseTest.driver).clear();
		Thread.sleep(1000);
		extCompanyName(BaseTest.driver).sendKeys(company);
		objBaseTest.logResults("Sending Keys for external Company Name");
	}

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
