package page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForNewAccountLDAPPage {
	BaseTest objBaseTest = new BaseTest();
	String CWIDSelectedFornewAccountCreation = null;

	// Creator locators
	private By requestNewAccountLink = By.xpath(
			"//span[contains(@title,'request a LDAP account')]//span[contains(text(),'Request Corporate LDAP Account (Intranet)')]");
	private By reasonForRequest = By.id("1002917");
	private By accountRequestTab = By.id("ui-id-3");
	private By searchBtnForCWID = By.xpath("//*[@id='1002531_btn']");
	private By searchingCwid = By.xpath("(//table[@class='ui-search-table'])[1]//tr[1]//td[2]//input");
	private By requestNewAccountButton = By.xpath("//input[contains(@value,'Request new account')]");
	private By okButtonforMandatoryCheck = By.xpath("//button[contains(text(),'OK')]");
	private By mandatoryPopUpMessageLabel = By.id("ui-id-2");
	private By firstRowCwid = By.xpath("//table[@id='1000172_selection-grid-grid']//tr[2]//td[2]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	
	
	// Returning WebElement from respective locators

	public WebElement requestNewAccountLink(final WebDriver driver) {
		return driver.findElement(requestNewAccountLink);
	}

	public WebElement reasonForRequest(final WebDriver driver) {
		return driver.findElement(reasonForRequest);
	}

	public WebElement accountRequestTab(final WebDriver driver) {
		return driver.findElement(accountRequestTab);
	}

	public WebElement searchBtnForCWID(final WebDriver driver) {
		return driver.findElement(searchBtnForCWID);
	}

	public WebElement searchingCwid(final WebDriver driver) {
		return driver.findElement(searchingCwid);
	}

	public WebElement requestNewAccountButton(final WebDriver driver) {
		return driver.findElement(requestNewAccountButton);
	}

	public WebElement okButtonforMandatoryCheck(final WebDriver driver) {
		return driver.findElement(okButtonforMandatoryCheck);
	}

	public WebElement mandatoryPopUpMessageLabel(final WebDriver driver) {
		return driver.findElement(mandatoryPopUpMessageLabel);
	}

	public WebElement firstRowCwid(final WebDriver driver) {
		return driver.findElement(firstRowCwid);
	}

	public WebElement okBtnForSelectingCwid(final WebDriver driver) {
		return driver.findElement(okBtnForSelectingCwid);
	}

	
	/**
	 * Function to Request New Account
	 * 
	 * @param reasonForRequestEntered
	 * @throws InterruptedException
	 */
	public void creatingNewLDAPAccount(String reasonForRequestEntered) throws InterruptedException {

		// Changing the tab inside service Link
		objBaseTest.fluentWait();
		Thread.sleep(8000);
		accountRequestTab(BaseTest.driver).click();
		objBaseTest.logResults("Account Request Tab Opened");

		// Clicking on Request Secondary CWID Link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLink = BaseTest.driver.findElements(requestNewAccountLink);
		chckLink.get(0).click();
		objBaseTest.logResults("Clicking on Request New Account Link");
		objBaseTest.fluentWait();
		Thread.sleep(17000);

		// clicking on search button for searching the cwid
		searchBtnForCWID(BaseTest.driver).click();
		objBaseTest.fluentWait();
		Thread.sleep(3000);
		objBaseTest.logResults("clicking on search button for searching the cwid");

		// Enter the input (CWID) in the search option
		searchingCwid(BaseTest.driver).sendKeys("m");
		searchingCwid(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Entered the user input (CWID) in the search option");
		objBaseTest.fluentWait();
		Thread.sleep(10000);

		// Storing the value of the CWID for which the new account is created
		objBaseTest.clickUsingJavascript(firstRowCwid(BaseTest.driver));
		CWIDSelectedFornewAccountCreation = firstRowCwid(BaseTest.driver).getText();
		objBaseTest.logResults("Requesting for new account for the cwid-:" + CWIDSelectedFornewAccountCreation);
		okBtnForSelectingCwid(BaseTest.driver).click();

		// Clicking on Request for new Account button
		objBaseTest.fluentWait();
		Thread.sleep(1000);
		requestNewAccountButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request for new Account button");
		objBaseTest.fluentWait();
		Thread.sleep(1000);

		// Getting the text of Warning popup model window
		okButtonforMandatoryCheck(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on madnatory PopUp Message Ok Button");

		objBaseTest.scrollInView(reasonForRequest(BaseTest.driver));
		objBaseTest.enterDataUsingJavascript(reasonForRequest(BaseTest.driver), reasonForRequestEntered);
		objBaseTest.logResults("Entering reason For Request field as" + reasonForRequestEntered);

		// Clicking on Request for new Account button
		objBaseTest.fluentWait();
		Thread.sleep(1000);
		requestNewAccountButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request for new Account button");
		objBaseTest.fluentWait();
		Thread.sleep(18000);

	}
	

}
