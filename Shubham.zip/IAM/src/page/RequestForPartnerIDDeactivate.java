package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForPartnerIDDeactivate {

	BaseTest objBaseTest = new BaseTest();

	String sponser = "BBSS1";


	// Creator locators
	private By deactivatePartnerIDLink = By.xpath("//span[(text()='Deactivate Partner ID')]");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By backButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='< Back']");
	private By popUpMessageLabel = By.id("ui-id-1");
	private By popUpMessageOkButton = By.xpath("//*[contains(text(),'OK')]");
	private By sponsorCWID = By.xpath("//input[@id='1029498_textbox-selectized']");
	private By searchPIDbutton = By.xpath("//a[@id='1029499_addbtn']");
	private By firstRowPID = By.xpath("//table[@id='selection-grid-grid']//tbody/tr[2]/td[3]");
	private By okButton = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='OK']");
	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement deactivatePartnerIDLink(final WebDriver driver) {
		return driver.findElement(deactivatePartnerIDLink);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement popUpMessageLabel(final WebDriver driver) {
		return driver.findElement(popUpMessageLabel);
	}

	public WebElement popUpMessageOkButton(final WebDriver driver) {
		return driver.findElement(popUpMessageOkButton);
	}

	public WebElement sponsorCWID(final WebDriver driver) {
		return driver.findElement(sponsorCWID);
	}

	public WebElement searchPIDbutton(final WebDriver driver) {
		return driver.findElement(searchPIDbutton);
	}

	public WebElement firstRowPID(final WebDriver driver) {
		return driver.findElement(firstRowPID);
	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);
	}

	public WebElement backButton(final WebDriver driver) {
		return driver.findElement(backButton);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function for clicking on Deactivate Partner ID Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDeactivatePartnerIDLink() throws InterruptedException {
		// Clicking on Deactivate Partner ID Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// deactivatePartnerIDLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(deactivatePartnerIDLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Deactivate Partner ID Link");
	}

	/**
	 * Function for Sending Keys for search Sponser CWID
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnSponsorCWID() throws InterruptedException {
		// Sending Keys for search Sponser CWID
		Thread.sleep(2000);
		objBaseTest.scrollInView(sponsorCWID(BaseTest.driver));
		sponsorCWID(BaseTest.driver).sendKeys(sponser);
		Thread.sleep(4000);
		sponsorCWID(BaseTest.driver).sendKeys(Keys.ENTER);
		objBaseTest.logResults("Sending Keys for search Sponser CWID");
	}

	/**
	 * Function to Select Partner ID
	 * 
	 * @throws InterruptedException
	 */
	public void selectPartnerID() throws InterruptedException {
		// Clicking on Search Partner ID button
		Thread.sleep(2000);
		searchPIDbutton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Search Partner ID button");
		Thread.sleep(5000);

		// Selecting First Row PID
		objBaseTest.clickUsingJavascript(firstRowPID(BaseTest.driver));
		String[] SelectedPID = firstRowPID(BaseTest.driver).getText().split(" ");
		objBaseTest.logResults("Selecting Partner ID : " + SelectedPID[0]);

		// Clicking on OK button
		Thread.sleep(1000);
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on OK button");

	}

	/**
	 * Function for Deactivating Partner ID
	 * 
	 * @throws InterruptedException
	 */
	public void deactivatingPartnerID() throws InterruptedException {
		// Clicking on Next Button
		Thread.sleep(2000);
		// nextButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next Button");

		// Clicking on Finish Button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(2000);
		finishButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on Finish button");
	}

	/**
	 * Function to Check Exceptions
	 * 
	 * @throws InterruptedException
	 */
	public void checkValidation() throws InterruptedException {

		// Clicking on Next button without entering Mandatory Fields
		objBaseTest.explicitWait(sponsorCWID);
		Thread.sleep(2000);
		nextButton(BaseTest.driver).click();
		objBaseTest.logResults("clicking on next button without entering mandatory fields");

		// Getting the text of Warning popup modal window when not filling mandatory
		// fields
		objBaseTest.fluentWait();
		Thread.sleep(2000);
		String emptyValuePopUpMessageLabelActual = popUpMessageLabel(BaseTest.driver).getText().trim();
		popUpMessageOkButton(BaseTest.driver).click();
		objBaseTest.logResults("Validation Error thrown : " + emptyValuePopUpMessageLabelActual);

	}

	public void submissionState() throws InterruptedException {

		objBaseTest.explicitWait(successMessageLabel);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
