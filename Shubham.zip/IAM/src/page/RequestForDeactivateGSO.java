package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForDeactivateGSO {

	BaseTest objBaseTest = new BaseTest();
	public String selectedCWID = null;
	// Creator locators
	private By deactivateGSO = By.xpath("//span[(text()='Deactivate GSO CWID')]");
	private By searchGsoCwid = By.xpath("//img[@id='1034735_btn']");
	private By enterGsoCwid = By.xpath("//table[@class='ui-jqgrid-htable']/thead/tr[2]/th[3]//input");
	private By gsoCwidPerson = By.xpath("//table[@id='1001479_selection-grid-grid']//tbody/tr[2]/td[3]"); // xpath
	private By gsoCwidPersonOk = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='OK']");
	private By deactivationReason = By.xpath("//textarea[@id='1034734']");
	private By requestDeactivationGSO = By.xpath("//input[@value='Request deactivation']");
	private By viewAllRequest = By.xpath("//div[@id='Dashboard1_widget1_header']//span[text()='View all >']");
	private By approveDeactivationGSO = By.xpath("//a[text()='Approve deactivation of GSO CWID']");
	private By declineDeactivationGsoRequest = By.xpath("//input[@value='Decline request']");
	private By declineReason = By.xpath("//table[@id='1034747WRAPPER']/tbody/tr/td[1]/textarea");
	private By sendCommentRequestor = By.xpath("//input[@value='Send comments to requestor']");
	private By approveDeactivationGsoRequest = By.xpath("//input[@value='Approve deactivation']");
	private By requestMessageLabel = By.xpath(
			"//span[@id='PageMsgsContnr']//td[contains(text(),'Your request has been submitted successfully.')]");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement deactivateGSO(final WebDriver driver) {
		return driver.findElement(deactivateGSO);

	}

	public WebElement searchGsoCwid(final WebDriver driver) {
		return driver.findElement(searchGsoCwid);
	}

	public WebElement enterGsoCwid(final WebDriver driver) {
		return driver.findElement(enterGsoCwid);

	}

	public WebElement GsoCwidPerson(final WebDriver driver)

	{
		return driver.findElement(gsoCwidPerson);
	}

	public WebElement GsoCwidPersonOk(final WebDriver driver)

	{
		return driver.findElement(gsoCwidPersonOk);
	}

	public WebElement deactivationReason(final WebDriver driver)

	{
		return driver.findElement(deactivationReason);
	}

	public WebElement requestDeactivationGSO(final WebDriver driver)

	{
		return driver.findElement(requestDeactivationGSO);
	}

	public WebElement viewAllRequest(final WebDriver driver)

	{
		return driver.findElement(viewAllRequest);
	}

	public WebElement approveDeactivationGSO(final WebDriver driver)

	{
		return driver.findElement(approveDeactivationGSO);
	}

	public WebElement declineDeactivationGsoRequest(final WebDriver driver)

	{
		return driver.findElement(declineDeactivationGsoRequest);
	}

	public WebElement declineReason(final WebDriver driver)

	{
		return driver.findElement(declineReason);
	}

	public WebElement sendCommentRequestor(final WebDriver driver)

	{
		return driver.findElement(sendCommentRequestor);
	}

	public WebElement approveDeactivationGsoRequest(final WebDriver driver)

	{
		return driver.findElement(approveDeactivationGsoRequest);
	}
	
	public WebElement requestMessageLabel(final WebDriver driver) {
		return driver.findElement(requestMessageLabel);

	}
	

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on Deactivate GSO Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDeactivateGSOLink() throws InterruptedException {
		// Clicking on Deactivate GSO Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// Deactivate(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(deactivateGSO(BaseTest.driver));
		objBaseTest.logResults("Clicking on Deactivate GSO");
	}

	/**
	 * Function to click on Search GSO CWID image
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchGsoCwid() throws InterruptedException {
		// Clicking on Search GSO CWID
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// SearchGSOCwid(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchGsoCwid(BaseTest.driver));
		objBaseTest.logResults("Clicking on Search GSO CWID");
	}

	/**
	 * Function to click on GSO CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnGsoCwidPerson() throws InterruptedException {
		// Clicking on Search GSO CWID
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// GSOCwidPerson(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(GsoCwidPerson(BaseTest.driver));
		selectedCWID = GsoCwidPerson(BaseTest.driver).getText();
		objBaseTest.logResults("Requested UID for the cwid-:"+ selectedCWID);
	}

	/**
	 * Function to click on GSO CWID Ok button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnGsoCwidPersonOk() throws InterruptedException {
		// Clicking on GSO CWID Ok button
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// GSOCwidPersonOk(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(GsoCwidPersonOk(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
	}

	/**
	 * Function to click on Reason for Deactivating GSO CWID text area
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDeactivationReason() throws InterruptedException {
		// Clicking on Reason for Deactivating GSO CWID text area
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// deactivationReason(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(deactivationReason(BaseTest.driver));
		objBaseTest.logResults("Clicking on Deactivating GSO description text area");

	}

	/**
	 * Function to click on Request Deactivation Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnrequestDeactivationGSO() throws InterruptedException {
		// Clicking onReason for Request Deactivation Button
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// requestDeactivationGSO(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(requestDeactivationGSO(BaseTest.driver));
		objBaseTest.logResults("Clicking on Request Deactivation Button");
		Thread.sleep(13000);

	}

	/**
	 * Function to click on View all Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnViewAllRequest() throws InterruptedException {
		// Clicking on View all Button
		Thread.sleep(14000);
		objBaseTest.fluentWait();
		// viewAllRequest(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(viewAllRequest(BaseTest.driver));
		objBaseTest.logResults("Clicking on View all Button");

	}

	/**
	 * Function to click on Approve Deactivation Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnApproveDeactivationGSO() throws InterruptedException {
		// Clicking on Approve Deactivation Button
		Thread.sleep(10000);
		objBaseTest.fluentWait();
		// approveDeactivationGSO(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(approveDeactivationGSO(BaseTest.driver));
		objBaseTest.logResults("Clicking on Approve Deactivation Button");

	}

	/**
	 * Function to click on Decline Request Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnDeclineDeactivationGsoRequest() throws InterruptedException {
		// Clicking on Decline Request Button
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// declineDeactivationGsoRequest(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(declineDeactivationGsoRequest(BaseTest.driver));
		objBaseTest.logResults("Clicking on Decline Request Button");

	}

	/**
	 * Function to click on Send comments to Requestor button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSendCommentRequestor() throws InterruptedException {
		// Clicking on Send comment to Requestor Button
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// sendCommentRequestor(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(sendCommentRequestor(BaseTest.driver));
		objBaseTest.logResults("Clicking on Send comments to Requestor button");
		Thread.sleep(10000);

	}

	/**
	 * Function to click on approve Deactivation Gso Request button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnApproveDeactivationGsoRequest() throws InterruptedException {
		// Clicking on Approve Deactivation Button
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// sendCommentRequestor(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(approveDeactivationGsoRequest(BaseTest.driver));
		objBaseTest.logResults("Clicking on Approve Deactivation Button");
		Thread.sleep(10000);

	}

	/**
	 * Function to Send keys on GSO CWID search text area
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnEnterGsoCwid() throws InterruptedException {

		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// Sending keys into the GSO CWID search text area
		enterGsoCwid(BaseTest.driver).sendKeys("GSOSK" + Keys.ENTER);
		objBaseTest.logResults("Sending text on search");

	}

	/**
	 * Function to Send keys on Reason for Deactivating GSO CWID text area
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnDeactivationReason() throws InterruptedException {

		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// Sending keys into the Reason for Deactivating GSO
		deactivationReason(BaseTest.driver).sendKeys("This is a test for Deactivating GSO CWID");
		objBaseTest.logResults("Sending text on Description");

	}

	/**
	 * Function to Send keys on Reason for Declining request text area
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnDeclineReason() throws InterruptedException {

		Thread.sleep(16000);
		objBaseTest.fluentWait();
		// Sending keys into the Reason for Deactivating GSO
		declineReason(BaseTest.driver).sendKeys("This is a test for Declining Request for Deactivation of GSO CWID");
		objBaseTest.logResults("Sending text on Declining request");

	}
	
	
	/**
	 * Function to Check for Request message display
	 * 
	 * @throws InterruptedException
	 */
	
	public void requestState() throws InterruptedException {

		// Assert to check request message.
		Thread.sleep(5000);
		String requestMessagExpected = "Your request has been submitted successfully.";
		String requestMessagActual = requestMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(requestMessagActual, requestMessagExpected);
		objBaseTest.logResults("Checking request submission message label. " + requestMessagActual);
		Reporter.log("Checking request submission message label. " + requestMessagActual);

	}
	
	/**
	 * Function to check submission message display
	 * 
	 * @throws InterruptedException
	 */

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		Thread.sleep(4000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking task success message label. " + succesMessagActual);
		Reporter.log("Checking task success message label. " + succesMessagActual);

	}

}
