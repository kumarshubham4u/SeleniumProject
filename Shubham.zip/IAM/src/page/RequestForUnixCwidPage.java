package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForUnixCwidPage
{
	BaseTest objBaseTest = new BaseTest();
	private By searchBtnForCWID = By.id("1005059_btn");
	private By selectFirstRowForUnixCwid = By.xpath("//table[@id='selection-grid-grid']//tr[2]//td[2]");
	private By okBtnForSelectingCwid = By.xpath("//button[contains(text(),'OK')]");
	private By comments = By.id("1003968");
	private By submitRequestButton = By.id("btnTrans1151646");
	private By unixID = By.id("1003966");
	private By unixID_OkButton = By.xpath("//*[@id='PageButtonContainer']//input[contains(@value,'Ok')]");
	private By successMessageLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
	
	
	// Returning WebElement from respective locators

	public WebElement searchBtnForCWID(final WebDriver driver)
	{
		return driver.findElement(searchBtnForCWID);
	}
	public WebElement selectFirstRowFromTable(final WebDriver driver)
	{
		return driver.findElement(selectFirstRowForUnixCwid);
	}
	public WebElement okBtnForSelectingCwid(final WebDriver driver)
	{
		return driver.findElement(okBtnForSelectingCwid);
	}
	public WebElement comments(final WebDriver driver)
	{
		return driver.findElement(comments);
	}
	public WebElement submitRequestButton(final WebDriver driver)
	{
		return driver.findElement(submitRequestButton);
	}
	public WebElement unixID(final WebDriver driver)
	{
		return driver.findElement(unixID);
	}
	public WebElement unixID_OkButton(final WebDriver driver)
	{
		return driver.findElement(unixID_OkButton);
	}
	public WebElement successMessageLabel(final WebDriver driver)
	{
		return driver.findElement(successMessageLabel);
	}
	

/**
 * Function to create Unix-ID
 * @param comments
 * @throws InterruptedException
 */
	public void creatingRequestUnixID(String comments) throws InterruptedException
	{
		//Clicking on Request Unix ID
		objBaseTest.fluentWait();Thread.sleep(10000);
		objBaseTest.scrollInView(searchBtnForCWID(BaseTest.driver));
		searchBtnForCWID(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request Unix ID Link");

		//Selecting the first row from table
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(selectFirstRowFromTable(BaseTest.driver));
		String requestingCWID = selectFirstRowFromTable(BaseTest.driver).getText();
		System.out.println("requestingCWID"+requestingCWID);
		objBaseTest.logResults("Selecting CWID for Unix Id as :- "+ requestingCWID);
		selectFirstRowFromTable(BaseTest.driver).click();
		
		
		//Clicking on Ok Button 
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(okBtnForSelectingCwid(BaseTest.driver));
		okBtnForSelectingCwid(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Ok Button ");
		
		//Entering comments
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(comments(BaseTest.driver));
		comments(BaseTest.driver).sendKeys(comments);
		objBaseTest.logResults("Entering comments as:-"+ comments);
		
		//Clicking on Submit request button
		objBaseTest.fluentWait();Thread.sleep(4000);
		objBaseTest.scrollInView(submitRequestButton(BaseTest.driver));
		submitRequestButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Submit request Button ");
	}
	
	/**
	 * Function to get the Unix-ID and to submit a request
	 * @throws InterruptedException
	 */
	public void gettingUnixID() throws InterruptedException
	{
		//Getting the unixID Value
		objBaseTest.fluentWait();Thread.sleep(8000);
		objBaseTest.scrollInView(unixID(BaseTest.driver));
		String unixIDValue = unixID(BaseTest.driver).getAttribute("value");
		System.out.println("unixIDValue"+unixIDValue);
		objBaseTest.logResults("UnixID Value:-"+ unixIDValue);
		
		//Clicking on Ok button 
		objBaseTest.fluentWait();Thread.sleep(8000);
		objBaseTest.scrollInView(unixID_OkButton(BaseTest.driver));
		unixID_OkButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on unixID Ok Button");
		Thread.sleep(18000);
		objBaseTest.fluentWait();
		
	}
}
