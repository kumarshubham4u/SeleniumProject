package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForUID {

	BaseTest objBaseTest = new BaseTest();
	
	public String selectedCWID = null;
	// Creator locators
	private By createUnixId = By.xpath("//span[(text()='Create Unix ID \"Admin Service\"')]");
	private By searchButton = By.xpath("//img[@id='1011129_btn']");
	private By purposeOfUsage = By.xpath("//input[@id='gs_1000685_selection-grid-grid_c1000377']");
	private By firstRowSelect = By.xpath("//table[@id='1000685_selection-grid-grid']//tr[2]//td[3]");
	private By okButton = By.xpath("//button[text()='OK']");
	private By comments = By.xpath("//table[@id='1010412WRAPPER']//textarea[@id='1010412']");
	private By createUIDbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Create Unix ID']");
	private By finishbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement createUnixId(final WebDriver driver) {
		return driver.findElement(createUnixId);

	}

	public WebElement searchButton(final WebDriver driver) {
		return driver.findElement(searchButton);

	}

	public WebElement purposeOfUsage(final WebDriver driver) {
		return driver.findElement(purposeOfUsage);

	}

	public WebElement firstRowSelect(final WebDriver driver) {
		return driver.findElement(firstRowSelect);

	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}
	
	public WebElement comments(final WebDriver driver) {
		return driver.findElement(comments);

	}

	public WebElement createUIDbutton(final WebDriver driver) {
		return driver.findElement(createUIDbutton);

	}

	public WebElement finishbutton(final WebDriver driver) {
		return driver.findElement(finishbutton);

	}
	
	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}
	/**
	 * Function to click on Create Unix ID "Admin Service"
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnCreateUnixId() throws InterruptedException {
		// Clicking on Create Unix ID "Admin Service"
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// createUnixId(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(createUnixId(BaseTest.driver));
		objBaseTest.logResults("Clicking on Create Unix ID Admin Service");
	}

	/**
	 * Function to click on search Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchButton() throws InterruptedException {
		// Clicking on search Button
		Thread.sleep(10000);
		objBaseTest.fluentWait();
		// searchButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on search Button");
	}

	/**
	 * Function to Select first row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowSelect() throws InterruptedException {
		// Clicking on first row CWID
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// firstRowSelect(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowSelect(BaseTest.driver));
		selectedCWID = firstRowSelect(BaseTest.driver).getText();
		objBaseTest.logResults("Requested UID for the cwid-:"+ selectedCWID);
	}

	/**
	 * Function to Click on Ok button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnOkButton() throws InterruptedException {
		// Clicking on Ok button
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
	}

	/**
	 * Function to Click on Create Unix ID button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnCreateUIDbutton() throws InterruptedException {
		// Clicking on Create Unix ID button
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// createUIDbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(createUIDbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Create Unix ID button");
	}

	/**
	 * Function to Click on Finish button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishbutton() throws InterruptedException {
		// Clicking on finish button
		objBaseTest.explicitWait(finishbutton);
		Thread.sleep(2000);
		// finishbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on finish button");
		Thread.sleep(10000);
	}

	
	/**
	 * Function to send keys on Comment box
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnComments() throws InterruptedException {
		// Sending Keys on Comment box
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		comments(BaseTest.driver).sendKeys("This is a test to request UID");
		objBaseTest.logResults("Sending Keys on Comments box");
	}

	/**
	 * Function to send keys on Purpose of Usage as Primary Employee
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnPurposeOfUsagePE() throws InterruptedException {
		// Sending Keys on Purpose of Usage as 00
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		purposeOfUsage(BaseTest.driver).sendKeys("00" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on Purpose of Usage as Primary Employee");
	}

	/**
	 * Function to send keys on Purpose of Usage as Primary Contractor
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnPurposeOfUsagePC() throws InterruptedException {
		// Sending Keys on Purpose of Usage as 12
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		purposeOfUsage(BaseTest.driver).sendKeys("12" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on Purpose of Usage as Primary Contractor");
	}

	/**
	 * Function to send keys on Purpose of Usage as Secondary Employee
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnPurposeOfUsageSE() throws InterruptedException {
		// Sending Keys on Purpose of Usage as 09
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		purposeOfUsage(BaseTest.driver).sendKeys("09" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on Purpose of Usage as Secondary Employee");
	}

	/**
	 * Function to send keys on Purpose of Usage as Secondary Contractor
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnPurposeOfUsageSC() throws InterruptedException {
		// Sending Keys on Purpose of Usage as 19
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		purposeOfUsage(BaseTest.driver).sendKeys("19" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on Purpose of Usage as Secondary Contractor");
	}

	/**
	 * Function to send keys on Purpose of Usage as Machine
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnPurposeOfUsageMachine() throws InterruptedException {
		// Sending Keys on Purpose of Usage as 88
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		purposeOfUsage(BaseTest.driver).sendKeys("88" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on Purpose of Usage as Machine");
	}

	
	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
