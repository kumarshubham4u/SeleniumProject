package page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import commonFunctions.BaseTest;

public class RequestForSecondaryCwidPage 
{
	BaseTest objBaseTest = new BaseTest();
	String secondaryCWIDGenerated = null;

	
	private By requestSecondaryCWIDLink = By.xpath("//span[contains(@title,'request a CWID for testing ')]//span[contains(text(),'Request Secondary CWID')]");
	private By reasonForRequest = By.id("1001452");
	private By radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk = By.id("1035471_1");
	private By checboxAD_Account = By.id("1023696");
	private By requestForSecondaryCWIDButton = By.id("btnTrans1013993");
	private By successMessageLabel= By.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your request has been submitted successfully.')]");

	private By createSecondaryCWIDLinkAdmService = By.xpath(
			"//span[contains(@title,'Request a secondary CWID')]//span[contains(text(),'Create Secondary CWID')]");
	private By checboxAD_AccountAdmService = By.id("1035476");
	private By selectCwidTestboxAdmService = By.id("1011555");
	private By nextButtonAdmService = By.xpath("//input[@value='Next >']");
	private By finishButtonForSecondaryCWIDAdmService = By.xpath("//input[@value='Finish']");
	private By successMessageLabelAdmService = By
			.xpath("//span[@id='PageMsgsContnr']//td[contains(text(),'Your task has been completed successfully.')]");
	private By AdAccountTable = By.xpath("(//table[contains(@id,'PanelSection')])[3]");
	private By ProcessStepIdSpan = By.id("ProcessStepIdSpan");
	private By SecondaryCwidgenerated = By.id("1024077");



	// Returning WebElement from respective locators
	
	public WebElement requestSecondaryCWIDLink(final WebDriver driver)
	{
		return driver.findElement(requestSecondaryCWIDLink);
	}
	public WebElement reasonForRequest(final WebDriver driver)
	{
		return driver.findElement(reasonForRequest);
	}
	public WebElement radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(final WebDriver driver)
	{
		return driver.findElement(radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk);
	}

	public WebElement checboxAD_Account(final WebDriver driver)
	{
		return driver.findElement(checboxAD_Account);
	}

	public WebElement requestForSecondaryCWIDButton(final WebDriver driver)
	{
		return driver.findElement(requestForSecondaryCWIDButton);
	}
	public WebElement successMessageLabel(final WebDriver driver)
	{
		return driver.findElement(successMessageLabel);
	}

	public WebElement createSecondaryCWIDLinkAdmService(final WebDriver driver) {
		return driver.findElement(createSecondaryCWIDLinkAdmService);
	}

	public WebElement checboxAD_AccountAdmService(final WebDriver driver) {
		return driver.findElement(checboxAD_AccountAdmService);
	}

	public WebElement selectCwidTestboxAdmService(final WebDriver driver) {
		return driver.findElement(selectCwidTestboxAdmService);
	}

	public WebElement nextButtonAdmService(final WebDriver driver) {
		return driver.findElement(nextButtonAdmService);
	}

	public WebElement finishButtonForSecondaryCWIDAdmService(final WebDriver driver) {
		return driver.findElement(finishButtonForSecondaryCWIDAdmService);
	}

	public WebElement successMessageLabelAdmService(final WebDriver driver) {
		return driver.findElement(successMessageLabelAdmService);
	}

	public WebElement AdAccountTable(final WebDriver driver) {
		return driver.findElement(AdAccountTable);
	}

	public WebElement ProcessStepIdSpan(final WebDriver driver) {
		return driver.findElement(ProcessStepIdSpan);
	}

	public WebElement SecondaryCwidgenerated(final WebDriver driver) {
		return driver.findElement(SecondaryCwidgenerated);
	}





	/**
	 *  Function to create secondary CWID
	 * @param reasonForRequestEntered
	 * @param ADAccount
	 * @param radioCyberArk
	 * @throws InterruptedException
	 */
	public void creatingSecondaryCWIDLink(String reasonForRequestEntered,String ADAccount, String radioCyberArk) throws InterruptedException
	{
		//Clicking on Request Secondary CWID Link
		objBaseTest.fluentWait();Thread.sleep(4000);
		List<WebElement> chckLink= BaseTest.driver.findElements(requestSecondaryCWIDLink);
		System.out.println(chckLink.size());
		chckLink.get(1).click();
		objBaseTest.logResults("Clicking on Request Secondary CWID Link");


		//select Purpose of usage- need to add condition to check
		if(radioCyberArk.equalsIgnoreCase("SelectCyberArkRadioButton"))
		{
			Thread.sleep(3000);
			objBaseTest.scrollInView(radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(BaseTest.driver));
			radioButton_secondary_CWID_Privileged_Access_Mangmt_CyberArk(BaseTest.driver).click();
			objBaseTest.logResults("Clicking on Secondary CWID for Privileged Access Management - CyberArk radio button");
		}


		//Clicking on Request Secondary CWID Link
		objBaseTest.fluentWait();Thread.sleep(3000);

		objBaseTest.scrollInView(reasonForRequest(BaseTest.driver));
		objBaseTest.enterDataUsingJavascript(reasonForRequest(BaseTest.driver),reasonForRequestEntered);
		objBaseTest.logResults("Entering reason For Request field as"+ reasonForRequestEntered );

		//Uncheck the checkbox i.e without AD account
		if(ADAccount.equalsIgnoreCase("WithOut_ADAccount"))
		{
			Thread.sleep(1000);
			checboxAD_Account(BaseTest.driver).click();
			objBaseTest.logResults("Uncheck the checkbox i.e without AD account");
		}


		// Clicking on Request for Secondary CWID button
		objBaseTest.fluentWait();Thread.sleep(1000);
		requestForSecondaryCWIDButton(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Request for Secondary CWID button");
		objBaseTest.fluentWait();Thread.sleep(15000);


	}


	/***
	 * Function to create secondary CWID for AD Content admin
	 * 
	 * @param ADAccount
	 * @param reasonForRequestEntered
	 * @throws InterruptedException
	 */

	public void creatingSecondaryCWIDLinkAdminService(String ADAccount, String reasonForRequestEntered)
			throws InterruptedException {
		

		// Clicking on Request Secondary CWID Link
		objBaseTest.fluentWait();
		Thread.sleep(4000);
		List<WebElement> chckLinkAdminService = BaseTest.driver.findElements(createSecondaryCWIDLinkAdmService);
		System.out.println(chckLinkAdminService.size());
		chckLinkAdminService.get(0).click();
		objBaseTest.logResults("Clicking on Request Secondary CWID Link");

		objBaseTest.fluentWait();
		Thread.sleep(3000);

		if (reasonForRequestEntered.equalsIgnoreCase("Employee"))
		{
			selectCwidTestboxAdmService(BaseTest.driver).sendKeys("BBSE12");
		} else 
		{
			selectCwidTestboxAdmService(BaseTest.driver).sendKeys("BBSC8");
		}
		selectCwidTestboxAdmService(BaseTest.driver).sendKeys(Keys.TAB);

		// Uncheck the checkbox i.e without AD account
		objBaseTest.scrollInView(checboxAD_AccountAdmService(BaseTest.driver));
		if (ADAccount.equalsIgnoreCase("WithOut_ADAccount")) {
			Thread.sleep(1000);
			checboxAD_AccountAdmService(BaseTest.driver).click();
		}
		objBaseTest.fluentWait();
		Thread.sleep(1000);

		// Clicking on Next Button for Secondary CWID
		nextButtonAdmService(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on Next Button for Secondary CWID ");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(AdAccountTable(BaseTest.driver));
		Thread.sleep(2000);

		// Clicking on confirm page Next Button for Secondary CWID
		nextButtonAdmService(BaseTest.driver).click();
		objBaseTest.logResults("Clicking on confirm page Next Button for Secondary CWID ");
		objBaseTest.fluentWait();
		Thread.sleep(15000);
		objBaseTest.scrollInView(ProcessStepIdSpan(BaseTest.driver));
		Thread.sleep(2000);

		// Stroing the new generated Secondary CWID
		secondaryCWIDGenerated = SecondaryCwidgenerated(BaseTest.driver).getText().trim();
		objBaseTest.logResults("New Secondary CWID Generated -:" + secondaryCWIDGenerated);

		// Clicking on finish Button for Secondary CWID
		finishButtonForSecondaryCWIDAdmService(BaseTest.driver).click();
		objBaseTest.logResults("Request placed successfully for Secondary CWID ");
		objBaseTest.fluentWait();
		Thread.sleep(15000);

	}


}
