package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForImmediateOffboardEmployeeGHR {

	BaseTest objBaseTest = new BaseTest();

	public String selectedCWID = null;
	String newSponsorCWID = "BCSE10";
	String offboardCWID1 = "BCSE";
	// Creator locators
	private By immediateOffboardLink = By.xpath("//span[(text()='Immediate Offboard employee GHR')]");
	private By searchButton = By.xpath("//img[@id='1036407_btn']");

	private By identityID = By.xpath("//input[@id='gs_1000918_selection-grid-grid_c950']");
	private By displayName = By.xpath("//input[@id='gs_selection-grid-grid_c-40']");

	private By firstRowSelect = By.xpath("//table[@id='1000918_selection-grid-grid']//tr[2]//td[2]");

	private By okButton = By.xpath("//button[text()='OK']");
	private By newSponsor = By.xpath("//input[@id='1036511_textbox-selectized']");
	private By createUIDbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Create Unix ID']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Next >']");
	private By finishbutton = By.xpath("//div[@id='PageButtonContainer']//input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement immediateOffboardLink(final WebDriver driver) {
		return driver.findElement(immediateOffboardLink);

	}

	public WebElement searchButton(final WebDriver driver) {
		return driver.findElement(searchButton);

	}

	public WebElement identityID(final WebDriver driver) {
		return driver.findElement(identityID);

	}

	public WebElement displayName(final WebDriver driver) {
		return driver.findElement(displayName);

	}

	public WebElement firstRowSelect(final WebDriver driver) {
		return driver.findElement(firstRowSelect);

	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}

	public WebElement newSponsor(final WebDriver driver) {
		return driver.findElement(newSponsor);

	}

	public WebElement createUIDbutton(final WebDriver driver) {
		return driver.findElement(createUIDbutton);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement finishbutton(final WebDriver driver) {
		return driver.findElement(finishbutton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on Clicking on Immediate Offboard employee GHR Link
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnImmediateOffboardLink() throws InterruptedException {
		// Clicking on Immediate Offboard employee GHR Link
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// immediateOffboardLink(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(immediateOffboardLink(BaseTest.driver));
		objBaseTest.logResults("Clicking on Immediate Offboard employee GHR Link");
	}

	/**
	 * Function to click on search Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnSearchButton() throws InterruptedException {
		// Clicking on search Button
		objBaseTest.explicitWait(searchButton);
		Thread.sleep(2000);
		// searchButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(searchButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on search Button");
	}

	/**
	 * Function to Select first row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowSelect() throws InterruptedException {
		// Clicking on first row CWID
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		// firstRowSelect(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowSelect(BaseTest.driver));
		selectedCWID = firstRowSelect(BaseTest.driver).getText();
		objBaseTest.logResults("Requested Immediate Offboard for Employee cwid :  " + selectedCWID);
	}

	/**
	 * Function to Click on Ok button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnOkButton() throws InterruptedException {
		// Clicking on Ok button
		Thread.sleep(3000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Ok button");
		Thread.sleep(3000);
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next button");
	}


	/**
	 * Function to Click on Finish button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishbutton() throws InterruptedException {
		// Clicking on finish button
		objBaseTest.explicitWait(finishbutton);
		Thread.sleep(2000);
		// finishbutton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishbutton(BaseTest.driver));
		objBaseTest.logResults("Clicking on finish button");
		Thread.sleep(10000);
	}

	/**
	 * Function to Select New Sponsor
	 * 
	 * @throws InterruptedException
	 */
	public void selectingNewSponsor() throws InterruptedException {

		// Selecting New Sponsor

		objBaseTest.explicitWait(newSponsor);
		Thread.sleep(2000);
		newSponsor(BaseTest.driver).sendKeys(newSponsorCWID);
		Thread.sleep(8000);
		newSponsor(BaseTest.driver).sendKeys(Keys.TAB);
		objBaseTest.logResults("Selecting New Sponsor as " + newSponsorCWID);
		Thread.sleep(3000);
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next button");
	}

	/**
	 * Function to Send Keys on identityID to search Employee to offboard
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnIdentityID1() throws InterruptedException {
		// Sending Keys on identityID to search Employee to offboard
		Thread.sleep(5000);
		objBaseTest.fluentWait();
		identityID(BaseTest.driver).sendKeys(offboardCWID1 + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on identityID to search Employee to offboard");
	}

	/**
	 * Function to send keys on identityID as "BCSE" type employee
	 * 
	 * @throws InterruptedException
	 */
	public void sendingKeysOnIdentityID2() throws InterruptedException {
		// Sending Keys on identityID as "BC" type employee
		Thread.sleep(7000);
		objBaseTest.fluentWait();
		identityID(BaseTest.driver).sendKeys("IM" + Keys.ENTER);
		objBaseTest.logResults("Sending Keys on identityID as \"IM\" type employee");
	}

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
