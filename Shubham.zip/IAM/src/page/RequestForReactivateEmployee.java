package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import commonFunctions.BaseTest;

public class RequestForReactivateEmployee {

	BaseTest objBaseTest = new BaseTest();
	public String selectedCWID = null;
	// Creator locators

	private By addButton = By.xpath("//a[@id='1027195_addbtn']");
	private By firstRowCWID = By.xpath("//table[@id='1001157_selection-grid-grid']//tr[2]//td[3]");
	private By okButton = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='OK']");
	private By nextButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Next >']");
	private By finishButton = By.xpath("//div[@id='PageButtonContainer'] //input[@value='Finish']");
	private By successMessageLabel = By
			.xpath("//table[@class='InfoTextPageWideTable']//td[text()='Your task has been completed successfully.']");

	// Returning WebElement from respective locators

	public WebElement addButton(final WebDriver driver) {
		return driver.findElement(addButton);

	}

	public WebElement firstRowCWID(final WebDriver driver) {
		return driver.findElement(firstRowCWID);

	}

	public WebElement okButton(final WebDriver driver) {
		return driver.findElement(okButton);

	}

	public WebElement nextButton(final WebDriver driver) {
		return driver.findElement(nextButton);

	}

	public WebElement finishButton(final WebDriver driver) {
		return driver.findElement(finishButton);

	}

	public WebElement successMessageLabel(final WebDriver driver) {
		return driver.findElement(successMessageLabel);

	}

	/**
	 * Function to click on add Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnAddButton() throws InterruptedException {
		// Clicking on add Button
		Thread.sleep(8000);
		objBaseTest.fluentWait();
		// addButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(addButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on add Button");
	}

	/**
	 * Function to click on first Row CWID
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFirstRowCWID() throws InterruptedException {
		// Clicking on first Row CWID
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// firstRowCWID(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(firstRowCWID(BaseTest.driver));
		selectedCWID = firstRowCWID(BaseTest.driver).getText();
		objBaseTest.logResults("Requested UID for the cwid-:" + selectedCWID);

	}

	/**
	 * Function to click on ok Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnOkButton() throws InterruptedException {
		// Clicking on Ok Button
		Thread.sleep(2000);
		objBaseTest.fluentWait();
		// okButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(okButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on ok Button");
	}

	/**
	 * Function to click on Next Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnNextButton() throws InterruptedException {
		// Clicking on Next Button
		Thread.sleep(4000);
		objBaseTest.fluentWait();
		// nextButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(nextButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Next Button");
	}

	/**
	 * Function to click on Finish Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickingOnFinishButton() throws InterruptedException {
		// Clicking on Finish Button
		objBaseTest.explicitWait(finishButton);
		Thread.sleep(2000);
		// finishButton(BaseTest.driver).click();
		objBaseTest.clickUsingJavascript(finishButton(BaseTest.driver));
		objBaseTest.logResults("Clicking on Finish Button");
		Thread.sleep(15000);
	}

	public void submissionState() throws InterruptedException {

		// Assert to check success message.
		objBaseTest.explicitWait(successMessageLabel);
		Thread.sleep(2000);
		String succesMessagExpected = "Your task has been completed successfully.";
		String succesMessagActual = successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}

}
