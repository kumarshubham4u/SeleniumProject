package testScripts_Process_SBX_Signature_Exception_Handling;

import java.awt.AWTException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.AdminIdentityPage;
import page.HomePage;
import page.SignatureExceptionHandlingSelect_IdentitiesPage;

/**
 *  Process_SBX_Signature_Exception_Handling_S01 - Creating Signature for Exception Handling - Employee login
 *  Pre-requisite:
 *  1.Employee login should have GUMS Signing Security Bulletin - accelerated as active running process
 *   
 * @author EPVRY
 *
 */

@Test
public class Process_SBX_Signature_Exception_Handling_S01 extends BaseTest
{
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	SignatureExceptionHandlingSelect_IdentitiesPage objSignatureExceptionHandlingPage= new SignatureExceptionHandlingSelect_IdentitiesPage();
	AdminIdentityPage objAdminIdentityPage = new AdminIdentityPage();

	public void Process_SBX_Signature_Exception_Handling_S01_Scenario()  throws InterruptedException, AWTException
	{

		String enterReason="Need access for Signature Exception"; 
		// Login in with  Employee 
		// entering userName from windows popup
		robotClassUserNameForEmployee("SignaturExceptionHandling");

		//Entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		//Clicking on Service Link 
		objHomePage.clickingOnServiceLink();

		//Clicking on AccountRequest Zulassungsantrage Link
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		//Clicking on Signature Exception Handling Link
		objHomePage.clickingOnSignatureExceptionHandlingLink();

		//Clicking on Next button without entering fields
		objSignatureExceptionHandlingPage.clickingNextButtonWithoutEnteringFields();

		//Selecting CWID from search icon String requestingCWID=
		String requestingCWID =objSignatureExceptionHandlingPage.selectingCWIDFromSearchIcon();

		//Function to select dropdown from Reason field
		objSignatureExceptionHandlingPage.selectingReasonDropdown(enterReason);

		//Function to click on next button
		objSignatureExceptionHandlingPage.clickNextButton();

		//Function to click on finish button
		objSignatureExceptionHandlingPage.clickingFinishButton();

		//Assert to check success message.
		String succesMessagUnixRequestExpected  ="Your task has been completed successfully.";
		String  succesMessagUnixRequestActual = objSignatureExceptionHandlingPage.successMessageLabel(BaseTest.driver).getText().trim();
		//System.out.println("succesMessagActualApprover"+succesMessagApproverActual) ;
		Assert.assertEquals(succesMessagUnixRequestActual,succesMessagUnixRequestExpected);
		objBaseTest.logResults("Checking success message label as: "+  succesMessagUnixRequestExpected);
		Reporter.log("Checking success message label.");

		//Closing the session 
		BaseTest.driver.close();


		//Login with the Admin to cross verify if signature is signed
		browserInitialization();

		//entering userName from windows popup
		robotClassUserNameForAdmin("ADMIN");	

		//Entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Admin");
		Reporter.log("Login with Admin");

		//Clicking on Set Up Link
		objHomePage.clickingOnSetUpLink();

		//Clicking on Identity Link
		objHomePage.clickingOnidentityLink();

		//Entering search field
		objAdminIdentityPage.searchFieldFromTextBox(requestingCWID);

		//Function to select first record from table
		objAdminIdentityPage.selectFirstRecordFromTable();

		//To verifying the fields to check if bulletin is checked or not
		String bulletinCheckBoxValue =objAdminIdentityPage.checkingBulletingSignedCheckbox();
		if(bulletinCheckBoxValue.equalsIgnoreCase("true"))
		{
			Assert.assertTrue(true);
			objBaseTest.logResults("Bulletin Signed CheckBox checked");
		}
		else
		{
			Assert.assertTrue(false);
			objBaseTest.logResults("Bulletin Signed CheckBox is not checked");
		}

		//To verify Acceptance Date
		
		String acceptanceDateActual =objAdminIdentityPage.acceptanceDate();

		DateFormat sampleDate = new SimpleDateFormat("MM/dd/YYYY");

		Date date = new Date();
		String acceptanceDateExpected = sampleDate.format(date);

		if(acceptanceDateActual.contains(acceptanceDateExpected))
		{
			Assert.assertTrue(true);
			objBaseTest.logResults("AcceptanceDate"+acceptanceDateActual);
		}
		else
		{
			Assert.assertTrue(false);
			objBaseTest.logResults("acceptanceDate not displayed correctly");
		}

	}

}
