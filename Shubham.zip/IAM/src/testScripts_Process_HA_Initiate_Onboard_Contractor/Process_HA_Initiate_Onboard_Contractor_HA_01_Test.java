package testScripts_Process_HA_Initiate_Onboard_Contractor;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForInitiateContractorOnboard;

public class Process_HA_Initiate_Onboard_Contractor_HA_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForInitiateContractorOnboard objConOnboard = new RequestForInitiateContractorOnboard();

	@Test
	public void Process_HA_Initiate_Onboard_Contractor() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on gums Contractor Admin Link
		objHomePage.clickingOnGumsContractorAdmin();

		// Clicking on Initiate Onboard contractor GUMS Non�GHR
		objConOnboard.clickingOnInitiateOnboardLink();

		// Clicking on Next button without entering fields
		objConOnboard.clickingNextButtonWithoutEnteringFields();

		// Sending keys for First name
		objConOnboard.sendingKeysOnFirstName();

		// Sending keys for last name
		objConOnboard.sendingKeysOnLastName();

		// Sending Keys for external Company Name
		objConOnboard.sendingKeysOnExtCompanyName();

		// Sending Keys for Sponser CWID lookup
		objConOnboard.sendingKeysOnSponsorCWIDLookup();

		// Sending Keys for Valid To date
		objConOnboard.sendingKeysOnValidToDate();

		// Sending Keys for External Email
		objConOnboard.sendingKeysOnExtEmail();

		// Sending Keys for External Mobile Country Code
		objConOnboard.sendingKeysOnExtMobileCountryCode();

		// Sending Keys for External Mobile Country Prefix
		objConOnboard.sendingKeysOnExtMobilePrefix();

		// Sending Keys for External Mobile Country Number
		objConOnboard.sendingKeysOnExtMobileNumber();

		// Clicking on Next button after entering fields
		objConOnboard.clickingNextButtonAfterEnteringFields();

		// Fetching generated CWID details and Clicking on Finish button
		objConOnboard.clickingFinishButton();

		// Checking for the submission State
		objConOnboard.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
