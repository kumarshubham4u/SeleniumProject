package testScripts_Process_UAA_Request_UID_admin_UUA_01_Test;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForUID;


//Test case to process UAA Request UID by Admin UUA for *Purpose of Usage as Secondary Contractor*

@Test
public class Process_UAA_Request_UID_byAdmin_UUA_04_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForUID objRequestUid = new RequestForUID();

	public void Process_UAA_Request_UID_byAdmin_UUA() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Account Request Zulassungsantrage
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		// Clicking on Create Unix ID Admin Service
		objRequestUid.clickingOnCreateUnixId();

		//Clicking on search Button
		objRequestUid.clickingOnSearchButton();
		
		//Sending Keys on Purpose of Usage as 19 for Secondary Contractor
		objRequestUid.sendingKeysOnPurposeOfUsageSC();
		
		//Select First Row CWID
		objRequestUid.clickingOnFirstRowSelect();
		
		//Clicking on Ok button
		objRequestUid.clickingOnOkButton();

		//Sending Keys on Comment Box
		objRequestUid.sendingKeysOnComments();
		
		// Clicking on Create Unix ID button
		objRequestUid.clickingOnCreateUIDbutton();
		
		// Clicking on finish button
		objRequestUid.clickingOnFinishbutton();
		
		//Checking for submission state
		objRequestUid.submissionState();
		
		//closing browser
		objBaseTest.CloseBrowser();

	}

}
