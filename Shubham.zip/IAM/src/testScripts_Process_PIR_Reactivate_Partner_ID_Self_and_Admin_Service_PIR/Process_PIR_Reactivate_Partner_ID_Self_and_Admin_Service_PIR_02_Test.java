package testScripts_Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPartnerIDReactivate;

public class Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPartnerIDReactivate objReactive = new RequestForPartnerIDReactivate();

	/*
	 * Test Case for Reactivating Partner ID by Employee
	 */
	@Test
	public void Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR()
			throws InterruptedException, AWTException {

		// Login in with supervisor
		// entering userName from windows popup
		robotClassUserNameForContractor("supervisor");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Partner-ID Request / Partner-ID Antr�ge Link
		objHomePage.clickingOnPartnerIdLink();

		// Clicking on Reactivate Partner ID Link
		objReactive.clickingOnReactivatePartnerIDLink();
		
		//Clicking on Next Button Without Entering mandatory fields
		objReactive.clickingOnNextButton();

		// Selecting Partner ID to reactivate
		objReactive.selectPartnerID();

		// Checking for Validation Error
		objReactive.checkValidation();

		// Reactivating Partner ID
		objReactive.reactivatePartnerID();

		// Checking for the submission State
		objReactive.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
