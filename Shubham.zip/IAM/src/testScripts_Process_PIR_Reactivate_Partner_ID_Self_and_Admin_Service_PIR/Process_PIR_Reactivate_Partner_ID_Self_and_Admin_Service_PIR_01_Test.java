package testScripts_Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPartnerIDReactivate;

public class Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPartnerIDReactivate objReactive = new RequestForPartnerIDReactivate();

	/*
	 * Test Case for Reactivating Partner ID by Identity Admin
	 */
	@Test
	public void Process_PIR_Reactivate_Partner_ID_Self_and_Admin_Service_PIR()
			throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Partner-ID Request / Partner-ID Antr�ge Link
		objHomePage.clickingOnPartnerIdLink();

		// Clicking on Reactivate Partner ID Link
		objReactive.clickingOnReactivatePartnerIDLink();
		
		//Clicking on Next Button Without Entering mandatory fields
		objReactive.clickingOnNextButton();

		// Sending Keys for search Sponsor CWID
		objReactive.sendingKeysOnSponsorCWID();

		// Selecting Partner ID to reactivate
		objReactive.selectPartnerID();
		
		// Checking for Validation Error
		objReactive.checkValidation();
		
		//Reactivating Partner ID
		objReactive.reactivatePartnerID();
		
		// Checking for the submission State
		objReactive.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
