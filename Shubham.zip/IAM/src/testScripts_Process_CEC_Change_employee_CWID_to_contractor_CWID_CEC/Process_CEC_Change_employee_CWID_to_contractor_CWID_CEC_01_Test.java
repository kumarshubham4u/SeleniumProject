package testScripts_Process_CEC_Change_employee_CWID_to_contractor_CWID_CEC;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForChangeEmpCwidToContractorCwid;

public class Process_CEC_Change_employee_CWID_to_contractor_CWID_CEC_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForChangeEmpCwidToContractorCwid objChange = new RequestForChangeEmpCwidToContractorCwid();

	/*
	 * Test script to change Employee CWID of type "DWHE" to Contractor CWID.
	 * 
	 */

	/*
	 * In order to run this script data for Employee type "DWHE" should be present
	 * else the script would fail
	 */

	@Test
	public void Process_CEC_Change_employee_CWID_to_contractor_CWID() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows pop-up
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows pop-up
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Change Employee CWID to Contractor-CWID Link
		objChange.clickingOnChangeEmpCwidLink();

		// Clicking on search Button to select Employee
		objChange.clickingOnSearchButton();

		// Sending Keys on display name as "DWHE" type Employee
		objChange.sendingKeysOnDisplayName();

		// Selecting Employee CWID to Change
		objChange.clickingOnFirstRowSelect();

		// Selecting Future Sponsor
		objChange.selectingFutureSponsor();

		// Sending Keys for external Company Name
		objChange.sendingKeysOnExternalCompany();

		// Checking for Validation error
		objChange.checkValidation();

		// Selecting a correct Valid To Date
		objChange.selectingCorrectValidToDate();

		// Clicking on Finish button
		objChange.clickingOnFinishbutton();

		// Checking for the submission State
		objChange.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		// Re-launch browser for new session

		objBaseTest.browserInitialization();

		// Login in with Admin
		// entering userName from windows popup
		robotClassUserNameForAdmin("ADMIN");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with admin");
		Reporter.log("Login with admin");

		// Clicking on Set Up Link
		objHomePage.clickingOnSetUpLink();

		// Validate Employee Data Change
		objChange.validateEmployeeDataChange();
	}

}
