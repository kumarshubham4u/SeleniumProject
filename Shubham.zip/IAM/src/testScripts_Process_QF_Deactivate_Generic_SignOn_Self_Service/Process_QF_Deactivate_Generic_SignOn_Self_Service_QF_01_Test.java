package testScripts_Process_QF_Deactivate_Generic_SignOn_Self_Service;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.RequestForDeactivateGSO;
import page.HomePage;

//Test Case for Process QF Deactivate GSO for Employee and to get Declined By Supervisor
@Test
public class Process_QF_Deactivate_Generic_SignOn_Self_Service_QF_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForDeactivateGSO objDeactivateGSO = new RequestForDeactivateGSO();

	public void Process_qf_Deactivate_Generic_SignOn_Decline() throws InterruptedException, AWTException {

		// Login in with Employee
		// entering userName from windows popup
		robotClassUserNameForEmployee("employeeGSO");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Deactivate GSO

		objDeactivateGSO.clickingOnDeactivateGSOLink();

		// Clicking on Search GSO CWID

		objDeactivateGSO.clickingOnSearchGsoCwid();

		// Clicking on GSO CWID Person

		objDeactivateGSO.clickingOnGsoCwidPerson();

		// Clicking on GSO CWID OK button

		objDeactivateGSO.clickingOnGsoCwidPersonOk();

		// Clicking on Deactivating GSO CWID text area

		objDeactivateGSO.clickingOnDeactivationReason();

		// Sending keys on Deactivating GSO CWID text area

		objDeactivateGSO.sendingKeysOnDeactivationReason();

		// Clicking on Request Deactivation button

		objDeactivateGSO.clickingOnrequestDeactivationGSO();

		// Checking for Request Submit state

		objDeactivateGSO.requestState();

		// Close the browser

		objBaseTest.CloseBrowser();

		// Re-launch browser for new session

		objBaseTest.browserInitialization();

		// Login in with Supervisor
		// entering userName from windows popup
		robotClassUserNameForEmployee("supervisorGSO");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with supervisor");
		Reporter.log("Login with supervisor");

		// Clicking on View All button

		objDeactivateGSO.clickingOnViewAllRequest();

		// Clicking on Approve Deactivation Button
		objDeactivateGSO.clickingOnApproveDeactivationGSO();

		// Clicking on Decline Request button
		objDeactivateGSO.clickingOnDeclineDeactivationGsoRequest();

		// Sending keys on the reason for Decline Reason text area
		objDeactivateGSO.sendingKeysOnDeclineReason();

		// clicking on Send Comment to Requestor button
		objDeactivateGSO.clickingOnSendCommentRequestor();

		// Checking for submission state
		objDeactivateGSO.submissionState();

	}
}
