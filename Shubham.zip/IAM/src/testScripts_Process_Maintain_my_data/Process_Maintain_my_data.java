package testScripts_Process_Maintain_my_data;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForMaintainingData;

public class Process_Maintain_my_data extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForMaintainingData objMaintain = new RequestForMaintainingData();

	/*
	 * Test Case for Changing the User Data and Validating the Updated data
	 */

	@Test
	public void Maintain_my_data() throws InterruptedException, AWTException {

		// Login in with Contractor
		// entering userName from windows popup
		robotClassUserNameForContractor("ContractorForMaintaingData");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Contractor");
		Reporter.log("Login with Contractor");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Maintain My Data Link
		objMaintain.clickingOnMaintainMyDataLink();

		// Checking for Validation Errors
		objMaintain.checkValidation();

		// Sending Keys on External Email ID as random Mail ID
		objMaintain.sendingKeysToEmailID();

		// Checking for Request Submit state

		objMaintain.requestState();

		// Validating User Data
		objMaintain.ValidateUserData();

		// Closing Browser
		objBaseTest.CloseBrowser();

	}

}
