package testScripts_Process_Y_Revoke_Delegation;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForRevokeDelegate;

public class Process_Y_Revoke_Delegation_Y_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForRevokeDelegate objRevoke = new RequestForRevokeDelegate();

	//Test case for Revoking Delegation Right present under the Employee(BBSS4).
	

	/*
	 * This Test Script will only pass if the Employee(BBSS4) has given delegate
	 * rights to any other Employee. Also you need to run this script after running 
	 * 
	 * "Process_X_Create_Delegation_X04_Test" script
	 * 
	 * 
	 */

	@Test
	public void Process_Y_Revoke_Delegation() throws InterruptedException, AWTException {

		// Login in with Employee (BBSS4)
		// entering userName from windows popup
		robotClassUserNameForEmployee("Employee");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Delegation / Aufgaben �bertragen Link
		objHomePage.clickingOnDelegationLink();

		// Clicking on Remove delegation of GUMS rights link
		objRevoke.clickingOnRevokeGumsRight();

		// Revoking Delegation Rights
		objRevoke.revokingDelegate();

		// Checking for the submission State
		objRevoke.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
