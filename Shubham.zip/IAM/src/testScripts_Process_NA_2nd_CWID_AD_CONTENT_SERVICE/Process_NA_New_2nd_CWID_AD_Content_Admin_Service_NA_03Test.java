/**
 * 
 */
package testScripts_Process_NA_2nd_CWID_AD_CONTENT_SERVICE;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForSecondaryCwidPage;

/**
 * Employee without AD
 * @author ELGNF
 *
 */

public class Process_NA_New_2nd_CWID_AD_Content_Admin_Service_NA_03Test extends BaseTest {
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();
	@Test
	public void Process_N_New_2nd_CWID_Employee_Scenario() throws InterruptedException, AWTException {

		// Login in with AD Content Admin
		// entering userName from windows popup
		robotClassUserNameForContractor("ADContentAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with ADContentAdmin");
		Reporter.log("Login with ADContentAdmin");
		
		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Creating Secondary CWID
		objRequestSecondaryCwidPage.creatingSecondaryCWIDLinkAdminService("WithOut_ADAccount", "Employee");

		String succesMessagExpected = "Your task has been completed successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabelAdmService(BaseTest.driver).getText()
				.trim();
		System.out.println("succesMessagActual" + succesMessagActual);
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label."+succesMessagActual);
		Reporter.log("Checking success message label."+succesMessagActual);

	}
}
