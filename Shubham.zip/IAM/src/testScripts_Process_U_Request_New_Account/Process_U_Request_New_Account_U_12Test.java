package testScripts_Process_U_Request_New_Account;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForNewAccountLDAPBySponsorPage;
import page.RequestForNewAccountLDAPPage;
import page.RequestForSecondaryCwidPage;

/**
 * Process_U_New_LDAP_ACCOUNT - Create request via contractor for new LDAP Account and Decline request from the sponsor.
 * Prerequisite-
 * 1.Request can not be processed if user already have account.
 * 
 * 
 * @author ELGNF
 *
 */

public class Process_U_Request_New_Account_U_12Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForNewAccountLDAPPage objRequestForNewAccountLDAPPage = new RequestForNewAccountLDAPPage();
	RequestForNewAccountLDAPBySponsorPage objRequestForNewAccountLDAPBySponsorPage = new RequestForNewAccountLDAPBySponsorPage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();

	@Test
	public void Process_U_New_Account_U_05_Employee_Scenario() throws InterruptedException, AWTException {
		String reasonForRequestEntered = "Testing Decline Process";
		// Login in with Contractor
		// Entering userName from windows popup
		robotClassUserNameForContractor("Contractor");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with contractor");
		Reporter.log("Login with contractor");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		objRequestForNewAccountLDAPPage.creatingNewLDAPAccount(reasonForRequestEntered);

		try {
			String succesMessagExpected = "Your request has been submitted successfully.";
			// Assert to check success message.
			String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabel(BaseTest.driver).getText()
					.trim();
			Assert.assertEquals(succesMessagActual, succesMessagExpected);
			objBaseTest.logResults("Checking success message label." + succesMessagActual);
		} catch (Exception e) {
			// Assert to check success message.
			String succesMessagApproverExpected = "Your task has been completed successfully.";
			String succesMessagApproverActual = objRequestForNewAccountLDAPBySponsorPage
					.successMessageForApproverLabel(BaseTest.driver).getText().trim();
			Assert.assertEquals(succesMessagApproverActual, succesMessagApproverExpected);
			objBaseTest.logResults("Checking success message label." + succesMessagApproverActual);
		}

		// Closing the session
		BaseTest.driver.close();

		// Login with the Sponsor to approve the request
		browserInitialization();

		// entering userName from windows popup
		robotClassUserNameForContractor("Sponsor");	

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Sponsor");
		
		

		objRequestForNewAccountLDAPBySponsorPage.viewingNewAccountRequest("Approver");

		// Rejecting request without entering comments
		String rejectionPopUpMessageLabelExpected = "Specify a value for all required fields";
		String rejectionPopUpMessageLabelActual = objRequestForNewAccountLDAPBySponsorPage
				.clickingRejectButtonWithOutEnteringComments();
		Assert.assertEquals(rejectionPopUpMessageLabelActual, rejectionPopUpMessageLabelExpected);

		// Rejecting request with entering comments
		objRequestForNewAccountLDAPBySponsorPage.clickingRejectButtonWithEnteringComments();

		// Assert to check success message.
		String succesMessagApproverExpected = "Your task has been completed successfully.";
		String succesMessagApproverActual = objRequestForNewAccountLDAPBySponsorPage
				.successMessageForApproverLabel(BaseTest.driver).getText().trim();
		// System.out.println("succesMessagActualApprover"+succesMessagApproverActual);
		Assert.assertEquals(succesMessagApproverActual, succesMessagApproverExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagApproverActual);

	}

}
