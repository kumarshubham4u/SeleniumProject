package testScripts_Process_ADR_Request_AD_Account_ADR;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForADAccountCwidPage;


/**
 *  Process_ADR_Request_AD_Account_ADR_03 - Adding Secondary CWIDs in "CWID without AD account - Employee login
 *  Pre-requisite:
 *  1.Employee login should be without AD account.
 *  2. Whenever searching CWID from search icon, popup should contains atleast 1 data.
 *  
 * @author EPVRY
 *
 */
@Test
public class Process_ADR_Request_AD_Account_ADR_03 extends BaseTest
{
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForADAccountCwidPage objRequestADAccountCwidPage= new RequestForADAccountCwidPage();

	public void Process_ADR_Request_AD_Account_ADR_03Scenario() throws InterruptedException, AWTException
	{
		String typeOFCWIDToSearch="GB";
		// Login in with Employee
		// entering userName from windows popup
		robotClassUserNameForEmployee("Employee");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		//Clicking on AccountRequest Zulassungsantrage Link
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		//Clicking on Request Ad Account Link
		objHomePage.clickingOnRequestAdAccount();

		//Selecting CWID from search icon
		objRequestADAccountCwidPage.selectingCWIDFromSearchIcon(typeOFCWIDToSearch);

		//Removing CWID from textbox
		objRequestADAccountCwidPage.removeCwidFromTextBox();

		//Once again selecting CWID from search icon
		objRequestADAccountCwidPage.selectingCWIDFromSearchIcon(typeOFCWIDToSearch);

		//Clicking on Next button 
		objRequestADAccountCwidPage.clickingOnNextButton();

		//Getting CWID and clicking on Finish button 
		objRequestADAccountCwidPage.clickingOnFinishButton();

		//Assert to check success message.
		String succesMessagUnixRequestExpected ="Your task has been completed successfully.";
		String succesMessagUnixRequestActual = objRequestADAccountCwidPage.successMessageLabel(BaseTest.driver).getText().trim();
		//System.out.println("succesMessagActualApprover"+succesMessagApproverActual);
		Assert.assertEquals(succesMessagUnixRequestActual, succesMessagUnixRequestExpected);
		objBaseTest.logResults("Checking success message label as: "+ succesMessagUnixRequestExpected);
		Reporter.log("Checking success message label.");




	}
}
