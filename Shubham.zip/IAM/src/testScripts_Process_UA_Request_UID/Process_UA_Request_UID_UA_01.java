package testScripts_Process_UA_Request_UID;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForUnixCwidPage;

/**
 *  Process_UA_Request_UID_UA_01 - Creating Unix-Id - Employee login
 *  Pre-requisite: Contractor login should not have Unix-Id already created.
 *  
 * @author EPVRY
 *
 */

@Test
public class Process_UA_Request_UID_UA_01 extends BaseTest
{
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForUnixCwidPage objRequestUnixCwidPage = new RequestForUnixCwidPage();

	public void Process_UA_Request_UID_UA_01Scenario() throws InterruptedException, AWTException
	{
		String reasonForUnixIDRequestEntered = "Need access for Unix ID";
		
		// Login in with Employee
		//entering userName from windows popup
		robotClassUserNameForEmployee("Employee");


		//entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		//Clicking on Account Request Zulassungsantrage
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		//Clicking on Request Unix-ID
		objHomePage.clickingOnRequestUnixIDLink();

		//Creating Request UnixID
		objRequestUnixCwidPage.creatingRequestUnixID(reasonForUnixIDRequestEntered);

		//Getting Unix Id Value and clicking on OK button  
		objRequestUnixCwidPage.gettingUnixID();

		//Assert to check success message.
		String succesMessagUnixRequestExpected ="Your task has been completed successfully.";
		String succesMessagUnixRequestActual = objRequestUnixCwidPage.successMessageLabel(BaseTest.driver).getText().trim();
		//System.out.println("succesMessagActualApprover"+succesMessagApproverActual);
		Assert.assertEquals(succesMessagUnixRequestActual, succesMessagUnixRequestExpected);
		objBaseTest.logResults("Checking success message label as: "+ succesMessagUnixRequestExpected);
		Reporter.log("Checking success message label.");




	}
}
