package testScripts_Process_RA_Restore_Archived_CWID;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForRestoreArchievedCwid;

public class Process_RA_Restore_Archived_CWID_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForRestoreArchievedCwid objRestore = new RequestForRestoreArchievedCwid();

	@Test
	public void Process_RA_Restore_Archived_CWID() throws InterruptedException, AWTException {

		// Login in with Admin
		// entering userName from windows popup
		robotClassUserNameForAdmin("ADMIN");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with admin");
		Reporter.log("Login with admin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Cwid Admins Link
		objHomePage.clickingOnCwidAdminsLink();

		// Clicking on Restore Archived Cwid Link
		objRestore.clickingOnRestoreArchieveCwidLink();

		// Clicking on search Button to select Employee
		objRestore.clickingOnSearchButton();

		// Selecting CWID to archive
		objRestore.clickingOnFirstRowSelect();

		// Clicking on Next button after validating the final Form
		objRestore.restoringArchivedCwid();

		// Clicking on Finish Button
		objRestore.clickingOnFinishbutton();

		// Checking for the submission State
		objRestore.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}
}
