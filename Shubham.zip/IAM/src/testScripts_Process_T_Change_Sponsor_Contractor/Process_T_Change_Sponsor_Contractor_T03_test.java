package testScripts_Process_T_Change_Sponsor_Contractor;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForChangeSponsorContractor;
import page.RequestForSecondaryCwidPage;

/**
 * Process_T_change sponsor of the contractor and approving the request Login
 * with Sponsor
 * 
 * 
 * @author ELGNF
 *
 */

public class Process_T_Change_Sponsor_Contractor_T03_test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForChangeSponsorContractor objRequestForChangeSponsorContractor = new RequestForChangeSponsorContractor();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();

	@Test
	public void Process_To_Change_Sponsor_Of_Contractor() throws InterruptedException, AWTException {
		// Login in with Sponsor
		// Entering userName from windows popup
		robotClassUserNameForEmployee("Sponsor");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Sponsor");
		Reporter.log("Login with Sponsor");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Creating request for changing sponsor
		objRequestForChangeSponsorContractor.changeSponsorForContractor();

		String succesMessagExpected = "Your task has been completed successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabelAdmService(BaseTest.driver).getText()
				.trim();
		System.out.println(succesMessagActual);
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

		// Closing the session
		BaseTest.driver.close();

		// Login with the Sponsor to approve the request
		browserInitialization();

		// Login in with Contractor
		// Entering userName from windows popup
		robotClassUserNameForContractor("Sponsor");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with requested Sponsor");
		Reporter.log("Login with requested Sponsor");

		objRequestForChangeSponsorContractor.viewingRequestForChangeSponsorContractor();
		objRequestForChangeSponsorContractor.ApproveRequest();

		// Assert to check success message.
		String succesMessageExpected = "Your task has been completed successfully.";
		String succesMessageActual = objRequestSecondaryCwidPage.successMessageLabelAdmService(BaseTest.driver)
				.getText().trim();
		Assert.assertEquals(succesMessageActual, succesMessageExpected);
		objBaseTest.logResults("Checking success message label." + succesMessageActual);

	}

}
