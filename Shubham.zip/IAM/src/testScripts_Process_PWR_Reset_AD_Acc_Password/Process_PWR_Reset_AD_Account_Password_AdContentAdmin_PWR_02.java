package testScripts_Process_PWR_Reset_AD_Acc_Password;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPassswordResetPage;
import page.RequestForSecondaryCwidPage;

/**
 * Function For Reset password via login with Ad Content Admin without sending mail
 * to sponsor/supervisor for choice of your cwid for which first you have to
 * wait for the ad content admin login via automation and then move to eclipse
 * again in console after you see the output "Enter the user input (CWID) in
 * the search option" enter the cwid in the next line and click enter (In 25
 * Seconds) then navigate to webdriver page for viewing the process.
 * 
 * @author ELGNF
 */

public class Process_PWR_Reset_AD_Account_Password_AdContentAdmin_PWR_02 extends BaseTest {
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPassswordResetPage objRequestForPassswordResetPage = new RequestForPassswordResetPage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();

	@Test
	public void Process_PWR_Reset_pwd_Employee_with_mail_Scenario() throws InterruptedException, AWTException {
		// Login with Ad Content Admin
		// entering userName from windows popup
		robotClassUserNameForContractor("ADContentAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Ad Content Admin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();
		
		// Reset Password via login with Employee
		objRequestForPassswordResetPage.runningResetPasswordProcess("without_Email","firstTab");

		String succesMessagExpected = "Your task has been completed successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabelAdmService(BaseTest.driver).getText()
				.trim();
		System.out.println(succesMessagActual);
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	

	}
}
