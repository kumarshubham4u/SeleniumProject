package testScripts_Process_PWR_Reset_AD_Acc_Password;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPassswordResetPage;
import page.RequestForSecondaryCwidPage;

/**
 * Function For Reset password via login with Contractor without sending mail to sponsor
 * @author ELGNF
 */

public class Process_PWR_Reset_AD_Account_Password_Contractor_PWR_02 extends BaseTest {
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPassswordResetPage objRequestForPassswordResetPage = new RequestForPassswordResetPage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();

	@Test
	public void Process_PWR_Reset_pwd_Contractor_without_mail_Scenario() throws InterruptedException, AWTException {
		// Login with contractor
		// entering userName from windows popup
		robotClassUserNameForContractor("Contractorforresetpassword");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Contractor");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Reset Password via login with contractor
		objRequestForPassswordResetPage.runningResetPasswordProcess("without_Email","secondTab");

		String succesMessagExpected = "Your task has been completed successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabelAdmService(BaseTest.driver).getText()
				.trim();
		System.out.println(succesMessagActual);
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label." + succesMessagActual);
		Reporter.log("Checking success message label." + succesMessagActual);

	}
}
