package testScripts_Process_PID_Deactivate_Partner_ID_Self_and_Admin_Service_PID;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPartnerIDDeactivate;

public class Process_PID_Deactivate_Partner_ID_Self_and_Admin_Service_PID_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPartnerIDDeactivate objDeactivate = new RequestForPartnerIDDeactivate();

	
	/*
	 * Test Case for Deactivating Partner ID by Employee
	 */
	@Test
	public void Process_PID_Deactivate_Partner_ID_Self_and_Admin_Service_PID()
			throws InterruptedException, AWTException {

		// Login in with supervisor
		// entering userName from windows popup
		robotClassUserNameForContractor("supervisor");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Partner-ID Request / Partner-ID Antr�ge Link
		objHomePage.clickingOnPartnerIdLink();

		// Clicking on Deactivate Partner ID Link
		objDeactivate.clickingOnDeactivatePartnerIDLink();

		// Checking for Validation Error
		objDeactivate.checkValidation();

		// Selecting Partner ID to deactivate
		objDeactivate.selectPartnerID();

		// Deactivating Partner ID
		objDeactivate.deactivatingPartnerID();

		// Checking for the submission State
		objDeactivate.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();
	}

}
