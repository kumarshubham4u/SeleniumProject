package testScripts_Process_Delegate_Approval_Permission_Employee_Admin_XA;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForDelegateApproval;

public class Process_XA_Delegate_Approval_Employee_Admin_XA_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForDelegateApproval objDelegate = new RequestForDelegateApproval();
	
	/*
	 * Test case for Creating Delegation Request by Identity Admin and Declining
	 * it from the delegate Contractor(BBSE56).
	 */

	/*
	 * You need to run "Process_Y_Revoke_Delegation_Y_02_Test" script before running
	 * this script to check if the Delegate rights were already present for BBSE56, else script will fail
	 */

	@Test
	public void Process_Delegate_Approval_Employee_Admin_XA_02_Decline() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Identity Admin");
		Reporter.log("Login with Identity Admin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Delegation / Aufgaben �bertragen Link
		objHomePage.clickingOnDelegationLink();

		// Clicking on Delegate Gums Right to an Employee Link
		objDelegate.clickingOnDelegateGumsRight();
		
		// Clicking on Next button without entering fields
		objDelegate.clickingNextButtonWithoutEnteringFields();

		// Sending Keys for search search CWID lookup
		objDelegate.sendingKeysOnLookupCWID();

		// Sending Keys on Delegate from date
		objDelegate.sendingKeysOnDelegateFromDate();

		// Sending Keys on Delegate To date
		objDelegate.sendingKeysOnDelegateToDate();

		// Clicking on Finish button
		objDelegate.clickingFinishButton();

		// Checking for the submission State
		objDelegate.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		// Re-launch browser for new session
		objBaseTest.browserInitialization();

		// Login in with Employee (BBSE56)
		// entering userName from windows popup
		robotClassUserNameForEmployee("employeeGSO");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Delegate Employee");
		Reporter.log("Login with Delegate Employee");

		// Clicking on View All Request link
		objDelegate.clickingOnViewAllRequest();

		// Clicking on Create Delegation, Accept Request Link
		objDelegate.clickingOnCreateDelegationLink();

		// Clicking on Accept No radio button
		objDelegate.decliningRequest();
		
		// Checking for the submission State
		objDelegate.submissionState();
		
		// Closing the browser
		objBaseTest.CloseBrowser();
		 

	}

}
