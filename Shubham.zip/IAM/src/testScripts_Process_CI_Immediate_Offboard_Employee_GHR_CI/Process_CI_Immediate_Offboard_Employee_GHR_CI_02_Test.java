package testScripts_Process_CI_Immediate_Offboard_Employee_GHR_CI;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForImmediateOffboardEmployeeGHR;

public class Process_CI_Immediate_Offboard_Employee_GHR_CI_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForImmediateOffboardEmployeeGHR objOffboard = new RequestForImmediateOffboardEmployeeGHR();

	/*
	 * Test script for Immediate Off-boarding "IM" type Employee
	 * 
	 * 
	 * Before running the script, make sure that "IM" type employee data who doesn't
	 * contain any "Machine/Secondary/Generic SignOn CWIDs" is already present. Else
	 * you have to add "IM" type employee with such credentials
	 */

	@Test
	public void Process_CI_Immediate_Offboard_Employee_GHR() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows pop-up
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows pop-up
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Account Request/Zulassungsantrage
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		// Clicking on Immediate Off-board employee GHR Link
		objOffboard.clickingOnImmediateOffboardLink();

		// Clicking on search Button
		objOffboard.clickingOnSearchButton();

		// Sending Keys on identityID as "IM" type employee
		objOffboard.sendingKeysOnIdentityID2();

		// Clicking on first row CWID
		objOffboard.clickingOnFirstRowSelect();

		// Clicking on OK button
		objOffboard.clickingOnOkButton();

		// Clicking on Finish Button
		objOffboard.clickingOnFinishbutton();

		// Checking for the submission State
		objOffboard.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
