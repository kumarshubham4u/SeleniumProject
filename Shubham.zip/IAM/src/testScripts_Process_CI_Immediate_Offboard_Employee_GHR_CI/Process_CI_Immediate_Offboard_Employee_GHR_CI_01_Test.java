package testScripts_Process_CI_Immediate_Offboard_Employee_GHR_CI;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForImmediateOffboardEmployeeGHR;

public class Process_CI_Immediate_Offboard_Employee_GHR_CI_01_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForImmediateOffboardEmployeeGHR objOffboard = new RequestForImmediateOffboardEmployeeGHR();

	/*
	 * Test script for Immediate Off-boarding "BCSE" type Employee and adding new
	 * Sponsor as "BCSE10".
	 * 
	 * Before running the script, make sure that BCSE type employee data is already
	 * present. Else you have to add BCSE type employee
	 * 
	 */

	/*
	 * After running the script, one should manually verify that the roles are
	 * correctly assigned to new Sponsor
	 * 
	 */

	@Test
	public void Process_CI_Immediate_Offboard_Employee_GHR() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows pop-up
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows pop-up
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Account Request/Zulassungsantrage
		objHomePage.clickingOnAccountRequest_ZulassungsantrageLink();

		// Clicking on Immediate Off-board employee GHR Link
		objOffboard.clickingOnImmediateOffboardLink();

		// Clicking on search Button
		objOffboard.clickingOnSearchButton();

		// Sending Keys on identityID as "BCSE" type employee
		objOffboard.sendingKeysOnIdentityID1();

		// Clicking on first row CWID
		objOffboard.clickingOnFirstRowSelect();

		// Clicking on OK button
		objOffboard.clickingOnOkButton();

		// Sending Keys on New Sponsor as BCSE10
		objOffboard.selectingNewSponsor();

		// Clicking on Finish Button
		objOffboard.clickingOnFinishbutton();

		// Checking for the submission State
		objOffboard.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

	}

}
