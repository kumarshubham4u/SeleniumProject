/**
 * 
 */
package testScripts_Process_P_Deactivate_2nd_CWID;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForDeactivateSecondaryCwidPage;
import page.RequestForSecondaryCwidPage;

/**
 * @author ELGNF
 *
 */

public class Process_P_Deactivate_2nd_CWID_P_01_Test extends BaseTest {
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForDeactivateSecondaryCwidPage objRequestDeactivateSecondaryCwidPage = new RequestForDeactivateSecondaryCwidPage();
	RequestForSecondaryCwidPage objRequestSecondaryCwidPage = new RequestForSecondaryCwidPage();
	@Test
	public void Process_P_Deactivate_2nd_CWID_Employee_Scenario() throws InterruptedException, AWTException {

		// Login in with Employee
		// entering userName from windows popup
		robotClassUserNameForEmployee("EmployeeForDeactivate");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");
		
		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Deactivating Secondary CWID
		objRequestDeactivateSecondaryCwidPage.deactivateSecondaryCWIDLinkSelfService();
		String succesMessagExpected = "Your request has been submitted successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestSecondaryCwidPage.successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label."+succesMessagActual);
		Reporter.log("Checking success message label."+succesMessagActual);

		// Verifying that cwid is deactivated.
		objRequestDeactivateSecondaryCwidPage.verifyDeactivatedSecondaryCWID();

		// Assert to check cwid status.
		String statusExpected = "Inactive";

		Assert.assertEquals(objRequestDeactivateSecondaryCwidPage.statusOfCWID, statusExpected);
		objBaseTest.logResults("Checking the secondary user is deactivated."+statusExpected);
		Reporter.log("Checking the secondary user is deactivated."+statusExpected);

	}

}
