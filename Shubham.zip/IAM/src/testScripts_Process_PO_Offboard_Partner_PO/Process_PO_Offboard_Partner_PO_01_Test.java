package testScripts_Process_PO_Offboard_Partner_PO;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForOffboardPartner;

public class Process_PO_Offboard_Partner_PO_01_Test extends BaseTest {
	
	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForOffboardPartner objOffboard = new RequestForOffboardPartner();
	
	
	/*
	 * Before running this text Script make sure that Employee BBSE22 has an active
	 * assigned task for Offboard PartnerID. Else you need to create a task to Offboard Partner ID
	 * 
	 */
	
	@Test
	public void Process_PO_Offboard_Partner() throws InterruptedException, AWTException {
		
		// Login in with Employee (BBSE22)
		// entering userName from windows popup
		robotClassUserNameForEmployee("employeeOffboard");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee with active assigned process for Offboard Partner");
		Reporter.log("Login with Employee with active assigned process for Offboard Partner");

		// Clicking on View All Request link
		objOffboard.clickingOnViewAllRequest();
		
		//Clicking on Off-board Partner ID Link
		objOffboard.clickingOnOffboardPartnerID();
		
		//Extend Valid To date
		objOffboard.extendValidToDate();
		
		//Clicking on Finish Button
		objOffboard.clickingOnFinishbutton();
		
		// Checking for the submission State
		objOffboard.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();

		
		
		
	}


}
