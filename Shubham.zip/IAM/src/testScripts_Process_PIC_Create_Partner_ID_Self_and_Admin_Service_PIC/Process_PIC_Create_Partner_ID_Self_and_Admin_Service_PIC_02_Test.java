package testScripts_Process_PIC_Create_Partner_ID_Self_and_Admin_Service_PIC;

import java.awt.AWTException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForPartnerID;

public class Process_PIC_Create_Partner_ID_Self_and_Admin_Service_PIC_02_Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForPartnerID objPartnerID = new RequestForPartnerID();
	
	
	/*
	 * Test Case for Creating Partner ID by Identity Admin for Sharepoint online
	 */
	
	@Test
	public void Process_PIC_Create_Partner_ID_Self_and_Admin_Service_PIC() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Partner-ID Request / Partner-ID Antr�ge Link
		objHomePage.clickingOnPartnerIdLink();

		// Clicking on Create Partner ID Link
		objPartnerID.clickingOnCreatePartnerIDLink();

		// Clicking on Sharepoint online Radio button
		objPartnerID.clickingOnSharepointOnline();
		
		//Sending Keys on Email Check
		objPartnerID.sendingKeysOnEmailCheck();
		
		// Sending Keys for search Sponser CWID
		objPartnerID.sendingKeysOnSponsorCWID();

		// Checking for Validation Error
		objPartnerID.checkValidation();

		// Creating Partner ID
		objPartnerID.createPartnerID();

		// Fetching generated Partner ID details and Clicking on Finish button
		objPartnerID.clickingFinishButton();

		// Checking for the submission State
		objPartnerID.submissionState();

		// Closing the browser
		objBaseTest.CloseBrowser();
	}

}
