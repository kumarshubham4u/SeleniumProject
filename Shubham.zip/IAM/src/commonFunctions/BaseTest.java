package commonFunctions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import page.LoginPage;

public class BaseTest 
{

	public static WebDriver driver;
	String browser = "FireFox";
	LoginPage objLoginPage = new LoginPage();
	static ExtentTest test;
	static ExtentReports report;

	/*
	 * Function to initialize browser
	 */

	@BeforeTest
	public void beforeTestExtentReport()
	{
		//Starting Extent report
		report = new ExtentReports(
				System.getProperty("user.dir") + "/test-output/Reports/" + getClass().getSimpleName() + ".html");

	}

	@BeforeClass
	public void browserInitialization() throws AWTException, InterruptedException 
	{
		// TODO Auto-generated method stub

		if (browser.equalsIgnoreCase("IE")) {
			// System.setProperty("webdriver.ie.driver","C:\\Users\\EPVRY\\Downloads\\Selenium
			// Project Jars\\IEDriverServer_x64_3.14.0\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", "src\\drivers\\IEDriverServer3_2.exe");

			DesiredCapabilities capabilities = new DesiredCapabilities();

			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS,true);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
			//From here I have used from internet
			/*
			 * capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
			 * true); capabilities.setCapability(InternetExplorerDriver.
			 * ENABLE_ELEMENT_CACHE_CLEANUP, true);
			 * capabilities.setCapability("allow-blocked-content", true);
			 * capabilities.setCapability("allowBlockedContent", true);
			 * //capabilities.setCapability(CapabilityType.VERSION, "8");
			 * //capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS,
			 * false); capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS,
			 * false);
			 */
			driver = new InternetExplorerDriver(capabilities);

			driver.get("https://qa1-by-gums-qa.intranet.cnb/");
			driver.manage().window().maximize();

			Thread.sleep(1000);



			/*
			 * driver.findElement(By.id("infoBlockIDImage")).click(); Thread.sleep(1000);
			 * driver.findElement(By.id("overridelink")).click();
			 */


		}
		if (browser.equalsIgnoreCase("FireFox")) {
			// System.setProperty("webdriver.gecko.driver",
			// "C:\\Users\\EPVRY\\Downloads\\Selenium Project
			// Jars\\geckodriver-v0.26.0-win64\\geckodriver.exe");
			System.setProperty("webdriver.gecko.driver", "src\\drivers\\geckodriver.exe");

			driver = new FirefoxDriver();
			driver.get("https://qa1-by-gums-qa.intranet.cnb/");
			//https://qa1-by-gums-qa.intranet.cnb/ 
			//https://by0t2j.qa1.ms-test-env.cnb/
		}




	}

	@BeforeMethod()
	public void beforeTestMethod(final Method m, final ITestContext context) throws Exception
	{
		test = report.startTest(m.getName());
	}


	@AfterMethod()
	public void tearDownMethod(final ITestResult testResult) throws Exception
	{
		// ExtentTest test = report.getTest();
		if (testResult.getStatus() == ITestResult.FAILURE)
		{
			String path = takeScreenshot(driver, testResult.getName());
			String imagePath = test.addScreenCapture(path);
			test.log(LogStatus.FAIL, "Teststep Failed", imagePath);
		} else if (testResult.getStatus() == ITestResult.SKIP)
		{
			test.log(LogStatus.SKIP, "Test Case Skipped is " + testResult.getName());
		}
		report.endTest(test);
	}

	/*
	 * Function to take screenshot
	 */
	public static String takeScreenshot(WebDriver driver, String fileName) throws IOException {
		fileName = fileName + ".png";
		String directory = System.getProperty("user.dir")+ "/test-output/Screenshots/";
		File  sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sourceFile, new File(directory + fileName));
		String destination = directory + fileName;
		return destination;
	}

	/*
	 * Function to generate logs in extent report 
	 */
	public void logResults(final String Action)
	{

		test.log(LogStatus.INFO, Action);
	}

	/*
	 * Function to handle windows popup,entering userName for contractor
	 */

	public void robotClassUserNameForContractor(String designation) throws AWTException, InterruptedException 
	{ 
		//Handling windows popup
		Robot robot = new Robot(); // Robot class throws AWT Exception
		Thread.sleep(2000); // Thread.sleep throws InterruptedException //qa1\bbsc5
		//robot.keyPress(KeyEvent.VK_CAPS_LOCK);
		//robot.keyRelease(KeyEvent.VK_CAPS_LOCK);
		if(designation.equals("Contractor"))
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_C);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_5);Thread.sleep(500); 
		}
		
		if(designation.equals("ContractorDelegate"))//qa1\bbsc36
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_C);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_9);Thread.sleep(500); 
		}
		
		if(designation.equals("Sponsor"))//qa1\bbse1
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_1);Thread.sleep(500);  
		}

		if (designation.equals("ADContentAdmin"))// qa1\coadm10
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_C);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_O);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_D);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_M);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);
			Thread.sleep(500);
		}

		if (designation.equals("ServiceDeskAdmin"))// qa1\SDADM10
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_D);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_D);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_M);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);
			Thread.sleep(500);
		}

		//used for password reset
		if (designation.equals("Contractorforresetpassword")) //qa1\BBSC30
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_C);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_3);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);
			Thread.sleep(500);
		}
		
		if (designation.equals("ContractorForMaintaingData")) //qa1\BBSC30
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_C);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_3);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_9);
			Thread.sleep(500);
		}
		
		if (designation.equals("EmployeeforResetPassword")) //qa1\BBSC1
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);

		}
		
		if (designation.equals("EmployeeforDelegate")) //qa1\BBSS3
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_3);
			Thread.sleep(500);

		}


		if (designation.equals("IdentityAdmin"))// qa1\IDADM10
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_I);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_D);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_D);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_M);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);
			Thread.sleep(500);
		}
		
		if (designation.equals("supervisor")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_2);
			Thread.sleep(500);

		}


	}


	/*
	 * Function to handle windows popup,entering Password
	 */

	public void robotClassEnteringPassword() throws AWTException, InterruptedException 
	{ 
		//Handling windows popup
		Robot robot = new Robot(); // Robot class throws AWT Exception
		//Thread.sleep(2000); // Thread.sleep throws InterruptedException 
		//Entering Password : Start123
		robot.keyPress(KeyEvent.VK_TAB);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_CAPS_LOCK);
		robot.keyRelease(KeyEvent.VK_CAPS_LOCK);
		robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_CAPS_LOCK);
		robot.keyRelease(KeyEvent.VK_CAPS_LOCK);
		robot.keyPress(KeyEvent.VK_T);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_A);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_R);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_T);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_1);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_2);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_3);Thread.sleep(500);robot.keyPress(KeyEvent.VK_TAB);Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_ENTER);Thread.sleep(500);

	}


	/*
	 * Function to handle windows popup,entering userName for contractor
	 */

	public void robotClassUserNameForEmployee(String designation) throws AWTException, InterruptedException 
	{ 
		//Handling windows popup
		Robot robot = new Robot(); // Robot class throws AWT Exception
		Thread.sleep(2000); // Thread.sleep throws InterruptedException //qa1\bbss4
		//robot.keyPress(KeyEvent.VK_CAPS_LOCK);
		//robot.keyRelease(KeyEvent.VK_CAPS_LOCK);
		if(designation.equals("Employee"))
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_4);Thread.sleep(500); 
		}
		
		
		if(designation.equals("EmployeeDelegate"))//qa1\bbse16
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_1);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_6);Thread.sleep(500); 
		}
		
		
		if(designation.equals("Sponsor"))//qa1\bbss2
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_2);Thread.sleep(500);  
		}
		if (designation.equals("EmployeeForDeactivate")) 
		{
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_5);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_6);
			Thread.sleep(500);
		}
		//Employee login for signature handling
		if(designation.equals("SignaturExceptionHandling")) //qa1\bmss2
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_M); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_2);Thread.sleep(500);
		}

		if (designation.equals("newSponsorForMachineCWID")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_5);
			Thread.sleep(500);

		}
		
		
		

		if (designation.equals("employeeGSO")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_5);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_6);
			Thread.sleep(500);

		}
		
		if (designation.equals("employeeDelegate")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_5);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_7);
			Thread.sleep(500);

		}
		
		if (designation.equals("supervisorGSO")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_5);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);
			Thread.sleep(500);

		}
		
		if (designation.equals("employeeRevoke")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_2);
			Thread.sleep(500);

		}
		
		
		if (designation.equals("employeeOffboard")) {
			robot.keyPress(KeyEvent.VK_Q);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_B);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_E);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_2);
			Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_2);
			Thread.sleep(500);

		}
		
		
		
		
	


	}




	/*
	 * Function to wait for the locators
	 */
	public void fluentWait() throws InterruptedException
	{
		Thread.sleep(2000);
		Wait wait = new FluentWait<WebDriver>(driver)
				.withTimeout(50, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);
		
	}
	
	/*
	 * Function to explicit wait for the locators
	 */
	public void explicitWait(By path ) throws InterruptedException
	{
		Thread.sleep(3000);
		WebDriverWait w = new WebDriverWait(driver, 50);
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(path));
		
	}

	/*
	 * Function to scroll a locator at center of page
	 */
	public void scrollInView(final WebElement element)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].scrollIntoView();", element);

	}

	/*
	 * Function to enter data in textbox using Javascript
	 */
	public void enterDataUsingJavascript(final WebElement element, final String value)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value=arguments[1]", element, "");
		js.executeScript("arguments[0].value=arguments[1]", element, value);
	}


	/*
	 *  Function to Click Using java Script
	 */

	public void clickUsingJavascript(final WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", element);
	}      

	/*
	 * Function to handle windows popup,entering userName for contractor
	 */

	public void robotClassUserNameForAdmin(String designation) throws AWTException, InterruptedException 
	{ 
		//Handling windows popup
		Robot robot = new Robot(); // Robot class throws AWT Exception
		Thread.sleep(2000); // Thread.sleep throws InterruptedException //qa1\wasa00
		//robot.keyPress(KeyEvent.VK_CAPS_LOCK);
		//robot.keyRelease(KeyEvent.VK_CAPS_LOCK);
		if(designation.equals("ADMIN"))
		{
			robot.keyPress(KeyEvent.VK_Q); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_1); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_BACK_SLASH);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_W);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A); Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_S);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_A);Thread.sleep(500); 
			robot.keyPress(KeyEvent.VK_0);Thread.sleep(500);
			robot.keyPress(KeyEvent.VK_0);Thread.sleep(500);
		}
	}

	/*
	 * Function to close the browser
	 */
	@AfterClass
	public void CloseDriver() {


//		driver.close();
	}

	public void CloseBrowser() {
		logResults("Closing browser");
		driver.close();
	}


	@AfterTest
	public void afterTestExtenReport()
	{
		// writing everything to document flush() - to write or update test information to your report.
		report.flush();
		//close() - To close all the operation
		report.close();
	}

}
