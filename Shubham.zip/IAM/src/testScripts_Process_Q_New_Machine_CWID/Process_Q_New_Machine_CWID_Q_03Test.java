package testScripts_Process_Q_New_Machine_CWID;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForNewMachineCWIDBySponsorPage;
import page.RequestForMachineCwidPage;

/**
 * Process_N_New_MACHINE_CWID_Q_03 - Approving request without AD account -
 * Employee
 * 
 * 
 * @author ELGNF
 *
 */

public class Process_Q_New_Machine_CWID_Q_03Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForMachineCwidPage objRequestMachineCwidPage = new RequestForMachineCwidPage();
	RequestForNewMachineCWIDBySponsorPage objRequestForNewMachineCWIDBySponsorPage = new RequestForNewMachineCWIDBySponsorPage();
	@Test
	public void Process_Q_New_Machine_CWID_Q_03Scenario() throws InterruptedException, AWTException {
		String reasonForRequestEntered = "Required for Approve scenario";
		// Login in with Employee
		// Entering userName from windows popup
		robotClassUserNameForEmployee("Employee");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Employee");
		Reporter.log("Login with Employee");

		//Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Creating Secondary CWID
		objRequestMachineCwidPage.creatingMachineCWIDLink(reasonForRequestEntered, "Without_ADAccount");
		String succesMessagExpected = "Your request has been submitted successfully.";

		// Assert to check success message.
		String succesMessagActual = objRequestMachineCwidPage.successMessageLabel(BaseTest.driver).getText().trim();
		Assert.assertEquals(succesMessagActual, succesMessagExpected);
		objBaseTest.logResults("Checking success message label.");
		Reporter.log("Checking success message label.");

		// Closing the session
		BaseTest.driver.close();

		// Login with the Sponsor to approve the request
		browserInitialization();

		// entering userName from windows popup
		robotClassUserNameForEmployee("Sponsor");

		// Entering password from windows popup 
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with Supervisor");
		Reporter.log("Login with Supervisor");

		// Clicking and viewing the request
		String reasonForRequestViewApproverPage = objRequestForNewMachineCWIDBySponsorPage
				.viewingMachineCWIDRequest();
		System.out.println("reasonForRequestViewApproverPage" + reasonForRequestViewApproverPage);
		Assert.assertEquals(reasonForRequestEntered, reasonForRequestViewApproverPage);

		//Rejecting request without entering comments
		String rejectionPopUpMessageLabelExpected ="Specify a value for all required fields";
		String rejectionPopUpMessageLabelActual = objRequestForNewMachineCWIDBySponsorPage.clickingRejectButtonWithOutEnteringComments("WithOut_ADAccount");
		Assert.assertEquals(rejectionPopUpMessageLabelActual, rejectionPopUpMessageLabelExpected);

		//Rejecting  request with entering comments
		objRequestForNewMachineCWIDBySponsorPage.clickingRejectButtonWithEnteringComments();

		//Assert to check success message.
		String succesMessagApproverExpected ="Your task has been completed successfully.";
		String succesMessagApproverActual = objRequestForNewMachineCWIDBySponsorPage.successMessageForApproverLabel(BaseTest.driver).getText().trim();		
		Assert.assertEquals(succesMessagApproverActual, succesMessagApproverExpected);
		objBaseTest.logResults("Checking success message label."+succesMessagApproverActual);

	}

}


