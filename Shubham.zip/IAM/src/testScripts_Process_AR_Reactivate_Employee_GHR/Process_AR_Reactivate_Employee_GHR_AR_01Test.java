package testScripts_Process_AR_Reactivate_Employee_GHR;

import java.awt.AWTException;


import org.testng.Reporter;
import org.testng.annotations.Test;

import commonFunctions.BaseTest;
import page.HomePage;
import page.RequestForReactivateEmployee;


public class Process_AR_Reactivate_Employee_GHR_AR_01Test extends BaseTest {

	BaseTest objBaseTest = new BaseTest();
	HomePage objHomePage = new HomePage();
	RequestForReactivateEmployee objReactivateEmp = new RequestForReactivateEmployee();
	
	@Test
	public void Process_AR_Reactivate_Employee() throws InterruptedException, AWTException {

		// Login in with IdentityAdmin
		// entering userName from windows popup
		robotClassUserNameForContractor("IdentityAdmin");

		// entering password from windows popup
		robotClassEnteringPassword();
		objBaseTest.logResults("Login with IdentityAdmin");
		Reporter.log("Login with IdentityAdmin");

		// Clicking on Service Link
		objHomePage.clickingOnServiceLink();

		// Clicking on Reactivate CWID

		objHomePage.clickingOnReactivateCWID();

		// Clicking on Add Button

		objReactivateEmp.clickingOnAddButton();

		// Selecting CWID of first row

		objReactivateEmp.clickingOnFirstRowCWID();

		// Clicking on Ok button

		objReactivateEmp.clickingOnOkButton();

		// Clicking on Next Button
		
		objReactivateEmp.clickingOnNextButton();
		
		// Clicking on Finish Button
		
		objReactivateEmp.clickingOnFinishButton();
		
		//Checking for the submission State
		objReactivateEmp.submissionState();
		
		//Closing the browser
		objBaseTest.CloseBrowser();
		

	}

}
