import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Users\\Default User\\Documents\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/");
		
		WebElement source = driver.findElement(By.id("FromTag"));
		WebElement destination = driver.findElement(By.id("ToTag"));
		source.click();
		source.sendKeys("Delhi");
		Thread.sleep(4000);
		source.sendKeys(Keys.ARROW_DOWN);
		source.sendKeys(Keys.ENTER);
		destination.click();

		destination.sendKeys("Mumbai");
		Thread.sleep(4000);
		destination.sendKeys(Keys.ARROW_DOWN);
		destination.sendKeys(Keys.ENTER);

		driver.findElement(By.id("DepartDate")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector(".ui-state-default.ui-state-highlight.ui-state-active ")).click();

		Select s = new Select(driver.findElement(By.id("Adults")));
		Select t = new Select(driver.findElement(By.id("Childrens")));

		s.selectByValue("3");
		t.selectByValue("1");

		driver.findElement(By.id("MoreOptionsLink")).click();
		WebElement airline = driver.findElement(By.id("AirlineAutocomplete"));

		airline.sendKeys("INDIGO");
		Thread.sleep(3000);
		airline.sendKeys(Keys.ENTER);

		driver.findElement(By.id("SearchBtn")).click();

	}

}
