import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xpathCssGeneration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\Default User\\Documents\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://login.salesforce.com/?locale=in");
		/*driver.findElement(By.xpath("//input[@id='username']")).sendKeys("kumarshubham4u");//own generated xpath used
		driver.findElement(By.xpath("//*[@type='password']")).sendKeys("Shubham@4u");*/
		
		driver.findElement(By.cssSelector("*[id='username']")).sendKeys("kumarshubham4u");//own generated css selector used
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Shubham@4u");
		
		
		
	}

}
