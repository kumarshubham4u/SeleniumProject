import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Salesforce_Xpath_CSS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\Default User\\Documents\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://login.salesforce.com/?locale=in");
		/*driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("kumarshubham4u");
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Shubham@4u");
		driver.findElement(By.xpath("//*[@id=\"Login\"]")).click(); //Using xpath locator*/
		
		driver.findElement(By.cssSelector("#username")).sendKeys("kumarshubham4u");
		driver.findElement(By.cssSelector("#password")).sendKeys("Shubham@4u");
		driver.findElement(By.cssSelector("#Login")).click();//using cssSelector locator
		System.out.println(driver.findElement(By.cssSelector("div#error.loginError")).getText());//Print the login error message in the console
		

	}

}
