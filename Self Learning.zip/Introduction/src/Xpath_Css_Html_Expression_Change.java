import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath_Css_Html_Expression_Change {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "D:\\\\Users\\\\Default User\\\\Documents\\\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://www.rediff.com/");
		driver.findElement(By.cssSelector("a[title*='Sign in']")).click();//css selector generated for html expression which cud change
		driver.findElement(By.xpath("//input[contains(@id,'login1')]")).sendKeys("kshubham");//xpath generated for html expression which cud change
		driver.findElement(By.xpath("//input[contains(@id,'password')]")).sendKeys("Shubham@4u");
		driver.findElement(By.cssSelector("input[value*='Sign in']")).click();
		
		

	}

}
