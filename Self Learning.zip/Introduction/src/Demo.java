import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver","D:\\Users\\Default User\\Documents\\chromedriver.exe");
		WebDriver Driver =new ChromeDriver(); //above two steps invokes Chrome Driver. Driver is the name of the object
		
		Driver.get("http://www.google.com");
		System.out.println(Driver.getTitle()); //prints the title of the page in console
		
		System.out.println(Driver.getCurrentUrl());// the validate if u landed on correct url
		
		//System.out.println(Driver.getPageSource()); //displays the page source
		
		Driver.get("http://yahoo.com");
		Driver.navigate().back();// navigates back to the previous page
		Driver.navigate().forward();//navigates forward to the page
		Driver.close(); //closes the browser once execution is completed
		//Driver.quit();// closes all the browser opened by selenium script at one instance
	
	}

}
