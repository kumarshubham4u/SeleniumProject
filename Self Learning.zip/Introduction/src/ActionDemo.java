import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionDemo {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"D:\\\\\\\\Users\\\\\\\\Default User\\\\\\\\Documents\\\\\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.com/");
		Actions a = new Actions(driver);// declaring actions class and driver is passed as an argument hence driver
										// object can interact with all the methods of Actions class
		WebElement move = driver.findElement(By.id("nav-link-accountList"));

		a.moveToElement(move).contextClick().build().perform();
		a.moveToElement(driver.findElement(By.id("twotabsearchtextbox"))).click().keyDown(Keys.SHIFT).sendKeys("adidas").doubleClick()
				.build().perform();//keyDown is used to press the key down like shift to enter words in CAPs
		

	}

}