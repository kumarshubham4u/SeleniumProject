import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Greenkart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\\\Users\\\\Default User\\\\Documents\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);//implicit wait
		// global declaration waits for 5 seconds
		WebDriverWait w = new WebDriverWait(driver, 5);// Explicit wait object creation for 5 seconds

		String[] itemsNeeded = { "Cucumber", "Brinjal", "Beetroot", "Mushroom", "Papaya", "Cocunut", "Carrot" };
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");

		addItems(driver, itemsNeeded);// created a method addItems

		driver.findElement(By.xpath("//img[@alt='Cart']")).click();
		driver.findElement(By.xpath("//div[@class='action-block']/button")).click();

		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".promoCode")));// explicit wait
																									// declared for a
																									// particular
																									// element

		driver.findElement(By.cssSelector(".promoCode")).sendKeys("rahulshettyacademy");
		driver.findElement(By.cssSelector(".promoBtn")).click();

		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".promoInfo")));

		System.out.println(driver.findElement(By.cssSelector(".promoInfo")).getText());
		System.out.println(driver.findElement(By.cssSelector(".discountAmt")).getText());
		driver.findElement(By.xpath("//button[text()='Place Order']")).click();

		Select s = new Select(driver.findElement(By.xpath("//select[@style='width: 200px;']")));
		s.selectByValue("India");
		driver.findElement(By.cssSelector(".chkAgree")).click();
		driver.findElement(By.xpath("//button[text()='Proceed']")).click();

	}

	public static void addItems(WebDriver driver, String[] itemsNeeded) throws InterruptedException // static is used in
																									// order to call
																									// method without
																									// creating objects
	{
		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name"));// List is used when
		// WebElement returns more
		// than one element
		int j = 0;

		for (int i = 0; i < products.size(); i++)// iterates for the number of product available on page
		{
			String[] name = products.get(i).getText().split("-");// gets the text of each index and split() is used to
			// split the words
			String formatedName = name[0].trim();// trim() is used to remove white spaces

			List itemsNeededList = Arrays.asList(itemsNeeded);// converts array into array list

			if (itemsNeededList.contains(formatedName)) {
				j++;
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();

				if (j == itemsNeeded.length)
					break;
			}

		}

	}

}
