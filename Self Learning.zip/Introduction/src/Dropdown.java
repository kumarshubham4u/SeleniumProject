import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Dropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver",
				"D:\\\\\\\\Users\\\\\\\\Default User\\\\\\\\Documents\\\\\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		/*
		 * driver.get("https://rahulshettyacademy.com/AutomationPractice/"); Select s =
		 * new Select(driver.findElement(By.id("dropdown-class-example")));
		 * s.selectByValue("option2");
		 */

		driver.get("https://www.spicejet.com/");
		driver.findElement(By.cssSelector("div[id='divpaxinfo']")).click();
		Select s = new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult")));// Select is a class in selenium
																						// and s is an object of select
																						// class
		s.selectByValue("2");// this method is use to select the option by value 2
		// s.selectByIndex(3);//this method is use to select the option by index, i.e.
		// 4th option in the dropdown
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.xpath("//a[@value='BOM']")).click();

		try {
			Thread.sleep(2000);// wait for 2000ms for the page to synchronise
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* driver.findElement(By.xpath("(//a[@value='MAA'])[2]")).click(); */

		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='MAA']"))
				.click();// parent child relationship

		// System.out.println(driver.findElement(By.cssSelector("input[name*='friendsandfamily']")).isSelected());//checks
		// for the selection of checkbox

		Assert.assertFalse(driver.findElement(By.cssSelector("input[name*='friendsandfamily']")).isSelected());// checks
																												// if it
																												// return
																												// false,
																												// else
																												// test
																												// fails

		driver.findElement(By.cssSelector("input[name*='friendsandfamily']")).click();// clicking checkbox
		System.out.println(driver.findElements(By.cssSelector("input[type='checkbox']")).size());// Count the number of
																									// checkboxes in the
																									// page
		// System.out.println(driver.findElement(By.cssSelector("input[name*='friendsandfamily']")).isSelected());
		Assert.assertTrue(driver.findElement(By.cssSelector("input[name*='friendsandfamily']")).isSelected());// checks
																												// if it
																												// return
																												// true,
																												// else
																												// test
																												// fails

		Assert.assertEquals(driver.findElement(By.id("divpaxinfo")).getText(), "2 Adult");// compares the actual and
																							// expected result

		// System.out.println(driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).isEnabled());//not
		// that much reliable

		driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).click();

		if (driver.findElement(By.id("Div1")).getAttribute("style").contains("1")) {
			System.out.println("Return button enabled");
			Assert.assertTrue(true);

		}

		else {
			System.out.println("Return button disabled");
			Assert.assertTrue(false);
		}
		// System.out.println(driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).isEnabled());

	}

}
