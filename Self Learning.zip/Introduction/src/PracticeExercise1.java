import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeExercise1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\\\Users\\\\Default User\\\\Documents\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		WebElement footerDriver = driver.findElement(By.id("gf-BIG")); // creating a subdriver
		System.out.println(driver.findElements(By.tagName("a")).size());
		System.out.println(footerDriver.findElements(By.tagName("a")).size()); // getting the number of links available
																				// in the footer section

		WebElement columnDriver = footerDriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));// creating a
																									// subdriver for a
																									// particular area
		System.out.println(columnDriver.findElements(By.tagName("a")).size());
		for (int i = 1; i < columnDriver.findElements(By.tagName("a")).size(); i++) {
			String clickOnLinkTab = Keys.chord(Keys.CONTROL, Keys.ENTER); // Keys.chord is used to click different
																			// buttons simultaneously
			columnDriver.findElements(By.tagName("a")).get(i).sendKeys(clickOnLinkTab);// opens link in different tabs
			Thread.sleep(2000);
		}

		Set<String> ids = driver.getWindowHandles();
		Iterator<String> it = ids.iterator();

		while (it.hasNext()) {
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());
		} // iterates all the tabs and print the title

	}

}
